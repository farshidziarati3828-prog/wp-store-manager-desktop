<?php
/**
 * Plugin Name:       مدیر فروشگاه (WP Store Manager)
 * Plugin URI:        https://rointansupplement.ir/wp-store-manager
 * Description:       مدیریت فروشگاه ووکامرس و باشگاه ورزشی با PWA فارسی، شهریه، تردد، مربیان و فروش حضوری/آنلاین.
 * Version:           2.3.0.1
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            WSM Team
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-store-manager
 * Domain Path:       /languages
 * WC requires at least: 7.0
 *
 * سازگار با PHP ۷.۴ تا ۸.۴ — وردپرس ۵.۸ تا ۷.۰ — ووکامرس ۷ تا ۹ — HPOS
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WSM_PATH', plugin_dir_path(__FILE__));

register_activation_hook(__FILE__, function () {
    require_once WSM_PATH . 'includes/bootstrap.php';
    WSM_Core::activate();
});
register_deactivation_hook(__FILE__, function () {
    require_once WSM_PATH . 'includes/bootstrap.php';
    WSM_Core::deactivate();
});

// HPOS compatibility (no class load)
add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

// Enforce the in-person-only channel on public WooCommerce pages without loading the full app bundle.
if (function_exists('add_filter')) {
    $wsm_product_channel = function ($product_id) {
        $product_id = (int) $product_id;
        $channel = get_post_meta($product_id, '_wsm_sales_channel', true);
        if (!in_array($channel, array('both', 'online', 'in_person'), true) && function_exists('wp_get_post_parent_id')) {
            $parent_id = (int) wp_get_post_parent_id($product_id);
            if ($parent_id) {
                $channel = get_post_meta($parent_id, '_wsm_sales_channel', true);
            }
        }
        return $channel === 'in_person';
    };
    add_filter('woocommerce_product_is_visible', function ($visible, $product_id) use ($wsm_product_channel) {
        return $wsm_product_channel($product_id) ? false : $visible;
    }, 99, 2);
    add_filter('woocommerce_is_purchasable', function ($purchasable, $product) use ($wsm_product_channel) {
        $id = is_object($product) && method_exists($product, 'get_id') ? $product->get_id() : 0;
        return $id && $wsm_product_channel($id) ? false : $purchasable;
    }, 99, 2);
    add_filter('woocommerce_variation_is_purchasable', function ($purchasable, $product) use ($wsm_product_channel) {
        $id = is_object($product) && method_exists($product, 'get_id') ? $product->get_id() : 0;
        return $id && $wsm_product_channel($id) ? false : $purchasable;
    }, 99, 2);
    add_filter('woocommerce_add_to_cart_validation', function ($passed, $product_id) use ($wsm_product_channel) {
        if ($passed && $wsm_product_channel($product_id)) {
            wc_add_notice('این کالا فقط برای فروش حضوری فعال است و از فروشگاه آنلاین قابل سفارش نیست.', 'error');
            return false;
        }
        return $passed;
    }, 99, 2);
    add_action('woocommerce_check_cart_items', function () use ($wsm_product_channel) {
        if (!function_exists('WC') || !WC()->cart) { return; }
        foreach (WC()->cart->get_cart() as $item) {
            if (!empty($item['product_id']) && $wsm_product_channel($item['product_id'])) {
                wc_add_notice('سبد خرید شامل کالایی است که فقط برای فروش حضوری فعال شده است؛ آن را حذف کنید.', 'error');
                break;
            }
        }
    }, 99);
}

// Record mail failures on all request types. Load the full bootstrap lazily on public pages.
// Keep a single listener: the bootstrap itself does not register another wp_mail_failed callback.
add_action('wp_mail_failed', function ($error) {
    if (!class_exists('WSM_Security', false)) {
        require_once WSM_PATH . 'includes/bootstrap.php';
    }
    WSM_Security::record_mail_error($error);
}, 10, 1);

// Performance gate: public pages load the full plugin only for its own routes, background work,
// or WooCommerce payment/return callbacks. The connect splash needs only WSM_Util and its template;
// loading every business subsystem there parses over 2 MB of PHP on every page view.
$wsm_uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
$wsm_uri_parts = parse_url($wsm_uri);
$wsm_uri_path = is_array($wsm_uri_parts) ? (string) ($wsm_uri_parts['path'] ?? '') : '';
$wsm_uri_query = array();
if (is_array($wsm_uri_parts) && !empty($wsm_uri_parts['query'])) { parse_str((string) $wsm_uri_parts['query'], $wsm_uri_query); }
$wsm_rest_route = isset($wsm_uri_query['rest_route']) && is_scalar($wsm_uri_query['rest_route']) ? trim((string) $wsm_uri_query['rest_route'], '/') : '';
$wsm_connect_request = preg_match('~(?:^|/)wsm-connect/?$~i', $wsm_uri_path) === 1;
$wsm_connect_request = $wsm_connect_request || (isset($wsm_uri_query['wsm_connect']) && is_scalar($wsm_uri_query['wsm_connect']) && (string) $wsm_uri_query['wsm_connect'] !== '');
$wsm_handshake_request = preg_match('~(?:^|/)wsm/v1/handshake/?$~i', $wsm_uri_path) === 1;
$wsm_handshake_request = $wsm_handshake_request || preg_match('~(?:^|/)wsm/v1/handshake/?$~i', $wsm_rest_route) === 1;
$wsm_profile_route = $wsm_connect_request ? 'wsm-connect' : ($wsm_handshake_request ? 'handshake' : '');
$wsm_profile_enabled = $wsm_profile_route !== '' && defined('WP_DEBUG') && WP_DEBUG;
$wsm_request_profile_started = $wsm_profile_enabled ? microtime(true) : 0.0;
if ($wsm_profile_enabled) {
    register_shutdown_function(function () use ($wsm_profile_route, $wsm_request_profile_started) {
        $elapsed = round((microtime(true) - $wsm_request_profile_started) * 1000, 2);
        error_log('[WSM PERF] route=' . $wsm_profile_route . ' total_php_ms=' . $elapsed);
    });
}

$wsm_wc_payment_request = preg_match('~(?:^|/)(?:checkout|order-pay|order-received|wc-api|wp-json/wc)(?:/|$)~i', $wsm_uri_path) === 1;
$wsm_wc_payment_request = $wsm_wc_payment_request || isset($wsm_uri_query['wc-api']) || isset($wsm_uri_query['order-pay']) || isset($wsm_uri_query['order-received']) || !empty($wsm_uri_query['pay_for_order']);
$wsm_wc_payment_request = $wsm_wc_payment_request || (isset($wsm_uri_query['wc-ajax']) && is_scalar($wsm_uri_query['wc-ajax']) && in_array(strtolower((string) $wsm_uri_query['wc-ajax']), array('checkout','checkout_order_review'), true));
$wsm_wc_payment_request = $wsm_wc_payment_request || ($wsm_rest_route !== '' && strpos('/' . $wsm_rest_route . '/', '/wc/') !== false);

if ($wsm_connect_request && !is_admin()) {
    if (!defined('WSM_URL')) { define('WSM_URL', plugin_dir_url(__FILE__)); }
    $wsm_minimal_bootstrap_started = $wsm_profile_enabled ? microtime(true) : 0.0;
    require_once WSM_PATH . 'includes/class-core.php';
    if ($wsm_profile_enabled) {
        $elapsed = round((microtime(true) - $wsm_minimal_bootstrap_started) * 1000, 2);
        error_log('[WSM PERF] route=wsm-connect minimal_bootstrap_ms=' . $elapsed);
    }
    add_action('template_redirect', function () {
        status_header(200);
        nocache_headers();
        header('X-Robots-Tag: noindex, nofollow');
        include WSM_PATH . 'templates/connect.php';
        exit;
    }, -999);
} elseif (is_admin() || stripos($wsm_uri, 'wsm') !== false || stripos($wsm_uri, 'athlete-portal') !== false || $wsm_wc_payment_request || defined('DOING_CRON') || defined('WP_CLI')) {
    $wsm_full_bootstrap_started = $wsm_profile_enabled ? microtime(true) : 0.0;
    require_once WSM_PATH . 'includes/bootstrap.php';
    if ($wsm_profile_enabled) {
        $elapsed = round((microtime(true) - $wsm_full_bootstrap_started) * 1000, 2);
        error_log('[WSM PERF] route=' . $wsm_profile_route . ' full_bootstrap_ms=' . $elapsed);
    }
}

