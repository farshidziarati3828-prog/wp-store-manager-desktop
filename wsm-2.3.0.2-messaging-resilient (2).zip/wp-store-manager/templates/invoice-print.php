<?php
/**
 * قالب چاپ فاکتور تکی و چاپ گروهی (A4، RTL، فارسی با فونت وزیرمتن، بارکد Code-128B و کیوآرکد SVG)
 */
if (!defined('ABSPATH')) {
    exit;
}

$render_list = (!empty($batch_mode) && !empty($batch_invoices) && is_array($batch_invoices))
    ? $batch_invoices
    : array($invoice);
$logo = isset($store['store_logo']) ? (string) $store['store_logo'] : '';
$store_name = !empty($store['store_name']) ? (string) $store['store_name'] : get_bloginfo('name');
$store_phone = !empty($store['postal_sender_phone']) ? (string) $store['postal_sender_phone'] : '';
$store_address_parts = array_filter(array(
    isset($store['postal_sender_state']) ? trim((string) $store['postal_sender_state']) : '',
    isset($store['postal_sender_city']) ? trim((string) $store['postal_sender_city']) : '',
    isset($store['postal_sender_address_1']) ? trim((string) $store['postal_sender_address_1']) : '',
));
$store_address = implode('، ', $store_address_parts);
$store_postal  = isset($store['postal_sender_postcode']) ? trim((string) $store['postal_sender_postcode']) : '';
$page_title    = count($render_list) > 1
    ? ('چاپ گروهی فاکتورها (' . wsm_to_persian_digits((string) count($render_list)) . ' فقره)')
    : ('فاکتور ' . $render_list[0]['number']);
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html($page_title); ?></title>
<style>
  @page { size: A4; margin: 12mm; }
  * { box-sizing: border-box; }
  body {
    font-family: Vazirmatn, "IRANSans", Tahoma, "Segoe UI", Arial, sans-serif;
    direction: rtl;
    color: #0f172a;
    background: #fff;
    margin: 0;
    padding: 18px;
    font-size: 13px;
    line-height: 1.8;
  }
  .actions {
    max-width: 780px;
    margin: 0 auto 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    padding: 10px 14px;
    background: #f8fafc;
    border: 1px solid #d6dbe5;
    border-radius: 10px;
  }
  .actions button {
    padding: 9px 22px;
    border: 0;
    border-radius: 8px;
    background: #0d9488;
    color: #fff;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    font-family: inherit;
  }
  .sheet {
    max-width: 780px;
    margin: 0 auto 24px;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    padding: 18px;
    background: #fff;
    page-break-inside: avoid;
  }
  .sheet.page-break {
    page-break-after: always;
    break-after: page;
  }
  header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 14px;
    border-bottom: 2px solid #0d9488;
    padding-bottom: 12px;
    margin-bottom: 14px;
  }
  header .brand {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  header img.store-logo {
    width: 56px;
    height: 56px;
    object-fit: contain;
    border-radius: 8px;
  }
  h1.store-name {
    font-size: 20px;
    margin: 0;
    color: #0f766e;
  }
  .meta {
    text-align: right;
    direction: rtl;
    font-size: 12px;
    color: #334155;
  }
  .codes-row {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 8px;
  }
  .grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-bottom: 14px;
  }
  .box {
    border: 1px solid #d6dbe5;
    border-radius: 8px;
    padding: 10px 12px;
    background: #fcfdfd;
  }
  .box h2 {
    font-size: 13px;
    margin: 0 0 6px;
    color: #0f766e;
    border-bottom: 1px dashed #d6dbe5;
    padding-bottom: 4px;
  }
  table.items-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 12px;
  }
  table.items-table th, table.items-table td {
    border: 1px solid #d6dbe5;
    padding: 6px 8px;
    text-align: right;
    vertical-align: middle;
  }
  table.items-table th {
    background: #eef6f5;
    font-size: 12px;
    color: #0f172a;
  }
  td.num, th.num { text-align: center; }
  .thumb {
    width: 38px;
    height: 38px;
    object-fit: cover;
    border-radius: 6px;
    border: 1px solid #d6dbe5;
    vertical-align: middle;
    margin-left: 6px;
  }
  .totals {
    width: 320px;
    margin-right: auto;
    border-collapse: collapse;
  }
  .totals td {
    border: none;
    border-bottom: 1px solid #eef0f4;
    padding: 6px 8px;
  }
  .totals tr.grand td {
    font-weight: 700;
    font-size: 15px;
    color: #0f766e;
    border-top: 2px solid #0d9488;
  }
  .num-fa {
    direction: ltr;
    unicode-bidi: plaintext;
    font-variant-numeric: tabular-nums;
  }
  .note {
    margin-top: 14px;
    padding: 8px 12px;
    background: #f8fafc;
    border-radius: 8px;
    font-size: 12px;
    color: #334155;
    white-space: pre-line;
  }
  .stamp {
    display: inline-block;
    margin-top: 4px;
    padding: 2px 10px;
    border: 2px solid #0d9488;
    color: #0f766e;
    border-radius: 6px;
    font-weight: 700;
  }
  .stamp.void {
    border-color: #dc2626;
    color: #b91c1c;
    background: #fef2f2;
  }
  @media print {
    .actions { display: none !important; }
    body { padding: 0; }
    .sheet { border: 0; padding: 0; margin-bottom: 0; }
  }
</style>
</head>
<body>
<div class="actions">
  <div><strong><?php echo esc_html($page_title); ?></strong></div>
  <button type="button" onclick="window.print()">چاپ / ذخیره به PDF</button>
</div>

<?php
$sheet_total = count($render_list);
foreach ($render_list as $sheet_i => $inv_cur):
    $t       = $inv_cur['totals'];
    $is_last = ($sheet_i === $sheet_total - 1);
    $is_void = (!empty($inv_cur['is_void']) || $inv_cur['status'] === 'cancelled');
    $cur_bar = ($sheet_total === 1 && !empty($barcode_svg)) ? $barcode_svg : WSM_Invoices::svg_code128($inv_cur['number']);
    $qr_text = $inv_cur['number'] . '|' . ($inv_cur['source_order_number'] !== '' ? ('ORD-' . $inv_cur['source_order_number']) : 'MANUAL') . '|' . $t['total'] . '|' . $inv_cur['status'];
    $cur_qr  = ($sheet_total === 1 && !empty($qr_svg)) ? $qr_svg : WSM_Invoices::svg_qr($qr_text);
    $buyer_mobile = !empty($inv_cur['buyer']['mobile']) ? $inv_cur['buyer']['mobile'] : (!empty($inv_cur['buyer']['phone']) ? $inv_cur['buyer']['phone'] : '');
?>
<div class="sheet<?php echo !$is_last ? ' page-break' : ''; ?>" data-invoice-id="<?php echo (int) $inv_cur['id']; ?>" data-invoice-number="<?php echo esc_attr($inv_cur['number']); ?>">
  <header>
    <div class="brand">
      <?php if ($logo !== '') : ?>
        <img class="store-logo" src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($store_name); ?>" onerror="this.style.display='none'">
      <?php endif; ?>
      <div>
        <h1 class="store-name"><?php echo esc_html($store_name); ?></h1>
        <div style="font-size:12px;color:#555">فاکتور فروش رسمی</div>
        <div class="stamp<?php echo $is_void ? ' void' : ''; ?>">
          <?php echo esc_html($is_void ? 'باطل‌شده / لغوشده' : $inv_cur['status_label']); ?>
        </div>
      </div>
    </div>
    <div class="meta">
      <div><strong>شماره فاکتور:</strong> <span class="num-fa invoice-number"><?php echo esc_html(wsm_to_persian_digits($inv_cur['number'])); ?></span></div>
      <?php if (!empty($inv_cur['source_order_number'])) : ?>
        <div><strong>شماره سفارش:</strong> <span class="num-fa">#<?php echo esc_html(wsm_to_persian_digits($inv_cur['source_order_number'])); ?></span></div>
      <?php endif; ?>
      <div><strong>تاریخ صدور:</strong> <span class="invoice-date"><?php echo esc_html($inv_cur['date']); ?></span></div>
      <div class="codes-row">
        <?php echo $cur_bar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        <?php echo $cur_qr;  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
      </div>
    </div>
  </header>

  <div class="grid">
    <div class="box">
      <h2>مشخصات خریدار</h2>
      <div>نام: <strong class="buyer-name"><?php echo esc_html($inv_cur['buyer']['name'] ?: '—'); ?></strong></div>
      <div>موبایل: <span class="num-fa"><?php echo esc_html(wsm_to_persian_digits($buyer_mobile ?: '—')); ?></span></div>
      <?php if (!empty($inv_cur['club_member_code']) || !empty($inv_cur['club_card_number'])) : ?>
        <div>کد ورزشکار: <span class="num-fa"><?php echo esc_html(wsm_to_persian_digits($inv_cur['club_member_code'] ?: '—')); ?></span></div>
        <?php if (!empty($inv_cur['club_card_number'])) : ?>
          <div>شماره کارت: <span class="num-fa"><?php echo esc_html(wsm_to_persian_digits($inv_cur['club_card_number'])); ?></span></div>
        <?php endif; ?>
      <?php endif; ?>
      <?php if (!empty($inv_cur['buyer']['national_id'])) : ?>
        <div>کد ملی: <span class="num-fa"><?php echo esc_html(wsm_to_persian_digits($inv_cur['buyer']['national_id'])); ?></span></div>
      <?php endif; ?>
      <?php if (!empty($inv_cur['buyer']['email'])) : ?>
        <div>ایمیل: <span class="num-fa"><?php echo esc_html($inv_cur['buyer']['email']); ?></span></div>
      <?php endif; ?>
      <?php if (!empty($inv_cur['buyer']['address'])) : ?>
        <div>نشانی: <?php echo esc_html($inv_cur['buyer']['address']); ?></div>
      <?php endif; ?>
    </div>
    <div class="box">
      <h2>اطلاعات فروشنده</h2>
      <div><strong><?php echo esc_html($store_name); ?></strong></div>
      <?php if ($store_phone !== '') : ?>
        <div>تلفن: <span class="num-fa"><?php echo esc_html(wsm_to_persian_digits($store_phone)); ?></span></div>
      <?php endif; ?>
      <?php if ($store_address !== '') : ?>
        <div>نشانی: <?php echo esc_html($store_address); ?></div>
      <?php endif; ?>
      <?php if ($store_postal !== '') : ?>
        <div>کد پستی: <span class="num-fa"><?php echo esc_html(wsm_to_persian_digits($store_postal)); ?></span></div>
      <?php endif; ?>
      <div style="font-size:11px;color:#64748b"><?php echo esc_html(home_url('/')); ?></div>
    </div>
  </div>

  <table class="items-table">
    <thead>
      <tr>
        <th class="num" style="width:36px">#</th>
        <th>شرح کالا</th>
        <th class="num" style="width:70px">تعداد</th>
        <th class="num" style="width:125px">فی واحد</th>
        <th class="num" style="width:115px">تخفیف</th>
        <th class="num" style="width:135px">مبلغ خالص</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($inv_cur['items'] as $idx => $it) :
        $unit_p    = isset($it['unit_price']) ? $it['unit_price'] : (isset($it['price']) ? $it['price'] : 0);
        $gross_p   = isset($it['gross']) ? $it['gross'] : ($unit_p * $it['qty']);
        $net_p     = isset($it['total']) ? $it['total'] : (isset($it['line_total']) ? $it['line_total'] : $gross_p);
        $line_d    = max(0, $gross_p - $net_p);
    ?>
      <tr>
        <td class="num"><?php echo esc_html(wsm_to_persian_digits($idx + 1)); ?></td>
        <td>
          <?php if (!empty($it['image_url'])) : ?>
            <img class="thumb" src="<?php echo esc_url($it['image_url']); ?>" alt="" onerror="this.style.display='none'">
          <?php endif; ?>
          <?php echo esc_html($it['name']); ?>
        </td>
        <td class="num"><?php echo esc_html(wsm_to_persian_digits($it['qty'])); ?></td>
        <td class="num"><?php echo esc_html(wsm_fa_money($unit_p)); ?></td>
        <td class="num"><?php echo $line_d > 0 ? esc_html(wsm_fa_money($line_d)) : '—'; ?></td>
        <td class="num"><?php echo esc_html(wsm_fa_money($net_p)); ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <table class="totals">
    <tr><td>جمع ناخالص اقلام</td><td class="num"><?php echo esc_html(wsm_fa_money($t['subtotal'])); ?></td></tr>
    <?php if ($t['line_discount'] > 0) : ?>
      <tr><td>تخفیف اقلام</td><td class="num">− <?php echo esc_html(wsm_fa_money($t['line_discount'])); ?></td></tr>
    <?php endif; ?>
    <?php if ($t['order_discount'] > 0) : ?>
      <tr><td>تخفیف فاکتور</td><td class="num">− <?php echo esc_html(wsm_fa_money($t['order_discount'])); ?></td></tr>
    <?php endif; ?>
    <?php if ($t['tax'] > 0) : ?>
      <tr><td>مالیات<?php echo !empty($inv_cur['tax_percent']) ? (' (' . esc_html(wsm_to_persian_digits($inv_cur['tax_percent'])) . '٪)') : ''; ?></td><td class="num"><?php echo esc_html(wsm_fa_money($t['tax'])); ?></td></tr>
    <?php endif; ?>
    <?php if ($t['shipping'] > 0) : ?>
      <tr><td>هزینهٔ ارسال</td><td class="num"><?php echo esc_html(wsm_fa_money($t['shipping'])); ?></td></tr>
    <?php endif; ?>
    <tr class="grand"><td>مبلغ قابل پرداخت</td><td class="num grand-total"><?php echo esc_html(wsm_fa_money($t['total'])); ?></td></tr>
  </table>

  <?php if (!empty($inv_cur['note'])) : ?>
    <div class="note"><strong>توضیحات:</strong> <?php echo esc_html($inv_cur['note']); ?></div>
  <?php endif; ?>
</div>
<?php endforeach; ?>
</body>
</html>
