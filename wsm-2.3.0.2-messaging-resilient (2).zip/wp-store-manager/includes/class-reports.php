<?php
/**
 * داشبورد و گزارش‌ها: KPI، فروش روزانه، بهای تمام‌شده (COGS)، تفکیک روش پرداخت، پرفروش‌ها و موجودی انبار
 */

if (!defined('ABSPATH')) {
    exit;
}

class WSM_Reports {

    const SALE_STATUSES = array('processing', 'completed');

    /** A changing generation token scopes every sale/dashboard aggregate cache key. */
    public static function sales_cache_epoch() {
        $cache_epoch = get_transient('wsm_reports_sales_epoch_v1');
        if (!is_string($cache_epoch) || $cache_epoch === '') {
            $cache_epoch = wp_generate_uuid4();
            set_transient('wsm_reports_sales_epoch_v1', $cache_epoch, 900);
        }
        return $cache_epoch;
    }

    /** Check whether WooCommerce HPOS custom order tables are active. */
    private static function is_hpos_enabled() {
        $order_util = 'Automattic\\WooCommerce\\Utilities\\OrderUtil';
        if (class_exists($order_util)
            && is_callable(array($order_util, 'custom_orders_table_usage_is_enabled'))
            && (bool) call_user_func(array($order_util, 'custom_orders_table_usage_is_enabled'))) {
            return true;
        }
        return get_option('woocommerce_custom_orders_table_enabled') === 'yes';
    }

    /** Safe percentage helper: never divides by zero or returns NaN/INF. */
    private static function safe_percent($part, $whole) {
        $part_f  = is_numeric($part) ? (float) $part : 0.0;
        $whole_f = is_numeric($whole) ? (float) $whole : 0.0;
        if ($whole_f <= 0.0 || !is_finite($part_f) || !is_finite($whole_f)) {
            return 0.0;
        }
        $pct = round(($part_f / $whole_f) * 100.0, 2);
        return is_finite($pct) ? $pct : 0.0;
    }

    /** Resolve unit purchase cost for an order line item (snapshot first, product fallback second). */
    private static function resolve_line_unit_cost($item, &$product_cost_cache) {
        if (empty(WSM_Util::runtime_settings()['finance_auto_cogs'])) { return ''; }
        if (!is_object($item) || !method_exists($item, 'get_meta')) {
            return '';
        }
        $snapshot_known = (string) $item->get_meta('_wsm_purchase_cost_known', true) === 'yes';
        $snapshot_val   = $item->get_meta('_wsm_purchase_cost_snapshot', true);
        if ($snapshot_known && $snapshot_val !== '' && $snapshot_val !== null && is_numeric((string) $snapshot_val) && (float) $snapshot_val >= 0) {
            return (string) $snapshot_val;
        }
        $variation_id = method_exists($item, 'get_variation_id') ? absint($item->get_variation_id()) : 0;
        $product_id   = method_exists($item, 'get_product_id') ? absint($item->get_product_id()) : 0;
        $lookup_ids   = array_values(array_filter(array_unique(array($variation_id, $product_id))));
        foreach ($lookup_ids as $pid) {
            if (!array_key_exists($pid, $product_cost_cache)) {
                $cost = '';
                $prod = function_exists('wc_get_product') ? wc_get_product($pid) : false;
                if ($prod && class_exists('WSM_Products') && is_callable(array('WSM_Products', 'purchase_cost'))) {
                    $cost = WSM_Products::purchase_cost($prod);
                }
                if ($cost === '' && $prod && method_exists($prod, 'is_type') && $prod->is_type('variation') && $prod->get_parent_id()) {
                    $parent_id = absint($prod->get_parent_id());
                    if (!array_key_exists($parent_id, $product_cost_cache)) {
                        $parent = wc_get_product($parent_id);
                        $product_cost_cache[$parent_id] = ($parent && class_exists('WSM_Products')) ? WSM_Products::purchase_cost($parent) : '';
                    }
                    $cost = $product_cost_cache[$parent_id];
                }
                $product_cost_cache[$pid] = $cost;
            }
            if ($product_cost_cache[$pid] !== '') {
                return (string) $product_cost_cache[$pid];
            }
        }
        return '';
    }

    /** Resolve primary category (term_id + name) for a product ID with request-local memoization. */
    private static function resolve_product_category($product_id, $parent_id, &$category_cache) {
        $target_id = $parent_id > 0 ? $parent_id : $product_id;
        if ($target_id <= 0) {
            return array('id' => 0, 'name' => 'دسته‌بندی‌نشده');
        }
        if (isset($category_cache[$target_id])) {
            return $category_cache[$target_id];
        }
        $terms = function_exists('get_the_terms') ? get_the_terms($target_id, 'product_cat') : false;
        if (is_array($terms) && !empty($terms) && !is_wp_error($terms)) {
            usort($terms, function ($a, $b) {
                return ((int) $a->term_id) <=> ((int) $b->term_id);
            });
            $first = reset($terms);
            $category_cache[$target_id] = array(
                'id'   => (int) $first->term_id,
                'name' => (string) $first->name,
            );
            return $category_cache[$target_id];
        }
        $category_cache[$target_id] = array('id' => 0, 'name' => 'دسته‌بندی‌نشده');
        return $category_cache[$target_id];
    }

    /** Classify order payment method into cash (نقدی), card (کارتی), or credit (نسیه). */
    private static function classify_payment_bucket(WC_Order $order) {
        $pm = strtolower(trim((string) $order->get_payment_method()));
        $pos_pm = strtolower(trim((string) $order->get_meta('_wsm_club_pos_payment_method', true)));
        $is_credit_meta = (bool) $order->get_meta('_wsm_credit_sale', true);

        if ($pos_pm === 'mixed') {
            return 'mixed';
        }
        if ($is_credit_meta || $pm === 'wsm_store_account' || $pos_pm === 'credit'
            || in_array($pm, array('credit', 'store_credit', 'account', 'nesiyeh', 'on_account'), true)) {
            return 'credit';
        }
        if (in_array($pm, array('wsm_pos_cash', 'cod', 'cash'), true) || $pos_pm === 'cash') {
            return 'cash';
        }
        return 'card';
    }

    /**
     * جمع فروش، بهای تمام‌شده (COGS)، سود ناخالص، تفکیک کانال، روش پرداخت و پرفروش‌ها در بازهٔ زمانی (وقت محلی سایت)
     */
    private static function sales_between($start_ts, $end_ts) {
        global $wpdb;

        $timezone    = wp_timezone();
        $start_dt    = (new DateTimeImmutable('@' . (int) $start_ts))->setTimezone($timezone);
        $end_dt      = (new DateTimeImmutable('@' . (int) $end_ts))->setTimezone($timezone);
        $start_local = $start_dt->format('Y-m-d H:i:s');
        $end_local   = $end_dt->format('Y-m-d H:i:s');

        $cache_epoch = self::sales_cache_epoch();
        $cache_key   = 'wsm_reports_sales_aggregate_v6_' . md5($cache_epoch . '|' . (int) $start_ts . '|' . (int) $end_ts);
        $cached      = wp_cache_get($cache_key, 'wsm');
        if (!is_array($cached)) {
            $cached = get_transient($cache_key);
            if (is_array($cached)) {
                wp_cache_set($cache_key, $cached, 'wsm', 900);
            }
        }
        if (is_array($cached) && isset($cached['total'], $cached['count'], $cached['daily'], $cached['channels'], $cached['payment_methods'])) {
            return $cached;
        }

        $hpos_enabled = self::is_hpos_enabled();
        if ($hpos_enabled) {
            $orders_table      = $wpdb->prefix . 'wc_orders';
            $meta_table        = $wpdb->prefix . 'wc_orders_meta';
            $order_id_column   = 'o.id';
            $meta_order_column = 'order_id';
            $order_type_filter = "o.type = 'shop_order'";
            $parent_filter     = 'COALESCE(o.parent_order_id, 0) = 0';
            $created_column    = 'o.date_created_gmt';
            $start_bound       = gmdate('Y-m-d H:i:s', (int) $start_ts);
            $end_bound         = gmdate('Y-m-d H:i:s', (int) $end_ts);
            $credit_on_hold    = "(o.status = 'wc-on-hold' AND (
                o.payment_method = 'wsm_store_account'
                OR EXISTS (
                    SELECT 1 FROM {$meta_table} cm
                    WHERE cm.{$meta_order_column} = {$order_id_column}
                      AND ((cm.meta_key = '_wsm_credit_sale' AND cm.meta_value NOT IN ('', '0'))
                        OR (cm.meta_key = '_wsm_club_pos_payment_method' AND cm.meta_value IN ('credit', 'mixed')))
                )
            ))";
            $order_status_filter = "(o.status IN ('wc-processing', 'wc-completed') OR {$credit_on_hold})";
            $excluded_status_sql = "o.status IN ('wc-cancelled', 'wc-refunded')";
        } else {
            $orders_table      = $wpdb->posts;
            $meta_table        = $wpdb->postmeta;
            $order_id_column   = 'o.ID';
            $meta_order_column = 'post_id';
            $order_type_filter = "o.post_type = 'shop_order'";
            $parent_filter     = 'o.post_parent = 0';
            $created_column    = 'o.post_date';
            $start_bound       = $start_local;
            $end_bound         = $end_local;
            $credit_on_hold    = "(o.post_status = 'wc-on-hold' AND EXISTS (
                SELECT 1 FROM {$meta_table} cm
                WHERE cm.{$meta_order_column} = {$order_id_column}
                  AND ((cm.meta_key = '_payment_method' AND cm.meta_value = 'wsm_store_account')
                    OR (cm.meta_key = '_wsm_credit_sale' AND cm.meta_value NOT IN ('', '0'))
                    OR (cm.meta_key = '_wsm_club_pos_payment_method' AND cm.meta_value IN ('credit', 'mixed')))
            ))";
            $order_status_filter = "(o.post_status IN ('wc-processing', 'wc-completed') OR {$credit_on_hold})";
            $excluded_status_sql = "o.post_status IN ('wc-cancelled', 'wc-refunded')";
        }

        $not_invoice = "NOT EXISTS (
            SELECT 1 FROM {$meta_table} invoice_meta
            WHERE invoice_meta.{$meta_order_column} = {$order_id_column}
              AND invoice_meta.meta_key = '_wsm_invoice'
              AND invoice_meta.meta_value <> ''
              AND invoice_meta.meta_value <> '0'
        )";

        $sql = $wpdb->prepare(
            "SELECT {$order_id_column} AS order_id, {$created_column} AS created_at
             FROM {$orders_table} o
             WHERE {$order_type_filter}
               AND {$order_status_filter}
               AND {$parent_filter}
               AND {$created_column} >= %s
               AND {$created_column} < %s
               AND {$not_invoice}
             ORDER BY {$created_column} ASC, {$order_id_column} ASC",
            $start_bound,
            $end_bound
        );

        $wpdb->last_error = '';
        $rows = $wpdb->get_results($sql, ARRAY_A);
        if ($wpdb->last_error !== '') {
            error_log('[WSM Reports] Sales aggregate SQL error: ' . 'DB Error');
            return new WP_Error('wsm_sales_aggregate_failed', 'محاسبهٔ گزارش فروش انجام نشد.', array('status' => 500));
        }

        // Count cancelled/refunded orders in the same window for transparent audit visibility.
        $excluded_sql = $wpdb->prepare(
            "SELECT COUNT(*) FROM {$orders_table} o
             WHERE {$order_type_filter}
               AND {$excluded_status_sql}
               AND {$parent_filter}
               AND {$created_column} >= %s
               AND {$created_column} < %s
               AND {$not_invoice}",
            $start_bound,
            $end_bound
        );
        $cancelled_or_refunded_count = max(0, (int) $wpdb->get_var($excluded_sql));

        $sum              = 0.0;
        $items_sales_sum  = 0.0;
        $shipping_sum     = 0.0;
        $tax_sum          = 0.0;
        $discount_sum     = 0.0;
        $refunded_sum     = 0.0;
        $cogs_sum         = 0.0;
        $known_cogs_items = 0;
        $missing_cogs     = 0;
        $count            = 0;
        $daily            = array();
        $channels         = array(
            'online'    => array('total' => 0.0, 'count' => 0),
            'in_person' => array('total' => 0.0, 'count' => 0),
        );
        $payment_methods  = array(
            'cash'   => array('key' => 'cash',   'label' => 'نقدی',  'total' => 0.0, 'count' => 0),
            'card'   => array('key' => 'card',   'label' => 'کارتی', 'total' => 0.0, 'count' => 0),
            'credit' => array('key' => 'credit', 'label' => 'نسیه',  'total' => 0.0, 'count' => 0),
        );
        $products_map     = array();
        $categories_map   = array();
        $product_cost_cache = array();
        $category_cache     = array();
        $utc                = new DateTimeZone('UTC');

        foreach ((array) $rows as $row) {
            $order_id   = isset($row['order_id']) ? absint($row['order_id']) : 0;
            $created_at = isset($row['created_at']) ? trim((string) $row['created_at']) : '';
            if ($order_id <= 0 || $created_at === '') {
                continue;
            }
            $order = function_exists('wc_get_order') ? wc_get_order($order_id) : false;
            if (!$order || !($order instanceof WC_Order)) {
                continue;
            }
            $status = (string) $order->get_status();
            if (in_array($status, array('cancelled', 'refunded', 'failed', 'trash', 'checkout-draft'), true)) {
                continue;
            }

            if ($hpos_enabled) {
                $created_dt = date_create_immutable($created_at, $utc);
                if (!$created_dt) {
                    continue;
                }
                $day = $created_dt->setTimezone($timezone)->format('Y-m-d');
            } else {
                $day = substr($created_at, 0, 10);
            }
            if (!self::valid_date($day)) {
                continue;
            }

            $gross_total    = round((float) $order->get_total(), 2);
            $order_refunded = round(max(0.0, (float) $order->get_total_refunded()), 2);
            $refunded_sum   = round($refunded_sum + $order_refunded, 2);
            $net_total      = round(max(0.0, $gross_total - $order_refunded), 2);

            // An order that has been 100% refunded has zero successful revenue and is excluded from active sales.
            if ($gross_total > 0 && $net_total <= 0.0 && $order_refunded >= $gross_total) {
                $cancelled_or_refunded_count++;
                continue;
            }

            $order_shipping = round(max(0.0, (float) $order->get_shipping_total() - (float) $order->get_total_shipping_refunded()), 2);
            $order_tax      = round(max(0.0, (float) $order->get_total_tax() - (float) $order->get_total_tax_refunded()), 2);
            $order_discount = round(max(0.0, (float) $order->get_discount_total()), 2);

            $order_items_sales = 0.0;
            $order_cogs        = 0.0;
            $seen_products_in_order = array();

            foreach ($order->get_items('line_item') as $item_id => $item) {
                if (!($item instanceof WC_Order_Item_Product)) {
                    continue;
                }
                $gross_qty    = (float) $item->get_quantity();
                $refunded_qty = abs((float) $order->get_qty_refunded_for_item($item_id));
                $net_qty      = max(0.0, $gross_qty - $refunded_qty);

                $gross_line    = (float) $item->get_total();
                $refunded_line = abs((float) $order->get_total_refunded_for_item($item_id));
                $net_line      = round(max(0.0, $gross_line - $refunded_line), 2);

                if ($net_qty <= 0.0 && $net_line <= 0.0) {
                    continue;
                }

                $unit_cost_raw = self::resolve_line_unit_cost($item, $product_cost_cache);
                $line_cogs     = 0.0;
                if ($unit_cost_raw !== '' && is_numeric($unit_cost_raw)) {
                    $line_cogs = round((float) $unit_cost_raw * $net_qty, 2);
                    $known_cogs_items++;
                } else {
                    $missing_cogs++;
                }

                $order_items_sales = round($order_items_sales + $net_line, 2);
                $order_cogs        = round($order_cogs + $line_cogs, 2);

                $prod_id   = absint($item->get_product_id());
                $var_id    = absint($item->get_variation_id());
                $entity_id = $var_id > 0 ? $var_id : $prod_id;
                $prod_key  = $entity_id > 0 ? 'p_' . $entity_id : 'name_' . md5((string) $item->get_name());

                if (!isset($products_map[$prod_key])) {
                    $prod_obj = ($entity_id > 0 && function_exists('wc_get_product')) ? wc_get_product($entity_id) : false;
                    $sku      = ($prod_obj && method_exists($prod_obj, 'get_sku')) ? (string) $prod_obj->get_sku() : '';
                    $products_map[$prod_key] = array(
                        'product_id'   => $entity_id,
                        'name'         => (string) $item->get_name(),
                        'sku'          => $sku,
                        'qty_sold'     => 0.0,
                        'orders_count' => 0,
                        'total'        => 0.0,
                        'cogs'         => 0.0,
                        'gross_profit' => 0.0,
                    );
                }
                $products_map[$prod_key]['qty_sold']     = round($products_map[$prod_key]['qty_sold'] + $net_qty, 3);
                $products_map[$prod_key]['total']        = round($products_map[$prod_key]['total'] + $net_line, 2);
                $products_map[$prod_key]['cogs']         = round($products_map[$prod_key]['cogs'] + $line_cogs, 2);
                $products_map[$prod_key]['gross_profit'] = round($products_map[$prod_key]['total'] - $products_map[$prod_key]['cogs'], 2);
                if (!isset($seen_products_in_order[$prod_key])) {
                    $products_map[$prod_key]['orders_count']++;
                    $seen_products_in_order[$prod_key] = true;
                }

                $cat_info = self::resolve_product_category($entity_id, $var_id > 0 ? $prod_id : 0, $category_cache);
                $cat_key  = 'c_' . (int) $cat_info['id'];
                if (!isset($categories_map[$cat_key])) {
                    $categories_map[$cat_key] = array(
                        'category_id'  => (int) $cat_info['id'],
                        'name'         => (string) $cat_info['name'],
                        'qty_sold'     => 0.0,
                        'total'        => 0.0,
                        'cogs'         => 0.0,
                        'gross_profit' => 0.0,
                        '_products'    => array(),
                    );
                }
                $categories_map[$cat_key]['qty_sold']     = round($categories_map[$cat_key]['qty_sold'] + $net_qty, 3);
                $categories_map[$cat_key]['total']        = round($categories_map[$cat_key]['total'] + $net_line, 2);
                $categories_map[$cat_key]['cogs']         = round($categories_map[$cat_key]['cogs'] + $line_cogs, 2);
                $categories_map[$cat_key]['gross_profit'] = round($categories_map[$cat_key]['total'] - $categories_map[$cat_key]['cogs'], 2);
                $categories_map[$cat_key]['_products'][$prod_key] = true;
            }

            // If an order had custom fee/partial order-level refund without line-level breakdown, clamp items_sales safely.
            if ($order_refunded > 0 && $order_items_sales > $net_total) {
                $scale = $order_items_sales > 0 ? ($net_total / $order_items_sales) : 0.0;
                $order_items_sales = $net_total;
                $order_cogs        = round($order_cogs * $scale, 2);
            }

            $order_gross_profit = round($order_items_sales - $order_cogs, 2);

            $pm_slug = strtolower(trim((string) $order->get_payment_method()));
            $is_in_person = (bool) $order->get_meta('_wsm_manual_sale', true)
                || (string) $order->get_meta('_wsm_club_pos_order', true) === 'yes'
                || strpos($pm_slug, 'wsm_pos_') === 0
                || $pm_slug === 'wsm_store_account';

            if (!isset($daily[$day])) {
                $daily[$day] = array(
                    'date'            => $day,
                    'label'           => wsm_fa_date_short($day . ' 00:00:00'),
                    'total'           => 0.0,
                    'items_sales'     => 0.0,
                    'cogs'            => 0.0,
                    'gross_profit'    => 0.0,
                    'online_total'    => 0.0,
                    'in_person_total' => 0.0,
                    'count'           => 0,
                );
            }
            $daily[$day]['total']        = round($daily[$day]['total'] + $net_total, 2);
            $daily[$day]['items_sales']  = round($daily[$day]['items_sales'] + $order_items_sales, 2);
            $daily[$day]['cogs']         = round($daily[$day]['cogs'] + $order_cogs, 2);
            $daily[$day]['gross_profit'] = round($daily[$day]['items_sales'] - $daily[$day]['cogs'], 2);
            $daily[$day]['count']++;

            if ($is_in_person) {
                $daily[$day]['in_person_total']    = round($daily[$day]['in_person_total'] + $net_total, 2);
                $channels['in_person']['total']    = round($channels['in_person']['total'] + $net_total, 2);
                $channels['in_person']['count']++;
            } else {
                $daily[$day]['online_total']       = round($daily[$day]['online_total'] + $net_total, 2);
                $channels['online']['total']       = round($channels['online']['total'] + $net_total, 2);
                $channels['online']['count']++;
            }

            $bucket = self::classify_payment_bucket($order);
            if ($bucket === 'mixed') {
                $raw_cash   = max(0.0, (float) $order->get_meta('_wsm_club_pos_cash_amount', true));
                $raw_card   = max(0.0, (float) $order->get_meta('_wsm_club_pos_card_amount', true));
                $raw_credit = max(0.0, (float) $order->get_meta('_wsm_club_debt_amount', true));
                $raw_sum    = $raw_cash + $raw_card + $raw_credit;
                if ($raw_sum > 0.0) {
                    $cash_part   = round($net_total * ($raw_cash / $raw_sum), 2);
                    $card_part   = round($net_total * ($raw_card / $raw_sum), 2);
                    $credit_part = round($net_total - $cash_part - $card_part, 2);
                    if ($cash_part > 0) {
                        $payment_methods['cash']['total'] = round($payment_methods['cash']['total'] + $cash_part, 2);
                        $payment_methods['cash']['count']++;
                    }
                    if ($card_part > 0) {
                        $payment_methods['card']['total'] = round($payment_methods['card']['total'] + $card_part, 2);
                        $payment_methods['card']['count']++;
                    }
                    if ($credit_part > 0) {
                        $payment_methods['credit']['total'] = round($payment_methods['credit']['total'] + $credit_part, 2);
                        $payment_methods['credit']['count']++;
                    }
                } else {
                    $payment_methods['card']['total'] = round($payment_methods['card']['total'] + $net_total, 2);
                    $payment_methods['card']['count']++;
                }
            } else {
                $payment_methods[$bucket]['total'] = round($payment_methods[$bucket]['total'] + $net_total, 2);
                $payment_methods[$bucket]['count']++;
            }

            $sum             = round($sum + $net_total, 2);
            $items_sales_sum = round($items_sales_sum + $order_items_sales, 2);
            $shipping_sum    = round($shipping_sum + $order_shipping, 2);
            $tax_sum         = round($tax_sum + $order_tax, 2);
            $discount_sum    = round($discount_sum + $order_discount, 2);
            $cogs_sum        = round($cogs_sum + $order_cogs, 2);
            $count++;
        }

        ksort($daily);

        $top_products = array_values($products_map);
        usort($top_products, function ($a, $b) {
            if ($b['total'] !== $a['total']) {
                return $b['total'] <=> $a['total'];
            }
            return $b['qty_sold'] <=> $a['qty_sold'];
        });
        foreach ($top_products as &$tp) {
            $tp['display']              = wsm_fa_money($tp['total']);
            $tp['cogs_display']         = wsm_fa_money($tp['cogs']);
            $tp['gross_profit_display'] = wsm_fa_money($tp['gross_profit']);
            $tp['share_percent']        = self::safe_percent($tp['total'], $items_sales_sum);
        }
        unset($tp);

        $top_categories = array();
        foreach ($categories_map as $cat) {
            $products_count = isset($cat['_products']) && is_array($cat['_products']) ? count($cat['_products']) : 0;
            unset($cat['_products']);
            $cat['products_count']       = $products_count;
            $cat['display']              = wsm_fa_money($cat['total']);
            $cat['cogs_display']         = wsm_fa_money($cat['cogs']);
            $cat['gross_profit_display'] = wsm_fa_money($cat['gross_profit']);
            $cat['share_percent']        = self::safe_percent($cat['total'], $items_sales_sum);
            $top_categories[]            = $cat;
        }
        usort($top_categories, function ($a, $b) {
            if ($b['total'] !== $a['total']) {
                return $b['total'] <=> $a['total'];
            }
            return $b['qty_sold'] <=> $a['qty_sold'];
        });

        $gross_profit = round($items_sales_sum - $cogs_sum, 2);
        $net_profit   = round($sum - $shipping_sum - $tax_sum - $cogs_sum, 2);

        $response = array(
            'total'                      => $sum,
            'items_sales'                => $items_sales_sum,
            'shipping_total'             => $shipping_sum,
            'tax_total'                  => $tax_sum,
            'discount_total'             => $discount_sum,
            'refunded_total'             => $refunded_sum,
            'cancelled_or_refunded_count'=> $cancelled_or_refunded_count,
            'cogs'                       => $cogs_sum,
            'gross_profit'               => $gross_profit,
            'net_profit'                 => $net_profit,
            'profit_margin'              => self::safe_percent($gross_profit, $items_sales_sum),
            'known_cogs_items'           => $known_cogs_items,
            'missing_cogs_items'         => $missing_cogs,
            'count'                      => $count,
            'daily'                      => $daily,
            'channels'                   => $channels,
            'payment_methods'            => $payment_methods,
            'top_products'               => array_slice($top_products, 0, 50),
            'top_categories'             => array_slice($top_categories, 0, 50),
        );
        wp_cache_set($cache_key, $response, 'wsm', 900);
        set_transient($cache_key, $response, 900);
        return $response;
    }

    public static function dashboard() {
        $cache_key = 'wsm_reports_dashboard_v6_' . md5(self::sales_cache_epoch());
        $cached    = wp_cache_get($cache_key, 'wsm');
        if (!is_array($cached)) {
            $cached = get_transient($cache_key);
            if (is_array($cached)) {
                wp_cache_set($cache_key, $cached, 'wsm', 60);
            }
        }
        if (is_array($cached) && isset($cached['today'], $cached['month'], $cached['last30'])) {
            return $cached;
        }
        $timezone        = wp_timezone();
        $now_dt          = new DateTimeImmutable('now', $timezone);
        $tomorrow_start  = $now_dt->modify('+1 day')->setTime(0, 0, 0)->getTimestamp();
        $month_start_dt  = $now_dt->modify('first day of this month')->setTime(0, 0, 0);
        $days30_start_dt = $now_dt->modify('-29 days')->setTime(0, 0, 0);
        $window_s        = min($month_start_dt->getTimestamp(), $days30_start_dt->getTimestamp());

        $window = self::sales_between($window_s, $tomorrow_start);
        if (is_wp_error($window)) {
            return $window;
        }

        $today_day  = $now_dt->format('Y-m-d');
        $month_day  = $now_dt->format('Y-m-01');
        $days30_day = $days30_start_dt->format('Y-m-d');
        $today      = isset($window['daily'][$today_day])
            ? $window['daily'][$today_day]
            : array('total' => 0.0, 'count' => 0);
        $month  = array('total' => 0.0, 'count' => 0);
        $last30 = array('total' => 0.0, 'count' => 0, 'daily' => $window['daily']);
        foreach ($window['daily'] as $day => $totals) {
            if ($day >= $month_day && $day <= $today_day) {
                $month['total'] = round($month['total'] + (float) $totals['total'], 2);
                $month['count'] += (int) $totals['count'];
            }
            if ($day >= $days30_day && $day <= $today_day) {
                $last30['total'] = round($last30['total'] + (float) $totals['total'], 2);
                $last30['count'] += (int) $totals['count'];
            }
        }

        $series = array();
        for ($i = 29; $i >= 0; $i--) {
            $day = $now_dt->modify('-' . $i . ' days')->format('Y-m-d');
            $series[$day] = array(
                'date'  => $day,
                'label' => wsm_fa_date_short($day . ' 00:00:00'),
                'total' => 0.0,
                'count' => 0,
            );
        }
        foreach ($last30['daily'] as $day => $totals) {
            if (isset($series[$day])) {
                $series[$day]['total'] = (float) $totals['total'];
                $series[$day]['count'] = (int) $totals['count'];
            }
        }

        $counts = array();
        foreach (WSM_Orders::statuses() as $s) {
            $counts[$s['key']] = array('label' => $s['label'], 'count' => 0);
        }
        $recent_invoice_ids = WSM_Util::order_ids_with_meta('_wsm_invoice');
        $recent_result = wc_get_orders(array(
            'type'    => 'shop_order',
            'limit'   => 50,
            'page'    => 1,
            'paginate'=> true,
            'orderby' => 'date',
            'order'   => 'DESC',
            'exclude' => $recent_invoice_ids,
        ));
        $all_recent = is_wp_error($recent_result)
            ? array()
            : (is_object($recent_result) && isset($recent_result->orders) ? (array) $recent_result->orders : (array) $recent_result);
        foreach ($all_recent as $o) {
            if (isset($counts[$o->get_status()])) {
                $counts[$o->get_status()]['count']++;
            }
        }

        $recent = array();
        foreach (array_slice($all_recent, 0, 8) as $o) {
            $recent[] = WSM_Orders::format($o);
        }

        $low_stock_count = self::low_stock_count();
        if (is_wp_error($low_stock_count)) {
            return $low_stock_count;
        }

        $response = array(
            'today'         => array('total' => $today['total'], 'count' => $today['count'], 'display' => wsm_fa_money($today['total'])),
            'month'         => array('total' => $month['total'], 'count' => $month['count'], 'display' => wsm_fa_money($month['total'])),
            'last30'        => array('total' => $last30['total'], 'count' => $last30['count'], 'display' => wsm_fa_money($last30['total'])),
            'low_stock'     => $low_stock_count,
            'pending'       => (int) ($counts['pending']['count'] ?? 0) + (int) ($counts['on-hold']['count'] ?? 0),
            'series'        => array_values($series),
            'status_counts' => $counts,
            'recent_orders' => $recent,
        );
        wp_cache_set($cache_key, $response, 'wsm', 60);
        set_transient($cache_key, $response, 60);
        return $response;
    }

    /**
     * اعتبارسنجی تاریخ میلادی Y-m-d
     */
    private static function valid_date($value) {
        if (!is_scalar($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $value)) {
            return false;
        }
        $parts = array_map('intval', explode('-', (string) $value));
        return count($parts) === 3 && checkdate($parts[1], $parts[2], $parts[0]);
    }

    /** Accept Gregorian/Jalali dates (including leap-year Esfand 30) and ISO-like date-time strings, returning Gregorian Y-m-d. */
    public static function normalize_report_date($value) {
        if ($value === null || $value === '') { return ''; }
        if (!is_scalar($value)) { return false; }
        $raw = trim((string) $value);
        if ($raw === '') { return ''; }
        $raw = strtr($raw, array(
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        ));
        $date_only = preg_replace('/(?:\s+|T)(?:[01]?\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d+)?)?(?:Z|[+\-](?:0\d|1\d|2[0-3]):?[0-5]\d)?$/u', '', $raw);
        if (!is_string($date_only)) { return false; }
        $raw = trim($date_only);
        if (!preg_match('/^(\d{4})\s*([\/.\-])\s*(\d{1,2})\s*\2\s*(\d{1,2})$/u', $raw, $parts)) {
            return false;
        }
        $year  = (int) $parts[1];
        $month = (int) $parts[3];
        $day   = (int) $parts[4];
        if ($year > 1600) {
            return checkdate($month, $day, $year) ? sprintf('%04d-%02d-%02d', $year, $month, $day) : false;
        }
        if ($year >= 1200 && $year <= 1600 && class_exists('WSM_Expiry') && is_callable(array('WSM_Expiry', 'normalize_input'))) {
            $gregorian = WSM_Expiry::normalize_input(sprintf('%04d/%02d/%02d', $year, $month, $day));
            return is_string($gregorian) && self::valid_date($gregorian) ? $gregorian : false;
        }
        return false;
    }

    /** Apply RBAC redaction to a sales report payload when `reports.finance` is not granted. */
    private static function format_sales_for_caller(array $response, $include_finance, $can_export) {
        $response['can_view_finance'] = (bool) $include_finance;
        $response['can_export']       = (bool) $can_export;
        $response = WSM_Util::apply_cogs_policy($response);
        if ($include_finance) {
            return $response;
        }
        $response['cogs']                = null;
        $response['cogs_display']        = 'محدود';
        $response['gross_profit']        = null;
        $response['gross_profit_display']= 'محدود';
        $response['net_profit']          = null;
        $response['net_profit_display']  = 'محدود';
        $response['profit_margin']       = null;
        $response['known_cogs_items']    = null;
        $response['missing_cogs_items']  = null;
        $response['finance_restricted']  = true;

        if (isset($response['days']) && is_array($response['days'])) {
            foreach ($response['days'] as &$d) {
                unset($d['cogs'], $d['gross_profit']);
            }
            unset($d);
        }
        if (isset($response['top_products']) && is_array($response['top_products'])) {
            foreach ($response['top_products'] as &$tp) {
                unset($tp['cogs'], $tp['cogs_display'], $tp['gross_profit'], $tp['gross_profit_display']);
            }
            unset($tp);
        }
        if (isset($response['top_categories']) && is_array($response['top_categories'])) {
            foreach ($response['top_categories'] as &$tc) {
                unset($tc['cogs'], $tc['cogs_display'], $tc['gross_profit'], $tc['gross_profit_display']);
            }
            unset($tc);
        }
        return $response;
    }

    public static function sales($from, $to, $options = array()) {
        $include_finance = !is_array($options) || !array_key_exists('include_finance', $options) || (bool) $options['include_finance'];
        $can_export      = !is_array($options) || !array_key_exists('can_export', $options) || (bool) $options['can_export'];

        $from = self::normalize_report_date($from);
        $to   = self::normalize_report_date($to);
        if ($from === false || $to === false) {
            return new WP_Error('wsm_bad_range', 'تاریخ گزارش را به‌صورت شمسی یا میلادی معتبر وارد کنید.', array('status' => 400));
        }
        $timezone = wp_timezone();
        $now      = new DateTimeImmutable('now', $timezone);
        if ($from === '') {
            $from = $now->modify('-29 days')->format('Y-m-d');
        } elseif (!self::valid_date($from)) {
            return new WP_Error('wsm_bad_range', 'تاریخ شروع گزارش نامعتبر است.', array('status' => 400));
        }
        if ($to === '') {
            $to = $now->format('Y-m-d');
        } elseif (!self::valid_date($to)) {
            return new WP_Error('wsm_bad_range', 'تاریخ پایان گزارش نامعتبر است.', array('status' => 400));
        }

        $from_date = DateTimeImmutable::createFromFormat('!Y-m-d', $from, $timezone);
        $to_date   = DateTimeImmutable::createFromFormat('!Y-m-d', $to, $timezone);
        if (!$from_date || !$to_date || $from_date > $to_date) {
            return new WP_Error('wsm_bad_range', 'بازهٔ زمانی نامعتبر است.', array('status' => 400));
        }
        $range_days = (int) $from_date->diff($to_date)->format('%a') + 1;
        if ($range_days > 366) {
            return new WP_Error('wsm_bad_range', 'برای گزارش فروش، بازهٔ انتخابی حداکثر ۳۶۶ روز است.', array('status' => 400));
        }

        // Exact inclusive day boundaries in site timezone [00:00:00 of $from, 00:00:00 of $to + 1 day).
        $start = $from_date->getTimestamp();
        $end   = $to_date->modify('+1 day')->getTimestamp();

        $cache_epoch = self::sales_cache_epoch();
        $cache_key   = 'wsm_reports_sales_v6_' . md5($cache_epoch . '|' . $from . '|' . $to);
        $cached      = wp_cache_get($cache_key, 'wsm');
        if (!is_array($cached)) {
            $cached = get_transient($cache_key);
            if (is_array($cached)) {
                wp_cache_set($cache_key, $cached, 'wsm', 900);
            }
        }
        if (is_array($cached)) {
            return self::format_sales_for_caller($cached, $include_finance, $can_export);
        }

        $data = self::sales_between($start, $end);
        if (is_wp_error($data)) {
            return $data;
        }

        // Build continuous daily series across every calendar day in [$from .. $to] with Jalali labels.
        $days   = array();
        $cursor = $from_date;
        for ($i = 0; $i < $range_days; $i++) {
            $d_iso = $cursor->format('Y-m-d');
            if (isset($data['daily'][$d_iso])) {
                $days[] = $data['daily'][$d_iso];
            } else {
                $days[] = array(
                    'date'            => $d_iso,
                    'label'           => wsm_fa_date_short($d_iso . ' 00:00:00'),
                    'total'           => 0.0,
                    'items_sales'     => 0.0,
                    'cogs'            => 0.0,
                    'gross_profit'    => 0.0,
                    'online_total'    => 0.0,
                    'in_person_total' => 0.0,
                    'count'           => 0,
                );
            }
            $cursor = $cursor->modify('+1 day');
        }

        $total_sales = (float) $data['total'];
        $pm_out = array();
        foreach (array('cash', 'card', 'credit') as $pm_key) {
            $pm_row = isset($data['payment_methods'][$pm_key]) ? $data['payment_methods'][$pm_key] : array('key' => $pm_key, 'label' => $pm_key, 'total' => 0.0, 'count' => 0);
            $pm_total = (float) $pm_row['total'];
            $pm_out[$pm_key] = array(
                'key'           => $pm_key,
                'label'         => $pm_row['label'],
                'total'         => $pm_total,
                'count'         => (int) $pm_row['count'],
                'display'       => wsm_fa_money($pm_total),
                'share_percent' => self::safe_percent($pm_total, $total_sales),
            );
        }

        $online_total    = (float) $data['channels']['online']['total'];
        $in_person_total = (float) $data['channels']['in_person']['total'];

        $response = array(
            'from'                       => $from,
            'to'                         => $to,
            'from_jalali'                => wsm_fa_date_short($from . ' 00:00:00'),
            'to_jalali'                  => wsm_fa_date_short($to . ' 00:00:00'),
            'timezone'                   => $timezone->getName(),
            'is_empty'                   => ((int) $data['count']) === 0,
            'total'                      => $total_sales,
            'display'                    => wsm_fa_money($total_sales),
            'items_sales'                => (float) $data['items_sales'],
            'items_sales_display'        => wsm_fa_money($data['items_sales']),
            'shipping_total'             => (float) $data['shipping_total'],
            'shipping_display'           => wsm_fa_money($data['shipping_total']),
            'tax_total'                  => (float) $data['tax_total'],
            'discount_total'             => (float) $data['discount_total'],
            'refunded_total'             => (float) $data['refunded_total'],
            'refunded_display'           => wsm_fa_money($data['refunded_total']),
            'cancelled_or_refunded_count'=> (int) $data['cancelled_or_refunded_count'],
            'cogs'                       => (float) $data['cogs'],
            'cogs_display'               => wsm_fa_money($data['cogs']),
            'gross_profit'               => (float) $data['gross_profit'],
            'gross_profit_display'       => wsm_fa_money($data['gross_profit']),
            'net_profit'                 => (float) $data['net_profit'],
            'net_profit_display'         => wsm_fa_money($data['net_profit']),
            'profit_margin'              => (float) $data['profit_margin'],
            'known_cogs_items'           => (int) $data['known_cogs_items'],
            'missing_cogs_items'         => (int) $data['missing_cogs_items'],
            'count'                      => (int) $data['count'],
            'channels'                   => array(
                'online' => array(
                    'total'         => $online_total,
                    'count'         => (int) $data['channels']['online']['count'],
                    'display'       => wsm_fa_money($online_total),
                    'share_percent' => self::safe_percent($online_total, $total_sales),
                ),
                'in_person' => array(
                    'total'         => $in_person_total,
                    'count'         => (int) $data['channels']['in_person']['count'],
                    'display'       => wsm_fa_money($in_person_total),
                    'share_percent' => self::safe_percent($in_person_total, $total_sales),
                ),
            ),
            'payment_methods'            => $pm_out,
            'top_products'               => $data['top_products'],
            'top_categories'             => $data['top_categories'],
            'days'                       => $days,
        );
        wp_cache_set($cache_key, $response, 'wsm', 900);
        set_transient($cache_key, $response, 900);
        return self::format_sales_for_caller($response, $include_finance, $can_export);
    }

    /** Single invalidation point for dashboard, sales, stock, club overview, and order-list snapshots. */
    public static function flush_sale_caches($arg1 = null, $arg2 = null, $arg3 = null, $arg4 = null) {
        set_transient('wsm_reports_sales_epoch_v1', wp_generate_uuid4(), 900);
        set_transient('wsm_orders_list_epoch_v1', wp_generate_uuid4(), 900);

        foreach (array(
            'wsm_api_dashboard_v4',
            'wsm_api_dashboard_v3',
            'wsm_api_club_overview_v1',
            'wsm_api_club_overview_v2',
            'wsm_reports_dashboard_v4',
            'wsm_reports_dashboard_v3',
            'wsm_reports_dashboard_v2',
            'wsm_reports_stock_v1',
            'wsm_reports_stock_v2',
            'wsm_reports_low_stock_count_v4',
            'wsm_reports_low_stock_count_v3',
            'wsm_reports_low_stock_count_v2',
            'wsm_reports_low_stock_count_v1',
            'wsm_club_overview_v2',
            'wsm_club_overview_v3',
        ) as $cache_key) {
            wp_cache_delete($cache_key, 'wsm');
            delete_transient($cache_key);
        }
        return true;
    }

    public static function invalidate_dashboard_cache($arg1 = null, $arg2 = null, $arg3 = null, $arg4 = null) {
        return self::flush_sale_caches();
    }

    public static function invalidate_stock_cache($arg1 = null, $arg2 = null, $arg3 = null) {
        return self::flush_sale_caches();
    }

    public static function invalidate_stock_cache_for_post($post_id, $post = null) {
        $post_type = is_object($post) && isset($post->post_type)
            ? (string) $post->post_type
            : get_post_type((int) $post_id);
        if (in_array($post_type, array('product', 'product_variation'), true)) {
            self::invalidate_stock_cache();
        }
    }

    /** Count strictly low-stock products (quantity > 0 AND <= threshold, excluding out-of-stock). */
    private static function low_stock_count() {
        $all = self::load_all_stock_rows();
        if (is_wp_error($all)) {
            return $all;
        }
        return (int) $all['summary']['low_stock_count'];
    }

    /** Load and classify all published/private store products in one fast SQL query. */
    private static function load_all_stock_rows() {
        global $wpdb;

        $epoch     = self::sales_cache_epoch();
        $cache_key = 'wsm_reports_stock_v2_' . md5($epoch);
        $cached    = wp_cache_get($cache_key, 'wsm');
        if (!is_array($cached)) {
            $cached = get_transient($cache_key);
            if (is_array($cached)) {
                wp_cache_set($cache_key, $cached, 'wsm', 120);
            }
        }
        if (is_array($cached) && isset($cached['rows'], $cached['summary'])) {
            return $cached;
        }

        $default_threshold = get_option('woocommerce_notify_low_stock_amount', 2);
        $default_threshold = is_numeric($default_threshold) ? max(0, (int) $default_threshold) : 2;

        $query = "SELECT p.ID AS id,
                         p.post_title AS name,
                         MAX(CASE WHEN pm.meta_key = '_sku' THEN pm.meta_value END) AS sku,
                         MAX(CASE WHEN pm.meta_key = '_manage_stock' THEN pm.meta_value END) AS manage_stock,
                         MAX(CASE WHEN pm.meta_key = '_stock' THEN pm.meta_value END) AS stock_quantity,
                         MAX(CASE WHEN pm.meta_key = '_stock_status' THEN pm.meta_value END) AS stock_status,
                         MAX(CASE WHEN pm.meta_key = '_low_stock_amount' THEN pm.meta_value END) AS low_stock_amount,
                         MAX(CASE WHEN pm.meta_key = '_price' THEN pm.meta_value END) AS price,
                         MAX(CASE WHEN pm.meta_key = '_wsm_purchase_cost' THEN pm.meta_value END) AS purchase_cost,
                         MAX(CASE WHEN pm.meta_key = '_wsm_cogs' THEN pm.meta_value END) AS legacy_cogs,
                         MAX(CASE WHEN pm.meta_key = '_cogs_total_value' THEN pm.meta_value END) AS native_cogs
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} pm
                    ON pm.post_id = p.ID
                   AND pm.meta_key IN (
                       '_sku', '_manage_stock', '_stock', '_stock_status',
                       '_low_stock_amount', '_price', '_wsm_purchase_cost', '_wsm_cogs', '_cogs_total_value'
                   )
                  WHERE p.post_type = 'product'
                    AND p.post_status IN ('publish', 'private')
                  GROUP BY p.ID, p.post_title
                  ORDER BY p.post_title ASC, p.ID ASC";

        $wpdb->last_error = '';
        $db_rows = $wpdb->get_results($query, ARRAY_A);
        if ($wpdb->last_error !== '') {
            error_log('[WSM Reports] Stock report SQL error: ' . 'DB Error');
            return new WP_Error('wsm_stock_report_failed', 'گزارش موجودی انبار دریافت نشد.', array('status' => 500));
        }

        $rows = array();
        $in_stock_count     = 0;
        $low_stock_count    = 0;
        $out_of_stock_count = 0;
        $total_units        = 0;
        $retail_value       = 0.0;
        $cost_value         = 0.0;

        foreach ((array) $db_rows as $row) {
            $manage_value = isset($row['manage_stock']) ? (string) $row['manage_stock'] : '';
            $manage_stock = in_array($manage_value, array('yes', '1', 'true'), true);
            $raw_quantity = isset($row['stock_quantity']) ? $row['stock_quantity'] : null;
            $quantity     = ($manage_stock && $raw_quantity !== '' && $raw_quantity !== null && is_numeric($raw_quantity))
                ? (int) round((float) $raw_quantity)
                : null;
            $raw_status   = isset($row['stock_status']) && $row['stock_status'] !== '' ? (string) $row['stock_status'] : 'instock';
            $custom_low   = isset($row['low_stock_amount']) && $row['low_stock_amount'] !== '' && is_numeric($row['low_stock_amount'])
                ? max(0, (int) $row['low_stock_amount'])
                : null;
            $threshold    = $custom_low !== null ? $custom_low : $default_threshold;

            $is_out = ($raw_status === 'outofstock') || ($manage_stock && $quantity !== null && $quantity <= 0);
            $is_low = !$is_out && $manage_stock && $quantity !== null && $quantity > 0 && $quantity <= $threshold;

            if ($is_out) {
                $state_key   = 'out_of_stock';
                $state_label = 'ناموجود';
                $effective_status = 'outofstock';
                $out_of_stock_count++;
            } elseif ($is_low) {
                $state_key   = 'low_stock';
                $state_label = 'کم‌موجودی';
                $effective_status = 'instock';
                $low_stock_count++;
            } else {
                $state_key   = 'in_stock';
                $state_label = 'موجود';
                $effective_status = $raw_status === 'onbackorder' ? 'onbackorder' : 'instock';
                $in_stock_count++;
            }

            $price_str = isset($row['price']) && $row['price'] !== null ? (string) $row['price'] : '';
            $cost_str  = '';
            foreach (array('purchase_cost', 'legacy_cogs', 'native_cogs') as $ck) {
                if (isset($row[$ck]) && $row[$ck] !== '' && $row[$ck] !== null && is_numeric((string) $row[$ck]) && (float) $row[$ck] >= 0) {
                    $cost_str = (string) $row[$ck];
                    break;
                }
            }

            if ($manage_stock && $quantity !== null && $quantity > 0) {
                $total_units += $quantity;
                if ($price_str !== '' && is_numeric($price_str)) {
                    $retail_value = round($retail_value + ((float) $price_str * $quantity), 2);
                }
                if ($cost_str !== '' && is_numeric($cost_str)) {
                    $cost_value = round($cost_value + ((float) $cost_str * $quantity), 2);
                }
            }

            $rows[] = array(
                'id'                 => isset($row['id']) ? (int) $row['id'] : 0,
                'name'               => isset($row['name']) ? (string) $row['name'] : '',
                'sku'                => isset($row['sku']) ? (string) $row['sku'] : '',
                'manage_stock'       => $manage_stock,
                'stock_quantity'     => $quantity,
                'low_stock_threshold'=> $threshold,
                'stock_status'       => $effective_status,
                'stock_state'        => $state_key,
                'stock_state_label'  => $state_label,
                'price'              => $price_str,
                'price_display'      => $price_str !== '' && is_numeric($price_str) ? wsm_fa_money((float) $price_str) : '—',
                'purchase_cost'      => $cost_str,
            );
        }

        // Urgent items first: out_of_stock (0), low_stock (1), in_stock (2), then ascending quantity, then name.
        $rank = array('out_of_stock' => 0, 'low_stock' => 1, 'in_stock' => 2);
        usort($rows, function ($a, $b) use ($rank) {
            $ra = $rank[$a['stock_state']] ?? 3;
            $rb = $rank[$b['stock_state']] ?? 3;
            if ($ra !== $rb) {
                return $ra <=> $rb;
            }
            $qa = $a['stock_quantity'] === null ? PHP_INT_MAX : $a['stock_quantity'];
            $qb = $b['stock_quantity'] === null ? PHP_INT_MAX : $b['stock_quantity'];
            if ($qa !== $qb) {
                return $qa <=> $qb;
            }
            return strcmp((string) $a['name'], (string) $b['name']);
        });

        $total_count = count($rows);
        $payload = array(
            'rows'    => $rows,
            'summary' => array(
                'total_count'          => $total_count,
                'in_stock_count'       => $in_stock_count,
                'low_stock_count'      => $low_stock_count,
                'out_of_stock_count'   => $out_of_stock_count,
                'total_units'          => $total_units,
                'default_low_threshold'=> $default_threshold,
                'inventory_retail_value'         => $retail_value,
                'inventory_retail_value_display' => wsm_fa_money($retail_value),
                'inventory_cost_value'           => $cost_value,
                'inventory_cost_value_display'   => wsm_fa_money($cost_value),
            ),
        );
        wp_cache_set($cache_key, $payload, 'wsm', 120);
        set_transient($cache_key, $payload, 120);
        return $payload;
    }

    /**
     * گزارش موجودی انبار (با تفکیک موجود / کم‌موجودی / ناموجود، فیلتر، جستجو و صفحه‌بندی سریع)
     */
    public static function stock($params = array()) {
        $params          = is_array($params) ? $params : array();
        $include_finance = !array_key_exists('include_finance', $params) || (bool) $params['include_finance'];
        $can_export      = !array_key_exists('can_export', $params) || (bool) $params['can_export'];

        $loaded = self::load_all_stock_rows();
        if (is_wp_error($loaded)) {
            return $loaded;
        }

        $rows    = $loaded['rows'];
        $summary = $loaded['summary'];

        $status_filter = isset($params['status']) ? sanitize_key((string) $params['status']) : 'all';
        if (in_array($status_filter, array('in_stock', 'low_stock', 'out_of_stock'), true)) {
            $rows = array_values(array_filter($rows, function ($r) use ($status_filter) {
                return $r['stock_state'] === $status_filter;
            }));
        } else {
            $status_filter = 'all';
        }

        $search = isset($params['search']) ? trim((string) $params['search']) : '';
        if ($search !== '') {
            $needle = class_exists('WSM_Persian_Normalizer')
                ? mb_strtolower(WSM_Persian_Normalizer::normalize($search), 'UTF-8')
                : mb_strtolower($search, 'UTF-8');
            $rows = array_values(array_filter($rows, function ($r) use ($needle) {
                $hay_name = class_exists('WSM_Persian_Normalizer')
                    ? mb_strtolower(WSM_Persian_Normalizer::normalize((string) $r['name']), 'UTF-8')
                    : mb_strtolower((string) $r['name'], 'UTF-8');
                $hay_sku  = mb_strtolower((string) $r['sku'], 'UTF-8');
                return mb_strpos($hay_name, $needle, 0, 'UTF-8') !== false
                    || mb_strpos($hay_sku, $needle, 0, 'UTF-8') !== false
                    || (string) $r['id'] === $needle;
            }));
        }

        $filtered_total = count($rows);
        $want_all       = !empty($params['all']) && rest_sanitize_boolean($params['all']);
        $has_paging     = isset($params['page']) || isset($params['per_page']);

        if ($want_all || !$has_paging) {
            $page        = 1;
            $per_page    = max(1, $filtered_total);
            $total_pages = 1;
            $paged_rows  = $rows;
        } else {
            $per_page    = isset($params['per_page']) ? max(1, min(200, absint($params['per_page']))) : 50;
            $total_pages = max(1, (int) ceil($filtered_total / $per_page));
            $page        = isset($params['page']) ? max(1, min($total_pages, absint($params['page']))) : 1;
            $offset      = ($page - 1) * $per_page;
            $paged_rows  = array_slice($rows, $offset, $per_page);
        }

        if (!$include_finance) {
            foreach ($paged_rows as &$r) {
                unset($r['purchase_cost']);
            }
            unset($r);
            $summary['inventory_cost_value']         = null;
            $summary['inventory_cost_value_display'] = 'محدود';
            $summary['finance_restricted']           = true;
        }

        return array(
            'items'            => array_values($paged_rows),
            'low_count'        => (int) $summary['low_stock_count'],
            'in_stock_count'   => (int) $summary['in_stock_count'],
            'low_stock_count'  => (int) $summary['low_stock_count'],
            'out_of_stock_count'=> (int) $summary['out_of_stock_count'],
            'total_products'   => (int) $summary['total_count'],
            'summary'          => $summary,
            'status_filter'    => $status_filter,
            'search'           => $search,
            'total'            => $filtered_total,
            'page'             => $page,
            'per_page'         => $per_page,
            'total_pages'      => $total_pages,
            'can_view_finance' => (bool) $include_finance,
            'can_export'       => (bool) $can_export,
        );
    }

}
