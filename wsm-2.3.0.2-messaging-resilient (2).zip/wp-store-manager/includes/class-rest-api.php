<?php
/**
 * REST API: /wp-json/wsm/v1/...
 * همهٔ مسیرها به‌جز handshake و refresh با توکن Bearer محافظت می‌شوند.
 */

if (!defined('ABSPATH')) {
    exit;
}

class WSM_Rest_API {

    const NS = 'wsm/v1';

    private static $app_init_shutdown_armed = false;
    private static $app_init_auth_verified = false;
    private static $app_init_output_level = null;
    private static $app_init_memory_reserve = null;
    private static $sqlite_sync_lock_handle = null;

    public static function register() {
        add_filter('rest_post_dispatch', array(__CLASS__, 'disable_wsm_rest_caching'), 10, 3);
        // WooCommerce writes are invalidated centrally by WSM_Core; this REST filter
        // handles WSM-specific mutations after their callbacks have completed.
        // check_request() deliberately fails closed for unmapped routes. app-init runs
        // that complete Bearer/HMAC/account check, then authorizes each returned section below.
        register_rest_route(self::NS, '/app-init', array(
            'methods'             => 'GET',
            'callback'            => array(__CLASS__, 'app_init'),
            'permission_callback' => array(__CLASS__, 'app_init_permission'),
        ));
        // اتصال و نشست
        self::route('/auth/login', 'POST', 'auth_login', true);
        self::route('/auth/otp/request', 'POST', 'auth_login_otp_request', true);
        self::route('/auth/otp/verify', 'POST', 'auth_login_otp_verify', true);
        self::route('/auth/recovery/request', 'POST', 'auth_recovery_request', true);
        self::route('/auth/recovery/reset', 'POST', 'auth_recovery_reset', true);
        self::route('/handshake', 'POST', 'handshake', true);
        self::route('/refresh', 'POST', 'refresh', true);
        self::route('/logout', 'POST', 'logout');
        // Offline actions are authenticated here and each action is authorized by the processor.
        register_rest_route(self::NS, '/sync/bulk', array(
            'methods' => 'POST',
            'callback' => array(__CLASS__, 'sync_bulk'),
            'permission_callback' => array(__CLASS__, 'sync_bulk_permission'),
        ));
        // Internal messages have a separate fail-closed account check and scoped inbox rules.
        register_rest_route(self::NS, '/messages/send', array(
            'methods' => 'POST', 'callback' => array(__CLASS__, 'messages_send'),
            'permission_callback' => array(__CLASS__, 'messages_permission'),
        ));
        register_rest_route(self::NS, '/messages/inbox', array(
            'methods' => 'GET', 'callback' => array(__CLASS__, 'messages_inbox'),
            'permission_callback' => array(__CLASS__, 'messages_permission'),
        ));
        register_rest_route(self::NS, '/messages/status', array(
            'methods' => 'POST', 'callback' => array(__CLASS__, 'messages_status'),
            'permission_callback' => array(__CLASS__, 'messages_permission'),
        ));
        register_rest_route(self::NS, '/messages/contact', array(
            'methods' => 'GET', 'callback' => array(__CLASS__, 'messages_contact'),
            'permission_callback' => array(__CLASS__, 'messages_permission'),
        ));
        register_rest_route(self::NS, '/messages/quick-replies', array(
            'methods' => array('GET', 'POST'), 'callback' => array(__CLASS__, 'messages_quick_replies'),
            'permission_callback' => array(__CLASS__, 'messages_permission'),
        ));
        register_rest_route(self::NS, '/messages/recipients', array(
            'methods' => 'GET', 'callback' => array(__CLASS__, 'messages_recipients'),
            'permission_callback' => array(__CLASS__, 'messages_permission'),
        ));
        register_rest_route(self::NS, '/messages/read', array(
            'methods' => 'POST', 'callback' => array(__CLASS__, 'messages_read'),
            'permission_callback' => array(__CLASS__, 'messages_permission'),
        ));
        register_rest_route(self::NS, '/messages/delete', array(
            'methods' => 'POST', 'callback' => array(__CLASS__, 'messages_delete'),
            'permission_callback' => array(__CLASS__, 'messages_permission'),
        ));
        register_rest_route(self::NS, '/messages/audit', array(
            'methods' => 'GET', 'callback' => array(__CLASS__, 'messages_audit_list'),
            'permission_callback' => array(__CLASS__, 'messages_permission'),
        ));
        // Delta pull uses the same Bearer/HMAC validation with scoped read permissions.
        register_rest_route(self::NS, '/sync/pull', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'sync_pull'),
            'permission_callback' => array(__CLASS__, 'sync_pull_permission'),
        ));
        self::route('/me', 'GET', 'me');
        self::route('/profile', 'GET', 'profile_get');
        self::route('/profile', 'PUT', 'profile_update');
        self::route('/settings', 'GET', 'settings');
        self::route('/settings/runtime', 'GET', 'settings_runtime');
        self::route('/settings', 'PUT', 'settings_update');
        self::route('/security', 'GET', 'security_get');
        self::route('/security', 'PUT', 'security_update');

        // داشبورد و گزارش
        self::route('/dashboard', 'GET', 'dashboard');
        self::route('/reports/sales', 'GET', 'report_sales');
        self::route('/reports/stock', 'GET', 'report_stock');

        // محصولات
        self::route('/products', 'GET', 'products_list');
        self::route('/products', 'POST', 'products_create');
        self::route('/products/barcode', 'POST', 'products_barcode');
        self::route('/products/expiring', 'GET', 'products_expiring');
        self::route('/categories', 'GET', 'categories_list');
        self::route('/products/(?P<id>\d+)', 'GET', 'products_get');
        self::route('/products/(?P<id>\d+)', 'PUT', 'products_update');
        self::route('/products/(?P<id>\d+)', 'DELETE', 'products_delete');
        self::route('/products/(?P<id>\d+)/copy', 'POST', 'products_copy');
        self::route('/products/(?P<id>\d+)/image', 'POST', 'products_image');

        // سفارش‌ها
        self::route('/orders', 'GET', 'orders_list');
        self::route('/orders/statuses', 'GET', 'orders_statuses');
        self::route('/orders/manual', 'POST', 'orders_manual');
        self::route('/orders/bulk-status', 'POST', 'orders_bulk_status');
        self::route('/orders/(?P<id>\d+)/print', 'GET', 'orders_print');
        self::route('/orders/(?P<id>\d+)', 'GET', 'orders_get');
        self::route('/orders/(?P<id>\d+)', 'PUT', 'orders_update');
        self::route('/orders/(?P<id>\d+)', 'DELETE', 'orders_delete');
        self::route('/orders/(?P<id>\d+)/invoice', 'POST', 'orders_invoice');
        self::route('/orders/(?P<id>\d+)/status', 'POST', 'orders_status');
        self::route('/orders/(?P<id>\d+)/refund-accounts', 'GET', 'orders_refund_accounts');
        self::route('/orders/(?P<id>\d+)/refund', 'POST', 'orders_refund');
        self::route('/orders/(?P<id>\d+)/history', 'GET', 'orders_history');

        // فاکتورها
        self::route('/invoices', 'GET', 'invoices_list');
        self::route('/invoices', 'POST', 'invoices_create');
        self::route('/invoices/statuses', 'GET', 'invoices_statuses');
        self::route('/invoices/batch-html', 'GET', 'invoices_batch_html');
        self::route('/invoices/batch-html', 'POST', 'invoices_batch_html');
        self::route('/invoices/(?P<id>\d+)', 'GET', 'invoices_get');
        self::route('/invoices/(?P<id>\d+)', 'PUT', 'invoices_update');
        self::route('/invoices/(?P<id>\d+)', 'DELETE', 'invoices_delete');
        self::route('/invoices/(?P<id>\d+)/status', 'POST', 'invoices_status');
        self::route('/invoices/(?P<id>\d+)/copy', 'POST', 'invoices_copy');
        self::route('/invoices/(?P<id>\d+)/html', 'GET', 'invoices_html');
        self::route('/invoices/(?P<id>\d+)/label', 'GET', 'invoices_label');

        // مشتریان، دستگاه‌ها، فعالیت
        self::route('/customers', 'GET', 'customers_list');
        self::route('/customers/(?P<id>\d+)', 'GET', 'customers_get');
        self::route('/store-customers', 'GET', 'store_customers_list');
        self::route('/store-customers', 'POST', 'store_customers_create');
        self::route('/store-customers/(?P<id>\d+)', 'GET', 'store_customer_get');
        self::route('/store-customers/(?P<id>\d+)', 'PUT', 'store_customer_update');
        self::route('/store-customers/(?P<id>\d+)/payments', 'POST', 'store_customer_payment');
        self::route('/users', 'GET', 'app_users');
        self::route('/users', 'POST', 'app_user_create');
        self::route('/users/(?P<id>\d+)', 'PUT', 'app_user_update');
        self::route('/users/(?P<id>\d+)', 'DELETE', 'app_user_delete');
        foreach (array('/users', '/club/users') as $user_route) {
            self::route($user_route . '/(?P<id>\d+)/access-key', 'POST', 'user_key_issue');
            self::route($user_route . '/(?P<id>\d+)/access-key', 'DELETE', 'user_key_revoke');
            self::route($user_route . '/(?P<id>\d+)/force-logout', 'POST', 'user_force_logout');
            self::route($user_route . '/(?P<id>\d+)/audit', 'GET', 'user_audit');
        }
        self::route('/club/users/(?P<id>\d+)', 'DELETE', 'app_user_delete');
        self::route('/devices', 'GET', 'devices_list');
        self::route('/devices/(?P<id>\d+)/status', 'POST', 'devices_status');
        self::route('/activity', 'GET', 'activity');
        register_rest_route(self::NS, '/activity-log', array(
            'methods' => 'GET', 'callback' => array(__CLASS__, 'activity'),
            'permission_callback' => array(__CLASS__, 'activity_log_alias_permission'),
        ));

        // مدیریت باشگاه
        self::route('/club/overview', 'GET', 'club_overview');
        self::route('/club/members', 'GET', 'club_members');
        self::route('/club/members', 'POST', 'club_member_create');
        self::route('/club/members/(?P<id>\d+)', 'GET', 'club_member_get');
        self::route('/club/members/(?P<id>\d+)', 'PUT', 'club_member_update');
        self::route('/club/members/(?P<id>\d+)/avatar', array('POST', 'DELETE'), 'club_member_avatar');
        self::route('/club/members/(?P<id>\d+)/archive', 'POST', 'club_member_archive');
        self::route('/club/plans', 'GET', 'club_plans');
        self::route('/club/plans', 'POST', 'club_plan_create');
        self::route('/club/plans/(?P<id>\d+)', 'PUT', 'club_plan_update');
        self::route('/club/plans/(?P<id>\d+)/archive', 'POST', 'club_plan_archive');
        self::route('/club/memberships', 'GET', 'club_memberships');
        self::route('/club/memberships', 'POST', 'club_membership_create');
        self::route('/club/payments', 'GET', 'club_payments');
        self::route('/club/payments', 'POST', 'club_payment_create');
        self::route('/club/attendance', 'GET', 'club_attendance');
        self::route('/club/attendance', 'POST', 'club_attendance_create');
        self::route('/club/staff', 'GET', 'club_staff');
        self::route('/club/staff', 'POST', 'club_staff_create');
        self::route('/club/staff/(?P<id>\d+)', 'PUT', 'club_staff_update');
        self::route('/club/payroll', 'GET', 'club_payroll');
        self::route('/club/payroll', 'POST', 'club_payroll_create');
        self::route('/club/payroll/accounts', 'GET', 'club_payroll_accounts');
        self::route('/club/payroll/(?P<id>\d+)/paid', 'POST', 'club_payroll_paid');
        self::route('/club/memberships/(?P<id>\d+)/freeze', 'POST', 'club_membership_freeze');
        self::route('/club/memberships/(?P<id>\d+)/cancel', 'POST', 'club_membership_cancel');
        self::route('/club/collections', 'GET', 'club_collections');
        self::route('/club/collections', 'POST', 'club_collections_create');
        self::route('/club/collections/(?P<id>\d+)', 'PUT', 'club_collections_update');
        self::route('/club/collections/(?P<id>\d+)', 'DELETE', 'club_collections_delete');
        self::route('/club/sports', 'GET', 'club_sports');
        self::route('/club/sports', 'POST', 'club_sports_create');
        self::route('/club/sports/(?P<id>\d+)', 'PUT', 'club_sports_update');
        self::route('/club/sports/(?P<id>\d+)', 'DELETE', 'club_sports_delete');
        self::route('/club/phonebook', 'GET', 'club_phonebook');
        self::route('/club/phonebook', 'POST', 'club_phonebook_create');
        self::route('/club/phonebook/(?P<id>\d+)', 'PUT', 'club_phonebook_update');
        self::route('/club/phonebook/(?P<id>\d+)', 'DELETE', 'club_phonebook_delete');
        self::route('/club/phonebook/bulk', 'POST', 'club_phonebook_bulk');
        self::route('/club/phonebook/import', 'POST', 'club_phonebook_import');
        self::route('/club/phonebook/sms/send', 'POST', 'club_phonebook_sms_send');
        self::route('/club/finance', 'GET', 'club_finance');
        self::route('/club/finance/(?P<id>\d+)/void', 'POST', 'club_finance_void');
        self::route('/club/expenses', 'POST', 'club_expense_create');
        self::route('/club/finance/cash-removal', 'POST', 'club_cash_removal');
        self::route('/club/cards/recharge', 'POST', 'club_card_recharge');
        self::route('/club/pos', 'POST', 'club_pos_create');
        self::route('/club/reports', 'GET', 'club_reports');
        self::route('/club/settings', 'GET', 'club_settings');
        self::route('/club/settings', 'PUT', 'club_settings_update');
        self::route('/club/sms/log', 'GET', 'club_sms_log');
        self::route('/club/sms/send', 'POST', 'club_sms_send');
        self::route('/club/users', 'GET', 'club_users');
        self::route('/club/users', 'POST', 'club_user_create');
        self::route('/club/users/(?P<id>\d+)', 'PUT', 'club_user_update');

        // پل سخت‌افزار: جفت‌سازی مدیر، زمان سرور، فهرست اعضا و رخدادهای تردد
        self::route('/bridge/pair-token', 'POST', 'bridge_pair_token');
        self::route('/bridge/pair', 'POST', 'bridge_pair', true);
        self::route('/bridge/time', 'GET', 'bridge_time');
        self::route('/bridge/access-list', 'GET', 'bridge_access_list');
        self::route('/bridge/attendance', 'GET', 'bridge_attendance_list');
        self::route('/bridge/attendance', 'POST', 'bridge_attendance');
        self::route('/bridge/attendance-from-zkteco', 'POST', 'bridge_attendance_from_zkteco');

        // به‌روزرسانی
        self::route('/update-check', 'GET', 'update_check');
    }

    private static function route($path, $method, $callback, $public = false) {
        register_rest_route(self::NS, $path, array(
            'methods'             => $method,
            'callback'            => array(__CLASS__, $callback),
            'permission_callback' => $public ? '__return_true' : array('WSM_Permissions', 'check_request'),
        ));
    }

    /** Prevent browser and intermediary caches from retaining any WSM REST response. */
    public static function disable_wsm_rest_caching($response, $server, $request) {
        if (!$request || !method_exists($request, 'get_route')) { return $response; }
        $route = '/' . ltrim((string) $request->get_route(), '/');
        $prefix = '/' . trim(self::NS, '/') . '/';
        if (strpos($route, $prefix) !== 0 && rtrim($route, '/') !== rtrim($prefix, '/')) { return $response; }

        if (!in_array(strtoupper((string) $request->get_method()), array('GET', 'HEAD'), true)) {
            self::invalidate_stats_cache();
        }

        $cache_control = 'no-cache, no-store, must-revalidate, max-age=0';
        if (is_object($response) && method_exists($response, 'header')) {
            $response->header('Cache-Control', $cache_control);
            $response->header('Pragma', 'no-cache');
            $response->header('Expires', '0');
        }
        return $response;
    }

    /** Arm a JSON-only shutdown response for fatal errors inside app-init. */
    private static function arm_app_init_shutdown($request) {
        $expected_route = '/' . trim(self::NS, '/') . '/app-init';
        if (!$request || !method_exists($request, 'get_route') ||
            (string) $request->get_route() !== $expected_route ||
            strtoupper((string) $request->get_method()) !== 'GET' ||
            self::$app_init_shutdown_armed) {
            return;
        }

        self::$app_init_shutdown_armed = true;
        self::$app_init_auth_verified = false;
        self::$app_init_output_level = function_exists('ob_get_level') ? ob_get_level() : 0;
        if (!headers_sent()) {
            header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0', true);
            header('Pragma: no-cache', true);
            header('Expires: 0', true);
        }
        if (function_exists('register_shutdown_function')) {
            register_shutdown_function(array(__CLASS__, 'handle_app_init_shutdown'));
        }
        if (function_exists('ob_start')) {
            @ob_start();
        }
        // Free this small reserve before JSON encoding if PHP runs out of memory.
        try {
            self::$app_init_memory_reserve = str_repeat('x', 262144);
        } catch (Throwable $exception) {
            self::$app_init_memory_reserve = null;
        }
    }

    /** Convert a fatal app-init shutdown into the normal WordPress REST error shape. */
    public static function handle_app_init_shutdown() {
        if (!self::$app_init_shutdown_armed || !function_exists('error_get_last')) {
            return;
        }
        $last_error = error_get_last();
        if (!is_array($last_error) || !isset($last_error['type']) || !in_array((int) $last_error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR), true)) {
            return;
        }

        self::$app_init_memory_reserve = null;
        $message = self::$app_init_auth_verified && isset($last_error['message'])
            ? (string) $last_error['message']
            : 'Fatal server error while validating the authenticated app request.';

        // Keep PHP's displayed fatal HTML and any nested buffers from corrupting JSON.
        if (function_exists('ob_get_level') && function_exists('ob_clean') && self::$app_init_output_level !== null) {
            while (ob_get_level() > self::$app_init_output_level + 1) {
                if (!@ob_end_flush()) { break; }
            }
            if (ob_get_level() > self::$app_init_output_level) {
                @ob_clean();
            }
        }
        if (!headers_sent()) {
            if (function_exists('status_header')) {
                status_header(500);
            } elseif (function_exists('http_response_code')) {
                http_response_code(500);
            }
            header('Content-Type: application/json; charset=UTF-8', true);
            header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0', true);
            header('Pragma: no-cache', true);
            header('Expires: 0', true);
        }

        $body = array(
            'code'    => 'wsm_app_init_fatal',
            'message' => $message,
            'data'    => array('status' => 500),
        );
        $json = function_exists('wp_json_encode') ? wp_json_encode($body) : json_encode($body);
        if (!is_string($json) || $json === '') {
            $json = '{"code":"wsm_app_init_fatal","message":"Fatal server error in app-init","data":{"status":500}}';
        }
        echo $json;
    }

    /**
     * Authentication for the aggregate bootstrap endpoint. The normal permission
     * callback verifies Bearer, HMAC, device and account state before returning the
     * expected unmapped-route error; only that exact error is accepted here.
     */
    public static function app_init_permission($request) {
        self::arm_app_init_shutdown($request);
        $expected_route = '/' . trim(self::NS, '/') . '/app-init';
        if (!$request || !method_exists($request, 'get_route') ||
            (string) $request->get_route() !== $expected_route ||
            strtoupper((string) $request->get_method()) !== 'GET') {
            return new WP_Error('wsm_permission_unmapped', 'برای این مسیر مجوز دستگاه تعریف نشده است.', array('status' => 403));
        }

        $permission = WSM_Permissions::check_request($request);
        if (WSM_Permissions::current_device()) {
            self::$app_init_auth_verified = true;
        }
        if (is_wp_error($permission) && $permission->get_error_code() === 'wsm_permission_unmapped') {
            return true;
        }
        return $permission;
    }

    /** Cache store-wide aggregates; dashboard callers can use a short, epoch-scoped TTL. */
    private static function cached_stats($cache_key, $callback, $expiration = 900) {
        $expiration = max(1, absint($expiration));
        $cached = wp_cache_get($cache_key, 'wsm');
        if (!is_array($cached)) {
            $cached = get_transient($cache_key);
            if (is_array($cached)) {
                wp_cache_set($cache_key, $cached, 'wsm', $expiration);
            }
        }
        if (is_array($cached)) {
            return $cached;
        }

        $result = call_user_func($callback);
        if (!is_wp_error($result) && is_array($result)) {
            wp_cache_set($cache_key, $result, 'wsm', $expiration);
            set_transient($cache_key, $result, $expiration);
        }
        return $result;
    }

    /**
     * Cache selected authenticated, read-only GET payloads for fifteen minutes.
     * Keys are scoped to site + device + route + complete request params + a write epoch.
     * Delta sync, orders, invoices, finance, and per-user data deliberately do not use this cache.
     */
    private static function cached_rest_get($bucket, $route, $params, $callback, $rate_checked = false) {
        $device_id = WSM_Permissions::current_device_id();
        if ($device_id < 1 || !is_array($params)) {
            return call_user_func($callback);
        }

        $bucket = sanitize_key($bucket);
        if (!in_array($bucket, array('products', 'settings'), true)) {
            return call_user_func($callback);
        }
        if (!$rate_checked) {
            $rate_limit = self::check_rest_read_rate_limit($bucket, $device_id);
            if (is_wp_error($rate_limit)) { return $rate_limit; }
        }
        $epoch_option = 'wsm_rest_' . $bucket . '_cache_epoch_v1';
        $context = array(
            'version' => 2,
            'blog_id' => function_exists('get_current_blog_id') ? (int) get_current_blog_id() : 1,
            'device_id' => $device_id,
            'route' => (string) $route,
            'params' => $params,
            'epoch' => max(1, absint(get_option($epoch_option, 1))),
        );
        $encoded = wp_json_encode($context);
        if (!is_string($encoded) || $encoded === '') {
            return call_user_func($callback);
        }

        $cache_key = 'wsm_rest_get_' . $bucket . '_v2_' . md5($encoded);
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            return $cached;
        }

        $result = call_user_func($callback);
        if (!is_wp_error($result) && is_array($result)) {
            set_transient($cache_key, $result, 900);
        }
        return $result;
    }

    /**
     * Apply a generous per-device request ceiling to the selected expensive read routes.
     * Use a persistent object cache when configured; otherwise use a short-lived transient.
     * Login/recovery have separate, stricter IP-based protections in WSM_Auth/WSM_Security.
     */
    private static function check_rest_read_rate_limit($bucket, $device_id) {
        $limit = 300;
        $window = 60;
        $now = time();
        $window_start = (int) (floor($now / $window) * $window);
        $blog_id = function_exists('get_current_blog_id') ? (int) get_current_blog_id() : 1;
        $bucket = sanitize_key($bucket);
        $identity = $blog_id . '|' . (int) $device_id . '|' . $bucket . '|' . $window_start;
        $key = 'wsm_rest_read_rl_v1_' . md5($identity);

        if (function_exists('wp_using_ext_object_cache') && wp_using_ext_object_cache()) {
            $added = wp_cache_add($key, 1, 'wsm_rest_rate_limit', $window + 5);
            if ($added) { return true; }
            $count = wp_cache_incr($key, 1, 'wsm_rest_rate_limit');
            if ($count === false) {
                wp_cache_set($key, 1, 'wsm_rest_rate_limit', $window + 5);
                return true;
            }
        } else {
            $count = absint(get_transient($key));
            if ($count >= $limit) {
                $count = $limit + 1;
            } else {
                $count++;
                $remaining = max(1, $window_start + $window + 5 - $now);
                set_transient($key, $count, $remaining);
            }
        }

        if ((int) $count > $limit) {
            $retry_after = max(1, $window_start + $window - $now);
            return new WP_Error(
                'wsm_rest_rate_limited',
                'تعداد درخواست‌های این دستگاه در یک دقیقه از حد مجاز بیشتر شد. کمی بعد دوباره تلاش کنید.',
                array('status' => 429, 'retry_after' => $retry_after)
            );
        }
        return true;
    }

    /** Rotate a read-cache namespace after a relevant write; old transients expire naturally. */
    private static function advance_rest_cache_epoch($bucket) {
        $bucket = sanitize_key($bucket);
        if (!in_array($bucket, array('products', 'settings'), true)) { return; }
        $option = 'wsm_rest_' . $bucket . '_cache_epoch_v1';
        $next = max(1, absint(get_option($option, 1))) + 1;
        if ($next > 2147483640) { $next = 1; }
        update_option($option, $next, false);
    }

    /** Evict product/category/expiry GET snapshots after a WooCommerce product write. */
    public static function invalidate_rest_product_cache($arg1 = null, $arg2 = null, $arg3 = null, $arg4 = null, $arg5 = null, $arg6 = null) {
        self::advance_rest_cache_epoch('products');
        if (class_exists('WSM_Products') && method_exists('WSM_Products', 'invalidate_pos_cache')) {
            WSM_Products::invalidate_pos_cache();
        }
    }

    /** Evict cached settings only when one of the settings they contain changes. */
    public static function invalidate_rest_settings_cache_option($option, $old_value = null, $new_value = null) {
        $option = (string) $option;
        if (in_array($option, array('wsm_settings', 'woocommerce_currency', 'admin_email', 'woocommerce_notify_low_stock_amount'), true)) {
            self::advance_rest_cache_epoch('settings');
        }
        if ($option === 'woocommerce_currency') {
            // Currency symbols are embedded in product, POS, order, and report display payloads.
            self::invalidate_rest_product_cache();
            self::invalidate_stats_cache();
        } elseif ($option === 'woocommerce_notify_low_stock_amount') {
            self::invalidate_stats_cache();
        }
    }

    /** Route every REST-side stats eviction through the shared generation-aware invalidator. */
    public static function invalidate_stats_cache($arg1 = null, $arg2 = null, $arg3 = null, $arg4 = null) {
        if (class_exists('WSM_Reports') && is_callable(array('WSM_Reports', 'flush_sale_caches'))) {
            return WSM_Reports::flush_sale_caches();
        }
        return false;
    }

    /** Daily bounded retention for terminal inbox rows; never delete unprocessed received work. */
    public static function cleanup_sync_logs() {
        global $wpdb;
        $table = $wpdb->prefix . 'wsm_sync_logs';
        $table_sql = '`' . str_replace('`', '``', $table) . '`';
        $now = self::sync_now();
        $batch_size = 1000;
        $max_batches = 10;
        $deleted_total = 0;

        for ($batch = 0; $batch < $max_batches; $batch++) {
            $sql = $wpdb->prepare(
                'DELETE FROM ' . $table_sql . " WHERE status IN (%s, %s) AND created_at < DATE_SUB(%s, INTERVAL 30 DAY) ORDER BY id ASC LIMIT %d",
                'processed', 'failed', $now, $batch_size
            );
            $deleted = $wpdb->query($sql);
            if ($deleted === false) {
                error_log('[WSM Sync] Daily retention cleanup could not delete old terminal rows.');
                return $deleted_total;
            }
            $deleted_total += (int) $deleted;
            if ((int) $deleted < $batch_size) {
                break;
            }
        }
        return $deleted_total;
    }

    private static function body($request) {
        $json = $request->get_json_params();
        if (is_array($json)) {
            return $json;
        }
        $body = $request->get_body_params();
        return is_array($body) ? $body : array();
    }

    private static function id($request) {
        $value = $request->get_param('id');
        return is_scalar($value) ? (int) $value : 0;
    }

    private static function scalar_param($request, $key, $default = '') {
        $value = $request->get_param($key);
        return is_scalar($value) ? (string) $value : (string) $default;
    }

    /** Authenticated outbox access; the processor enforces grants for each non-message action. */
    public static function sync_bulk_permission($request) {
        $checked = WSM_Permissions::check_request($request);
        if (is_wp_error($checked) && $checked->get_error_code() !== 'wsm_device_permission_denied') { return $checked; }
        if ($checked === false) { return new WP_Error('wsm_sync_bulk_auth_failed', 'احراز هویت درخواست همگام‌سازی ناموفق بود.', array('status' => 403)); }
        $device = WSM_Permissions::current_device();
        if (!$device) { return new WP_Error('wsm_sync_device_required', 'دستگاه احراز هویت‌شده در دسترس نیست.', array('status' => 401)); }
        $rate_limit = self::check_rest_read_rate_limit('sync', WSM_Permissions::current_device_id());
        if (is_wp_error($rate_limit)) { return $rate_limit; }
        return true;
    }

    /** Messages intentionally bypass the generic unknown-route map only after Bearer/HMAC/account validation. */
    public static function messages_permission($request) {
        $checked = WSM_Permissions::check_request($request);
        if (is_wp_error($checked) && $checked->get_error_code() !== 'wsm_permission_unmapped') { return $checked; }
        if ($checked === false) { return new WP_Error('wsm_message_auth_failed', 'احراز هویت پیام‌رسان ناموفق بود.', array('status' => 403)); }
        $device = WSM_Permissions::current_device();
        if (!$device || empty($device->user_id)) { return new WP_Error('wsm_message_device_required', 'دستگاه احرازشده برای پیام‌رسان در دسترس نیست.', array('status' => 401)); }
        $rate_limit = self::check_rest_read_rate_limit('messages', WSM_Permissions::current_device_id());
        if (is_wp_error($rate_limit)) { return $rate_limit; }
        return true;
    }

    private static function messages_current_user_id() {
        $device = WSM_Permissions::current_device();
        return $device && isset($device->user_id) ? absint($device->user_id) : 0;
    }

    /** Oversight is restricted to the literal WordPress administrator role, not app presets or device grants. */
    private static function messages_is_wordpress_administrator() {
        $user_id = self::messages_current_user_id();
        $user = $user_id ? get_userdata($user_id) : false;
        return $user && in_array('administrator', (array) $user->roles, true);
    }

    private static function messages_table_name() {
        global $wpdb;
        return $wpdb->prefix . 'wsm_messages';
    }

    private static function messages_audit_table_name() {
        global $wpdb;
        return $wpdb->prefix . 'wsm_message_audit';
    }

    /** Add moderation tombstones and an audit table without creating or editing plugin files. */
    private static function ensure_message_moderation_schema() {
        static $schema_status = null;
        if ($schema_status === true) { return true; }
        if (is_wp_error($schema_status)) { return $schema_status; }
        global $wpdb;
        $messages_table = self::messages_table_name();
        $messages_sql = '`' . str_replace('`', '``', $messages_table) . '`';
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($messages_table)));
        if ($exists !== $messages_table && class_exists('WSM_Core') && is_callable(array('WSM_Core', 'ensure_messages_table'))) {
            WSM_Core::ensure_messages_table();
            $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($messages_table)));
        }
        if ($exists !== $messages_table) {
            $schema_status = new WP_Error('wsm_message_schema_unavailable', 'جدول پیام‌های داخلی در دسترس نیست.', array('status' => 500));
            return $schema_status;
        }
        if (get_option('wsm_message_moderation_schema_version') === '1') {
            $deleted_at_column = $wpdb->get_var("SHOW COLUMNS FROM {$messages_sql} LIKE 'deleted_at'");
            $deleted_by_column = $wpdb->get_var("SHOW COLUMNS FROM {$messages_sql} LIKE 'deleted_by'");
            $audit_table = self::messages_audit_table_name();
            $audit_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($audit_table)));
            if ($deleted_at_column === 'deleted_at' && $deleted_by_column === 'deleted_by' && $audit_exists === $audit_table) {
                $schema_status = true;
                return true;
            }
        }
        foreach (array(
            'deleted_at' => "ALTER TABLE {$messages_sql} ADD COLUMN deleted_at datetime NULL DEFAULT NULL",
            'deleted_by' => "ALTER TABLE {$messages_sql} ADD COLUMN deleted_by bigint(20) unsigned NULL DEFAULT NULL",
        ) as $column_name => $alter_sql) {
            $column = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM {$messages_sql} LIKE %s", $column_name));
            if ($column !== $column_name && $wpdb->query($alter_sql) === false) {
                // A concurrent request may have added the same column after our initial check.
                $column = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM {$messages_sql} LIKE %s", $column_name));
                if ($column !== $column_name) {
                    $schema_status = new WP_Error('wsm_message_moderation_schema_failed', 'ساختار حذف امن پیام‌ها آماده نشد.', array('status' => 500));
                    return $schema_status;
                }
            }
        }
        if (!function_exists('dbDelta') && defined('ABSPATH') && is_file(ABSPATH . 'wp-admin/includes/upgrade.php')) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }
        if (!function_exists('dbDelta')) {
            $schema_status = new WP_Error('wsm_message_audit_schema_failed', 'ساختار گزارش ممیزی پیام‌ها آماده نشد.', array('status' => 500));
            return $schema_status;
        }
        $audit_table = self::messages_audit_table_name();
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$audit_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            message_uuid varchar(36) NOT NULL DEFAULT '',
            actor_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            action varchar(20) NOT NULL,
            item_count int(10) unsigned NOT NULL DEFAULT 0,
            acted_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY message_uuid (message_uuid),
            KEY actor_action_time (actor_user_id, action, acted_at)
        ) ENGINE=InnoDB {$charset};");
        $audit_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($audit_table)));
        $deleted_at_column = $wpdb->get_var("SHOW COLUMNS FROM {$messages_sql} LIKE 'deleted_at'");
        $deleted_by_column = $wpdb->get_var("SHOW COLUMNS FROM {$messages_sql} LIKE 'deleted_by'");
        if ($audit_exists !== $audit_table || $deleted_at_column !== 'deleted_at' || $deleted_by_column !== 'deleted_by') {
            $schema_status = new WP_Error('wsm_message_audit_schema_failed', 'ساختار حذف و گزارش ممیزی پیام‌ها کامل نشد.', array('status' => 500));
            return $schema_status;
        }
        update_option('wsm_message_moderation_schema_version', '1', false);
        $schema_status = true;
        return true;
    }

    private static function record_message_audit($action, $message_uuid = '', $item_count = 0) {
        global $wpdb;
        $user_id = self::messages_current_user_id();
        if (!$user_id) { return false; }
        return $wpdb->insert(self::messages_audit_table_name(), array(
            'message_uuid' => (string) $message_uuid,
            'actor_user_id' => $user_id,
            'action' => sanitize_key((string) $action),
            'item_count' => max(0, absint($item_count)),
            'acted_at' => current_time('mysql'),
        ), array('%s', '%d', '%s', '%d', '%s')) === 1;
    }

    private static function messages_deleted_uuids() {
        global $wpdb;
        if (!WSM_Club_Operations::ensure_ticket_message_schema()) { return new WP_Error('wsm_ticket_schema_unavailable', 'ساختار تیکت‌ها آماده نیست.', array('status' => 500)); }
        $table_sql = '`' . str_replace('`', '``', self::messages_table_name()) . '`';
        $note_filter = WSM_Permissions::ticket_can('wsm_ticket_internal_note') ? '' : ' AND is_internal_note=0';
        $rows = $wpdb->get_col("SELECT uuid FROM {$table_sql} WHERE deleted_at IS NOT NULL" . $note_filter);
        if (!empty($wpdb->last_error)) {
            return new WP_Error('wsm_message_tombstone_lookup_failed', 'دریافت وضعیت پیام‌های حذف‌شده انجام نشد.', array('status' => 500));
        }
        return array_values(array_filter(array_map('strval', (array) $rows)));
    }

    private static function messages_unread_count($user_id) {
        global $wpdb;
        $table_sql = '`' . str_replace('`', '``', self::messages_table_name()) . '`';
        $note_filter = WSM_Permissions::ticket_can('wsm_ticket_internal_note', (int) $user_id) ? '' : ' AND is_internal_note=0';
        $direct = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table_sql} WHERE deleted_at IS NULL AND receiver_id = %d AND sender_id <> %d AND is_read = 0" . $note_filter,
            (int) $user_id, (int) $user_id
        ));
        if (!empty($wpdb->last_error)) {
            return new WP_Error('wsm_message_unread_count_failed', 'شمارش پیام‌های خوانده‌نشده انجام نشد.', array('status' => 500));
        }
        $groups = $wpdb->get_results("SELECT sender_id, read_by FROM {$table_sql} WHERE deleted_at IS NULL AND receiver_id = 0" . $note_filter, ARRAY_A);
        if (!empty($wpdb->last_error)) {
            return new WP_Error('wsm_message_unread_count_failed', 'شمارش پیام‌های گروهی خوانده‌نشده انجام نشد.', array('status' => 500));
        }
        $group_unread = 0;
        foreach ((array) $groups as $row) {
            if (absint($row['sender_id']) === (int) $user_id) { continue; }
            $read_by = json_decode(isset($row['read_by']) ? (string) $row['read_by'] : '', true);
            $read_by = is_array($read_by) ? array_map('absint', $read_by) : array();
            if (!in_array((int) $user_id, $read_by, true)) { $group_unread++; }
        }
        return $direct + $group_unread;
    }

    private static function messages_admin_inbox_page($limit, $before_id) {
        global $wpdb;
        // This also ensures the existing thread columns are upgraded before the admin query.
        $ready = WSM_Club_Operations::list_internal_messages(1);
        if (is_wp_error($ready)) { return $ready; }
        $table_sql = '`' . str_replace('`', '``', self::messages_table_name()) . '`';
        $columns = 'id, uuid, thread_uuid, reply_to_uuid, sender_id, receiver_id, subject, message, status, is_internal_note, created_at';
        if ((int) $before_id > 0) {
            $sql = $wpdb->prepare("SELECT {$columns} FROM {$table_sql} WHERE deleted_at IS NULL AND id < %d ORDER BY id DESC LIMIT %d", (int) $before_id, (int) $limit + 1);
        } else {
            $sql = $wpdb->prepare("SELECT {$columns} FROM {$table_sql} WHERE deleted_at IS NULL ORDER BY id DESC LIMIT %d", (int) $limit + 1);
        }
        $rows = $wpdb->get_results($sql, ARRAY_A);
        if (!empty($wpdb->last_error)) {
            return new WP_Error('wsm_message_admin_read_failed', 'دریافت صفحهٔ نظارت پیام‌ها انجام نشد.', array('status' => 500));
        }
        $has_more = count((array) $rows) > (int) $limit;
        if ($has_more) { array_pop($rows); }
        $user_ids = array();
        foreach ((array) $rows as $row) {
            $user_ids[] = absint($row['sender_id']);
            if (absint($row['receiver_id']) > 0) { $user_ids[] = absint($row['receiver_id']); }
        }
        $names = array();
        foreach (array_unique($user_ids) as $id) {
            $user = get_userdata((int) $id);
            $names[(int) $id] = $user ? (string) $user->display_name : 'کاربر ' . (int) $id;
        }
        $items = array();
        foreach ((array) $rows as $row) {
            $sender_id = absint($row['sender_id']);
            $receiver_id = absint($row['receiver_id']);
            $uuid = strtolower((string) $row['uuid']);
            $thread_uuid = isset($row['thread_uuid']) && preg_match('/^[a-f0-9-]{36}$/i', (string) $row['thread_uuid']) ? strtolower((string) $row['thread_uuid']) : $uuid;
            $reply_uuid = isset($row['reply_to_uuid']) && preg_match('/^[a-f0-9-]{36}$/i', (string) $row['reply_to_uuid']) ? strtolower((string) $row['reply_to_uuid']) : '';
            $items[] = array(
                'id' => absint($row['id']), 'uuid' => $uuid, 'thread_uuid' => $thread_uuid, 'reply_to_uuid' => $reply_uuid,
                'sender_id' => $sender_id, 'receiver_id' => $receiver_id, 'subject' => (string) $row['subject'],
                'message' => (string) $row['message'], 'status' => in_array((string)($row['status'] ?? 'open'),array('open','in_progress','resolved'),true)?(string)($row['status'] ?? 'open'):'open',
                'is_internal_note' => !empty($row['is_internal_note']), 'is_read' => false, 'created_at' => (string) $row['created_at'], 
                'sender_name' => isset($names[$sender_id]) ? $names[$sender_id] : 'کاربر ' . $sender_id,
                'receiver_name' => $receiver_id === 0 ? 'همهٔ کارمندان' : (isset($names[$receiver_id]) ? $names[$receiver_id] : 'کاربر ' . $receiver_id),
            );
        }
        if (!self::record_message_audit('view_all', '', count($items))) {
            return new WP_Error('wsm_message_audit_write_failed', 'ثبت دسترسی مدیر به پیام‌ها در گزارش ممیزی انجام نشد.', array('status' => 500));
        }
        $user_id = self::messages_current_user_id();
        $unread = self::messages_unread_count($user_id);
        if (is_wp_error($unread)) { return $unread; }
        return array(
            'items' => $items, 'unread_count' => $unread, 'is_wordpress_admin' => true,
            'view_mode' => 'admin', 'has_more' => $has_more,
            'next_before_id' => $has_more && $items ? (int) end($items)['id'] : 0,
        );
    }

    public static function messages_send($request) {
        $payload = self::body($request);
        $is_internal_note = isset($payload['is_internal_note']) && rest_sanitize_boolean($payload['is_internal_note']);
        $required_capability = $is_internal_note ? 'wsm_ticket_internal_note' : 'wsm_ticket_reply';
        if (!WSM_Permissions::ticket_can($required_capability)) {
            return new WP_Error('wsm_ticket_reply_forbidden', 'مجوز ارسال این پیام یا یادداشت داخلی را ندارید.', array('status' => 403, 'capability' => $required_capability));
        }
        $schema = self::ensure_message_moderation_schema();
        if (is_wp_error($schema)) { return $schema; }
        if (!WSM_Club_Operations::ensure_ticket_message_schema()) {
            return new WP_Error('wsm_ticket_schema_unavailable', 'ساختار تیکت‌ها آماده نیست.', array('status' => 500));
        }
        $reply_uuid = isset($payload['reply_to_uuid']) && is_scalar($payload['reply_to_uuid']) ? strtolower(trim((string) $payload['reply_to_uuid'])) : '';
        if ($reply_uuid !== '' && preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i', $reply_uuid)) {
            $schema = self::ensure_message_moderation_schema();
            if (is_wp_error($schema)) { return $schema; }
            global $wpdb;
            $table_sql = '`' . str_replace('`', '``', self::messages_table_name()) . '`';
            $deleted = $wpdb->get_var($wpdb->prepare("SELECT deleted_at FROM {$table_sql} WHERE uuid = %s LIMIT 1", $reply_uuid));
            if (!empty($wpdb->last_error)) { return new WP_Error('wsm_message_reply_lookup_failed', 'بررسی پیام مورد پاسخ انجام نشد.', array('status' => 500)); }
            if ($deleted !== null) { return new WP_Error('wsm_message_reply_target_deleted', 'پاسخ به پیام حذف‌شده ممکن نیست.', array('status' => 404)); }
        }
        return WSM_Club_Operations::create_internal_message($payload);
    }

    public static function messages_inbox($request) {
        if (!WSM_Permissions::ticket_can('wsm_ticket_view')) {
            return new WP_Error('wsm_ticket_view_forbidden', 'مجوز مشاهدهٔ تیکت‌ها را ندارید.', array('status' => 403, 'capability' => 'wsm_ticket_view'));
        }
        $view_mode = strtolower(trim(self::scalar_param($request, 'view_mode', 'inbox')));
        if (!in_array($view_mode, array('', 'inbox', 'admin'), true)) {
            return new WP_Error('wsm_message_view_mode_invalid', 'حالت نمایش پیام‌ها معتبر نیست.', array('status' => 400));
        }
        $is_admin = self::messages_is_wordpress_administrator();
        if ($view_mode === 'admin' && (!$is_admin || !current_user_can('manage_options'))) {
            return new WP_Error('wsm_message_admin_view_forbidden', 'نمای نظارت پیام‌ها فقط برای مدیر WordPress دارای manage_options در دسترس است.', array('status' => 403));
        }
        $schema = self::ensure_message_moderation_schema();
        if (is_wp_error($schema)) { return $schema; }
        $limit = $request->get_param('limit');
        $limit = is_scalar($limit) ? max(1, min(200, absint($limit) ?: 100)) : 100;
        if ($view_mode === 'admin') {
            $before_raw = $request->get_param('before_id');
            if ($before_raw !== null && (!is_scalar($before_raw) || !preg_match('/^[0-9]+$/', (string) $before_raw))) {
                return new WP_Error('wsm_message_cursor_invalid', 'نشانگر صفحهٔ پیام‌ها معتبر نیست.', array('status' => 400));
            }
            $page = self::messages_admin_inbox_page($limit, $before_raw === null ? 0 : absint($before_raw));
            if (is_wp_error($page)) { return $page; }
            $deleted = self::messages_deleted_uuids();
            if (is_wp_error($deleted)) { return $deleted; }
            $page['deleted_uuids'] = $deleted;
            return $page;
        }
        $result = WSM_Club_Operations::list_internal_messages($limit);
        if (is_wp_error($result)) { return $result; }
        $user_id = self::messages_current_user_id();
        $deleted = self::messages_deleted_uuids();
        if (is_wp_error($deleted)) { return $deleted; }
        $deleted_map = array_fill_keys($deleted, true);
        $items = isset($result['items']) && is_array($result['items']) ? $result['items'] : array();
        $result['items'] = array_values(array_filter($items, function ($item) use ($user_id, $deleted_map) {
            if (!is_array($item) || empty($item['uuid']) || isset($deleted_map[(string) $item['uuid']])) { return false; }
            $sender_id = isset($item['sender_id']) ? absint($item['sender_id']) : 0;
            $receiver_id = isset($item['receiver_id']) ? absint($item['receiver_id']) : -1;
            return $sender_id === (int) $user_id || $receiver_id === (int) $user_id || $receiver_id === 0;
        }));
        $unread = self::messages_unread_count($user_id);
        if (is_wp_error($unread)) { return $unread; }
        $result['unread_count'] = $unread;
        $result['deleted_uuids'] = $deleted;
        $result['is_wordpress_admin'] = $is_admin;
        $result['view_mode'] = 'inbox';
        $result['has_more'] = false;
        return $result;
    }

    public static function messages_recipients($request) {
        if (!WSM_Permissions::ticket_can('wsm_ticket_reply')) {
            return new WP_Error('wsm_ticket_reply_forbidden', 'برای انتخاب گیرندهٔ پیام، مجوز پاسخ لازم است.', array('status' => 403, 'capability' => 'wsm_ticket_reply'));
        }
        $device = WSM_Permissions::current_device();
        return WSM_Club_Operations::list_internal_message_recipients($device && isset($device->user_id) ? (int) $device->user_id : 0);
    }

    public static function messages_status($request) {
        if (!WSM_Permissions::ticket_can('wsm_ticket_view') || !WSM_Permissions::ticket_can('wsm_ticket_close')) {
            return new WP_Error('wsm_ticket_status_forbidden', 'برای تغییر وضعیت تیکت، مجوز مشاهده و بستن لازم است.', array('status' => 403, 'capability' => 'wsm_ticket_close'));
        }
        $body = self::body($request);
        $thread_uuid = isset($body['thread_uuid']) && is_scalar($body['thread_uuid']) ? strtolower(trim((string) $body['thread_uuid'])) : '';
        $status = isset($body['status']) && is_scalar($body['status']) ? sanitize_key((string) $body['status']) : '';
        if (!preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i', $thread_uuid) || !in_array($status, array('open', 'in_progress', 'resolved'), true)) {
            return new WP_Error('wsm_ticket_status_invalid', 'شناسه یا وضعیت تیکت معتبر نیست.', array('status' => 400));
        }
        $schema = self::ensure_message_moderation_schema();
        if (is_wp_error($schema)) { return $schema; }
        if (!WSM_Club_Operations::ensure_ticket_message_schema()) {
            return new WP_Error('wsm_ticket_schema_unavailable', 'ساختار تیکت‌ها آماده نیست.', array('status' => 500));
        }
        global $wpdb;
        $table_sql = '`' . str_replace('`', '``', self::messages_table_name()) . '`';
        $root = $wpdb->get_row($wpdb->prepare("SELECT uuid,thread_uuid,sender_id,receiver_id,subject,is_internal_note FROM {$table_sql} WHERE uuid=%s AND deleted_at IS NULL LIMIT 1", $thread_uuid), ARRAY_A);
        if (!empty($wpdb->last_error)) { return new WP_Error('wsm_ticket_lookup_failed', 'بررسی تیکت انجام نشد.', array('status' => 500)); }
        if (!is_array($root)) { return new WP_Error('wsm_ticket_not_found', 'تیکت پیدا نشد.', array('status' => 404)); }
        $root_thread = isset($root['thread_uuid']) && preg_match('/^[a-f0-9-]{36}$/i', (string) $root['thread_uuid']) ? strtolower((string) $root['thread_uuid']) : strtolower((string) $root['uuid']);
        if ($root_thread !== strtolower((string) $root['uuid'])) {
            $root = $wpdb->get_row($wpdb->prepare("SELECT uuid,thread_uuid,sender_id,receiver_id,subject,is_internal_note FROM {$table_sql} WHERE uuid=%s AND deleted_at IS NULL LIMIT 1", $root_thread), ARRAY_A);
            if (!empty($wpdb->last_error)) { return new WP_Error('wsm_ticket_lookup_failed', 'بررسی تیکت انجام نشد.', array('status' => 500)); }
            if (!is_array($root)) { return new WP_Error('wsm_ticket_not_found', 'تیکت پیدا نشد.', array('status' => 404)); }
        }
        $user_id = self::messages_current_user_id();
        $is_admin = WSM_Permissions::ticket_is_admin_user($user_id);
        $is_support = (bool) preg_match('/^\\[athlete_support:[0-9]+:[a-f0-9]{16}\\]/i', (string) $root['subject']);
        if (!empty($root['is_internal_note']) && !WSM_Permissions::ticket_can('wsm_ticket_internal_note')) {
            return new WP_Error('wsm_ticket_not_found', 'تیکت پیدا نشد.', array('status' => 404));
        }
        if ($is_support && !WSM_Permissions::ticket_can('wsm_ticket_athlete')) {
            return new WP_Error('wsm_ticket_athlete_forbidden', 'مجوز دسترسی به تیکت‌های ورزشکاران را ندارید.', array('status' => 403, 'capability' => 'wsm_ticket_athlete'));
        }
        if (!$is_support && !$is_admin && (int) $root['receiver_id'] !== 0 && (int) $root['sender_id'] !== $user_id && (int) $root['receiver_id'] !== $user_id) {
            return new WP_Error('wsm_ticket_thread_forbidden', 'شما عضو این تیکت نیستید.', array('status' => 403));
        }
        if ($is_support) {
            $updated = $wpdb->query($wpdb->prepare(
                "UPDATE {$table_sql} SET status=%s WHERE subject=%s AND receiver_id=%d AND deleted_at IS NULL",
                $status, (string) $root['subject'], (int) $root['receiver_id']
            ));
        } else {
            $updated = $wpdb->query($wpdb->prepare(
                "UPDATE {$table_sql} SET status=%s WHERE (thread_uuid=%s OR (thread_uuid='' AND uuid=%s)) AND deleted_at IS NULL",
                $status, $root_thread, $root_thread
            ));
        }
        if ($updated === false) { return new WP_Error('wsm_ticket_status_update_failed', 'ذخیرهٔ وضعیت تیکت انجام نشد.', array('status' => 500)); }
        if ($updated > 0) { self::record_message_audit('status', $root_thread, (int) $updated); }
        return array('thread_uuid' => $root_thread, 'status' => $status, 'updated' => (int) $updated);
    }

    public static function messages_contact($request) {
        if (!WSM_Permissions::ticket_can('wsm_ticket_view')) {
            return new WP_Error('wsm_ticket_view_forbidden', 'مجوز مشاهدهٔ تیکت‌ها را ندارید.', array('status' => 403, 'capability' => 'wsm_ticket_view'));
        }
        $thread_uuid = is_scalar($request->get_param('thread_uuid')) ? strtolower(trim((string) $request->get_param('thread_uuid'))) : '';
        if (!preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i', $thread_uuid)) {
            return new WP_Error('wsm_ticket_contact_invalid', 'شناسهٔ تیکت معتبر نیست.', array('status' => 400));
        }
        $schema = self::ensure_message_moderation_schema();
        if (is_wp_error($schema)) { return $schema; }
        if (!WSM_Club_Operations::ensure_ticket_message_schema()) {
            return new WP_Error('wsm_ticket_schema_unavailable', 'ساختار تیکت‌ها آماده نیست.', array('status' => 500));
        }
        global $wpdb;
        $table_sql = '`' . str_replace('`', '``', self::messages_table_name()) . '`';
        $root = $wpdb->get_row($wpdb->prepare("SELECT uuid,thread_uuid,sender_id,receiver_id,subject,is_internal_note FROM {$table_sql} WHERE uuid=%s AND deleted_at IS NULL LIMIT 1", $thread_uuid), ARRAY_A);
        if (!empty($wpdb->last_error)) { return new WP_Error('wsm_ticket_contact_lookup_failed', 'خواندن اطلاعات مخاطب انجام نشد.', array('status' => 500)); }
        if (!is_array($root)) { return new WP_Error('wsm_ticket_not_found', 'تیکت پیدا نشد.', array('status' => 404)); }
        $root_thread = isset($root['thread_uuid']) && preg_match('/^[a-f0-9-]{36}$/i', (string) $root['thread_uuid']) ? strtolower((string) $root['thread_uuid']) : strtolower((string) $root['uuid']);
        if ($root_thread !== strtolower((string) $root['uuid'])) {
            $root = $wpdb->get_row($wpdb->prepare("SELECT uuid,thread_uuid,sender_id,receiver_id,subject,is_internal_note FROM {$table_sql} WHERE uuid=%s AND deleted_at IS NULL LIMIT 1", $root_thread), ARRAY_A);
            if (!empty($wpdb->last_error)) { return new WP_Error('wsm_ticket_contact_lookup_failed', 'خواندن اطلاعات مخاطب انجام نشد.', array('status' => 500)); }
            if (!is_array($root)) { return new WP_Error('wsm_ticket_not_found', 'تیکت پیدا نشد.', array('status' => 404)); }
        }
        if (!empty($root['is_internal_note']) && !WSM_Permissions::ticket_can('wsm_ticket_internal_note')) {
            return new WP_Error('wsm_ticket_not_found', 'تیکت پیدا نشد.', array('status' => 404));
        }
        $user_id = self::messages_current_user_id();
        $is_admin = WSM_Permissions::ticket_is_admin_user($user_id);
        $is_support = (bool) preg_match('/^\\[athlete_support:[0-9]+:[a-f0-9]{16}\\]/i', (string) $root['subject']);
        if ($is_support) { return new WP_Error('wsm_ticket_contact_support_route', 'برای مشخصات ورزشکار از نمای پشتیبانی استفاده کنید.', array('status' => 400)); }
        $sender_id = absint($root['sender_id']);
        $receiver_id = absint($root['receiver_id']);
        if (!$is_admin && $receiver_id !== 0 && $sender_id !== $user_id && $receiver_id !== $user_id) {
            return new WP_Error('wsm_ticket_thread_forbidden', 'شما عضو این تیکت نیستید.', array('status' => 403));
        }
        if ($receiver_id === 0) {
            return array('type' => 'group', 'contact' => array('name' => 'همهٔ کارمندان', 'email' => '', 'phone' => '', 'role' => 'گفتگوی گروهی'));
        }
        $contact_id = $sender_id === $user_id ? $receiver_id : $sender_id;
        $contact = get_userdata($contact_id);
        if (!$contact) { return new WP_Error('wsm_ticket_contact_missing', 'حساب مخاطب پیدا نشد.', array('status' => 404)); }
        $phone = '';
        foreach (array('billing_phone', 'phone', 'wsm_phone', 'user_phone') as $meta_key) {
            $candidate = get_user_meta($contact_id, $meta_key, true);
            if (is_scalar($candidate) && trim((string) $candidate) !== '') { $phone = sanitize_text_field((string) $candidate); break; }
        }
        $roles = array_values(array_filter(array_map('sanitize_key', (array) $contact->roles)));
        return array('type' => 'employee', 'contact' => array(
            'id' => $contact_id, 'name' => sanitize_text_field((string) $contact->display_name),
            'email' => sanitize_email((string) $contact->user_email), 'phone' => $phone,
            'role' => implode(', ', $roles),
        ));
    }

    /** Per-user quick replies are stored in WordPress user meta so they follow the staff account. */
    public static function messages_quick_replies($request) {
        $user_id = self::messages_current_user_id();
        if ($user_id < 1 || !WSM_Permissions::ticket_can('wsm_ticket_view', $user_id)) {
            return new WP_Error('wsm_ticket_quick_replies_forbidden', 'مجوز مشاهدهٔ پاسخ‌های سریع را ندارید.', array('status' => 403, 'capability' => 'wsm_ticket_view'));
        }
        $method = strtoupper((string) $request->get_method());
        if ($method === 'POST') {
            if (!WSM_Permissions::ticket_can('wsm_ticket_reply', $user_id) && !WSM_Permissions::ticket_can('wsm_ticket_internal_note', $user_id)) {
                return new WP_Error('wsm_ticket_quick_replies_forbidden', 'برای مدیریت پاسخ‌های سریع، مجوز پاسخ‌گویی لازم است.', array('status' => 403, 'capability' => 'wsm_ticket_reply'));
            }
            $body = self::body($request);
            $items = isset($body['items']) ? $body['items'] : null;
            if (!is_array($items) || count($items) > 20) {
                return new WP_Error('wsm_ticket_quick_replies_invalid', 'فهرست پاسخ‌های سریع معتبر نیست یا بیش از ۲۰ مورد دارد.', array('status' => 400));
            }
            $clean = array();
            foreach ($items as $item) {
                if (!is_scalar($item)) { continue; }
                $text = trim(sanitize_textarea_field((string) $item));
                if ($text === '') { continue; }
                $length = function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : (preg_match_all('/./us', $text, $matches) ?: strlen($text));
                if ($length > 500) { return new WP_Error('wsm_ticket_quick_reply_too_long', 'هر پاسخ سریع باید حداکثر ۵۰۰ نویسه باشد.', array('status' => 400)); }
                if (!in_array($text, $clean, true)) { $clean[] = $text; }
            }
            update_user_meta($user_id, 'wsm_ticket_quick_replies', array_slice($clean, 0, 20));
            return array('items' => array_slice($clean, 0, 20));
        }
        $saved = get_user_meta($user_id, 'wsm_ticket_quick_replies', true);
        if (!is_array($saved)) { $saved = array(); }
        $clean = array();
        foreach ($saved as $item) {
            if (!is_scalar($item)) { continue; }
            $text = trim(sanitize_textarea_field((string) $item));
            if ($text === '') { continue; }
            $length = function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : (preg_match_all('/./us', $text, $matches) ?: strlen($text));
            if ($length <= 500 && !in_array($text, $clean, true)) { $clean[] = $text; }
            if (count($clean) >= 20) { break; }
        }
        return array('items' => $clean);
    }

    public static function messages_read($request) {
        if (!WSM_Permissions::ticket_can('wsm_ticket_view')) {
            return new WP_Error('wsm_ticket_view_forbidden', 'مجوز مشاهدهٔ تیکت‌ها را ندارید.', array('status' => 403, 'capability' => 'wsm_ticket_view'));
        }
        if (self::messages_is_wordpress_administrator()) {
            return array('updated' => 0, 'uuids' => array(), 'read_receipts_suppressed' => true);
        }
        $body = self::body($request);
        $uuids = isset($body['uuids']) ? $body['uuids'] : array();
        if (!is_array($uuids) || count($uuids) > 200) {
            return WSM_Club_Operations::mark_internal_messages_read($uuids);
        }
        $schema = self::ensure_message_moderation_schema();
        if (is_wp_error($schema)) { return $schema; }
        $clean = array();
        foreach ($uuids as $uuid) {
            if (is_scalar($uuid)) {
                $uuid = strtolower(trim((string) $uuid));
                if (preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i', $uuid)) { $clean[$uuid] = $uuid; }
            }
        }
        if (!$clean) { return array('updated' => 0, 'uuids' => array()); }
        global $wpdb;
        $table_sql = '`' . str_replace('`', '``', self::messages_table_name()) . '`';
        $placeholders = implode(',', array_fill(0, count($clean), '%s'));
        $sql = $wpdb->prepare("SELECT uuid FROM {$table_sql} WHERE deleted_at IS NULL AND uuid IN ({$placeholders})", array_values($clean));
        $active = $wpdb->get_col($sql);
        if (!empty($wpdb->last_error)) { return new WP_Error('wsm_message_read_lookup_failed', 'بررسی وضعیت پیام‌های فعال انجام نشد.', array('status' => 500)); }
        return WSM_Club_Operations::mark_internal_messages_read(array_values(array_map('strval', (array) $active)));
    }

    public static function messages_delete($request) {
        if (!self::messages_is_wordpress_administrator()) {
            return new WP_Error('wsm_message_delete_forbidden', 'حذف پیام فقط برای نقش administrator مجاز است.', array('status' => 403));
        }
        $body = self::body($request);
        $uuid = isset($body['uuid']) && is_scalar($body['uuid']) ? strtolower(trim((string) $body['uuid'])) : '';
        if (!preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i', $uuid)) {
            return new WP_Error('wsm_message_uuid_invalid', 'شناسهٔ پیام معتبر نیست.', array('status' => 400));
        }
        $schema = self::ensure_message_moderation_schema();
        if (is_wp_error($schema)) { return $schema; }
        global $wpdb;
        $messages_table = self::messages_table_name();
        $audit_table = self::messages_audit_table_name();
        $messages_sql = '`' . str_replace('`', '``', $messages_table) . '`';
        $row = $wpdb->get_row($wpdb->prepare("SELECT uuid, deleted_at FROM {$messages_sql} WHERE uuid = %s LIMIT 1", $uuid), ARRAY_A);
        if (!empty($wpdb->last_error)) { return new WP_Error('wsm_message_delete_lookup_failed', 'بررسی پیام برای حذف انجام نشد.', array('status' => 500)); }
        if (!is_array($row)) { return new WP_Error('wsm_message_not_found', 'پیام پیدا نشد.', array('status' => 404)); }
        if (!empty($row['deleted_at'])) { return array('deleted' => true, 'already_deleted' => true, 'uuid' => $uuid); }
        foreach (array($messages_table, $audit_table) as $table_name) {
            $status = $wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS WHERE Name = %s', $table_name), ARRAY_A);
            if (!empty($wpdb->last_error) || !is_array($status) || strtolower((string) $status['Engine']) !== 'innodb') {
                return new WP_Error('wsm_message_delete_engine_required', 'حذف با گزارش ممیزی فقط روی جدول‌های تراکنشی InnoDB انجام می‌شود.', array('status' => 409));
            }
        }
        if ($wpdb->query('START TRANSACTION') === false) {
            return new WP_Error('wsm_message_delete_transaction_failed', 'شروع تراکنش حذف پیام انجام نشد.', array('status' => 500));
        }
        $deleted_at = current_time('mysql');
        $updated = $wpdb->query($wpdb->prepare(
            "UPDATE {$messages_sql} SET deleted_at = %s, deleted_by = %d WHERE uuid = %s AND deleted_at IS NULL",
            $deleted_at, self::messages_current_user_id(), $uuid
        ));
        if ($updated !== 1 || !self::record_message_audit('delete', $uuid, 1)) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('wsm_message_delete_failed', 'حذف امن پیام یا ثبت گزارش ممیزی انجام نشد.', array('status' => 500));
        }
        if ($wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('wsm_message_delete_commit_failed', 'ثبت نهایی حذف پیام انجام نشد.', array('status' => 500));
        }
        return array('deleted' => true, 'soft_deleted' => true, 'uuid' => $uuid, 'deleted_at' => $deleted_at);
    }

    public static function messages_audit_list($request) {
        if (!WSM_Permissions::ticket_can('wsm_ticket_audit')) {
            return new WP_Error('wsm_message_audit_forbidden', 'مجوز مشاهدهٔ گزارش ممیزی تیکت‌ها را ندارید.', array('status' => 403, 'capability' => 'wsm_ticket_audit'));
        }
        $schema = self::ensure_message_moderation_schema();
        if (is_wp_error($schema)) { return $schema; }
        global $wpdb;
        $limit = max(1, min(100, absint($request->get_param('limit')) ?: 50));
        $table_sql = '`' . str_replace('`', '``', self::messages_audit_table_name()) . '`';
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id, message_uuid, actor_user_id, action, item_count, acted_at FROM {$table_sql} ORDER BY id DESC LIMIT %d", $limit), ARRAY_A);
        if (!empty($wpdb->last_error)) { return new WP_Error('wsm_message_audit_read_failed', 'خواندن گزارش ممیزی پیام‌ها انجام نشد.', array('status' => 500)); }
        $user_ids = array_values(array_unique(array_map('absint', array_column((array) $rows, 'actor_user_id'))));
        $names = array();
        foreach ($user_ids as $id) { $user = get_userdata($id); $names[$id] = $user ? (string) $user->display_name : 'کاربر ' . $id; }
        $items = array();
        foreach ((array) $rows as $row) {
            $actor_id = absint($row['actor_user_id']);
            $items[] = array(
                'id' => absint($row['id']), 'message_uuid' => (string) $row['message_uuid'],
                'actor_user_id' => $actor_id, 'actor_name' => isset($names[$actor_id]) ? $names[$actor_id] : 'کاربر ' . $actor_id,
                'action' => (string) $row['action'], 'item_count' => absint($row['item_count']), 'acted_at' => (string) $row['acted_at'],
            );
        }
        return array('items' => $items, 'limit' => $limit);
    }

    /**
     * Pull route reuses the existing Bearer/HMAC/account checks. The generic
     * permission map deliberately fails closed for unknown routes, so authorize
     * this route's data scopes here after check_request has authenticated it.
     */
    public static function sync_pull_permission($request) {
        $checked = WSM_Permissions::check_request($request);
        if (is_wp_error($checked) && !in_array($checked->get_error_code(), array('wsm_permission_unmapped', 'wsm_device_permission_denied'), true)) {
            return $checked;
        }
        if ($checked === false) {
            return new WP_Error('wsm_sync_pull_auth_failed', 'احراز هویت درخواست همگام‌سازی ناموفق بود.', array('status' => 403));
        }
        $device = WSM_Permissions::current_device();
        if (!$device) {
            return new WP_Error('wsm_sync_pull_device_required', 'دستگاه احرازشده در دسترس نیست.', array('status' => 401));
        }
        $rate_limit = self::check_rest_read_rate_limit('sync', WSM_Permissions::current_device_id());
        if (is_wp_error($rate_limit)) { return $rate_limit; }
        foreach (array('products.view', 'club.pos.create', 'club.members.view', 'settings.view', 'security.manage') as $permission) {
            if (WSM_Devices::device_can($device, $permission)) { return true; }
        }
        return new WP_Error('wsm_sync_pull_forbidden', 'این دستگاه مجوز دریافت داده‌های همگام‌سازی را ندارد.', array('status' => 403));
    }

    /** Parse the client watermark (Unix seconds; milliseconds/ISO are accepted defensively). */
    private static function sync_pull_parse_last_sync($value) {
        if ($value === null || $value === '') { return 0; }
        if (!is_scalar($value)) {
            return new WP_Error('wsm_sync_pull_last_sync_invalid', 'پارامتر last_sync معتبر نیست.', array('status' => 400));
        }
        $value = trim((string) $value);
        if ($value === '' || $value === '0') { return 0; }
        if (is_numeric($value)) {
            $number = (float) $value;
            if (!is_finite($number) || $number < 0) {
                return new WP_Error('wsm_sync_pull_last_sync_invalid', 'پارامتر last_sync باید timestamp معتبر باشد.', array('status' => 400));
            }
            if ($number > 9999999999) { $number = floor($number / 1000); }
            return (int) floor($number);
        }
        $parsed = strtotime($value);
        if ($parsed === false) {
            return new WP_Error('wsm_sync_pull_last_sync_invalid', 'پارامتر last_sync باید timestamp یا تاریخ معتبر باشد.', array('status' => 400));
        }
        return max(0, (int) $parsed);
    }

    /** Log memory-only sync diagnostics when explicitly enabled by a WordPress administrator. */
    private static function sync_debug_log($stage) {
        static $enabled = null;
        if ($enabled === null) {
            $settings = WSM_Util::settings();
            $enabled = !empty($settings['sync_debug_mode']);
        }
        if (!$enabled || !function_exists('error_log')) { return; }
        $stage = preg_replace('/[^a-z0-9_-]/i', '', (string) $stage);
        error_log('[WSM SYNC START] Memory Usage: ' . memory_get_usage() . ' bytes; Peak: ' . memory_get_peak_usage() . ' bytes; Stage: ' . $stage);
    }

    /** GET /sync/pull — only return data visible to the authenticated device. */
    public static function sync_pull($request) {
        global $wpdb;
        self::sync_debug_log('start');
        if (!WSM_Util::is_woo_active()) { return WSM_Util::woo_required_error(); }
        $parsed_last_sync = self::sync_pull_parse_last_sync($request->get_param('last_sync'));
        if (is_wp_error($parsed_last_sync)) { return $parsed_last_sync; }

        $query_params = is_object($request) && method_exists($request, 'get_query_params') ? (array) $request->get_query_params() : array();
        $pagination_requested = array_key_exists('offset', $query_params);
        $offset = 0;
        if ($pagination_requested) {
            $offset_raw = $query_params['offset'];
            if (!is_scalar($offset_raw) || !preg_match('/^\d+$/D', (string) $offset_raw) || (float) $offset_raw > 10000000) {
                return new WP_Error('wsm_sync_pull_offset_invalid', 'پارامتر offset باید عدد صحیح نامنفی و حداکثر ۱۰۰۰۰۰۰۰ باشد.', array('status' => 400));
            }
            $offset = (int) $offset_raw;
        }
        $server_now = time();
        // The first page fixes this watermark; subsequent offset pages reuse it for a stable time window.
        $sync_time = max(0, $server_now - 1);
        if ($pagination_requested && array_key_exists('sync_time', $query_params)) {
            $sync_time_raw = $query_params['sync_time'];
            if (!is_scalar($sync_time_raw) || !preg_match('/^\d+$/D', (string) $sync_time_raw) || (float) $sync_time_raw > $sync_time) {
                return new WP_Error('wsm_sync_pull_time_invalid', 'پارامتر sync_time معتبر نیست یا از زمان سرور جلوتر است.', array('status' => 400));
            }
            $sync_time = (int) $sync_time_raw;
            $server_now = $sync_time + 1;
        }
        // Keep a one-second overlap for second-precision MySQL timestamps and clock skew.
        $cutoff = max(0, min((int) $parsed_last_sync, $sync_time) - 1);
        $cutoff_gmt = gmdate('Y-m-d H:i:s', $cutoff);
        $end_gmt = gmdate('Y-m-d H:i:s', $server_now);
        $cutoff_local = get_date_from_gmt($cutoff_gmt, 'Y-m-d H:i:s');
        $end_local = get_date_from_gmt($end_gmt, 'Y-m-d H:i:s');

        $device = WSM_Permissions::current_device();
        $can_products = $device && (WSM_Devices::device_can($device, 'products.view') || WSM_Devices::device_can($device, 'club.pos.create'));
        $can_members = $device && WSM_Devices::device_can($device, 'club.members.view');
        $can_settings = $device && (WSM_Devices::device_can($device, 'settings.view') || WSM_Devices::device_can($device, 'security.manage'));
        $include_non_product_delta = !$pagination_requested || $offset === 0;
        $products = array();
        $members = array();
        $deleted_by_key = array();
        $has_more_products = false;
        $next_offset = null;

        if ($can_products) {
            self::sync_debug_log('products-query');
            $product_sql = $wpdb->prepare(
                "SELECT ID, post_modified_gmt FROM {$wpdb->posts}
                 WHERE post_type = %s AND post_status NOT IN (%s, %s, %s)
                   AND post_modified_gmt > %s AND post_modified_gmt <= %s
                 ORDER BY post_modified_gmt ASC, ID ASC",
                'product', 'trash', 'auto-draft', 'inherit', $cutoff_gmt, $end_gmt
            );
            if ($pagination_requested) {
                $product_sql .= $wpdb->prepare(' LIMIT %d OFFSET %d', 101, $offset);
            }
            $product_rows = (array) $wpdb->get_results($product_sql);
            if (!empty($wpdb->last_error)) {
                return new WP_Error('wsm_sync_pull_products_failed', 'دریافت تغییرات کالاها انجام نشد.', array('status' => 500));
            }
            if ($pagination_requested) {
                $has_more_products = count($product_rows) > 100;
                if ($has_more_products) { $product_rows = array_slice($product_rows, 0, 100); }
                if ($has_more_products) { $next_offset = $offset + count($product_rows); }
            }

            $product_ids = array();
            foreach ($product_rows as $row) {
                $product_id = absint($row->ID ?? 0);
                if ($product_id) { $product_ids[$product_id] = $product_id; }
            }
            $category_terms = array();
            if ($product_ids && function_exists('wp_get_object_terms')) {
                self::sync_debug_log('category-bulk-query');
                foreach (array_chunk(array_values($product_ids), 100) as $product_id_chunk) {
                    $terms = wp_get_object_terms($product_id_chunk, 'product_cat', array('fields' => 'all'));
                    if (is_wp_error($terms)) { continue; }
                    foreach ((array) $terms as $term) {
                        if (is_object($term) && isset($term->term_id)) { $category_terms[(int) $term->term_id] = $term; }
                    }
                }
            }

            self::sync_debug_log('products-format-loop');
            foreach ($product_rows as $row) {
                $product = wc_get_product((int) $row->ID);
                if (!$product) { continue; }
                $formatted = WSM_Products::format($product, $category_terms);
                $formatted['updated_at'] = (string) $row->post_modified_gmt;
                $formatted['post_modified_gmt'] = (string) $row->post_modified_gmt;
                $products[] = $formatted;
            }

            if ($include_non_product_delta) {
                // Keep tombstones in a non-autoloaded option so every device can pull them,
                // including devices that were offline when a product was permanently deleted.
                $tombstones = get_option('wsm_sync_deleted_products', array());
                if (is_array($tombstones)) {
                    foreach ($tombstones as $raw_id => $deleted_at) {
                        $product_id = absint($raw_id);
                        $deleted_at = (int) $deleted_at;
                        if ($product_id < 1 || $deleted_at <= $cutoff || $deleted_at > $server_now) { continue; }
                        $existing_post = get_post($product_id);
                        if ($existing_post && $existing_post->post_type === 'product' && $existing_post->post_status !== 'trash') {
                            // A restored/published product must not be deleted by a stale tombstone.
                            continue;
                        }
                        $deleted_by_key['products:' . $product_id] = array('type' => 'products', 'id' => $product_id);
                    }
                }
                // Trash is a soft delete in this plugin; include recent trashed products too.
                self::sync_debug_log('deleted-products-query');
                $trash_sql = $wpdb->prepare(
                    "SELECT ID FROM {$wpdb->posts}
                     WHERE post_type = %s AND post_status = %s
                       AND post_modified_gmt > %s AND post_modified_gmt <= %s
                     ORDER BY post_modified_gmt ASC, ID ASC",
                    'product', 'trash', $cutoff_gmt, $end_gmt
                );
                $trashed_ids = $wpdb->get_col($trash_sql);
                if (!empty($wpdb->last_error)) {
                    return new WP_Error('wsm_sync_pull_deletions_failed', 'دریافت فهرست کالاهای حذف‌شده انجام نشد.', array('status' => 500));
                }
                foreach ((array) $trashed_ids as $trashed_id) {
                    $trashed_id = absint($trashed_id);
                    if ($trashed_id > 0) { $deleted_by_key['products:' . $trashed_id] = array('type' => 'products', 'id' => $trashed_id); }
                }
            }
        }

        if ($can_members && $include_non_product_delta) {
            $members_table = WSM_Club::table('members');
            self::sync_debug_log('members-query');
            $member_sql = $wpdb->prepare(
                "SELECT id, updated_at FROM {$members_table}
                 WHERE updated_at > %s AND updated_at <= %s
                 ORDER BY updated_at ASC, id ASC",
                $cutoff_local, $end_local
            );
            $member_rows = $wpdb->get_results($member_sql);
            if (!empty($wpdb->last_error)) {
                return new WP_Error('wsm_sync_pull_members_failed', 'دریافت تغییرات اعضا انجام نشد.', array('status' => 500));
            }
            $member_ids = array();
            foreach ((array) $member_rows as $row) { $member_ids[] = (int) $row->id; }
            $offline_uuids_by_member = array();
            if ($member_ids) {
                self::sync_debug_log('member-map-query');
                $map_table = $wpdb->prefix . 'wsm_sync_member_map';
                $found_map_table = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($map_table)));
                if (!empty($wpdb->last_error) || $found_map_table !== $map_table) {
                    return new WP_Error('wsm_sync_pull_member_map_unavailable', 'پیوند اعضای آفلاین برای همگام‌سازی در دسترس نیست.', array('status' => 500));
                }
                $map_table_sql = '`' . str_replace('`', '``', $map_table) . '`';
                $placeholders = implode(',', array_fill(0, count($member_ids), '%d'));
                $map_sql = $wpdb->prepare("SELECT member_id, offline_uuid FROM {$map_table_sql} WHERE member_id IN ({$placeholders})", $member_ids);
                $map_rows = $wpdb->get_results($map_sql);
                if (!empty($wpdb->last_error)) {
                    return new WP_Error('wsm_sync_pull_member_map_unavailable', 'خواندن پیوندهای اعضای آفلاین انجام نشد.', array('status' => 500));
                }
                foreach ((array) $map_rows as $map_row) {
                    $offline_uuids_by_member[(int) $map_row->member_id][] = (string) $map_row->offline_uuid;
                }
            }
            foreach ((array) $member_rows as $row) {
                $member = WSM_Club::get_member((int) $row->id);
                if (is_wp_error($member)) { return $member; }
                if (!is_array($member)) {
                    return new WP_Error('wsm_sync_pull_member_format_invalid', 'قالب عضو تغییرکرده معتبر نیست.', array('status' => 500));
                }
                $member['updated_at'] = (string) $row->updated_at;
                $member['offline_uuids'] = isset($offline_uuids_by_member[(int) $row->id])
                    ? array_values(array_unique($offline_uuids_by_member[(int) $row->id]))
                    : array();
                $members[] = $member;
            }
        }

        $settings_updated_at = 0;
        $settings = null;
        if ($include_non_product_delta) {
            $settings_updated_at = max(0, (int) get_option('wsm_sync_settings_updated_at', 0));
            if ($can_settings && ((int) $parsed_last_sync === 0 || ($settings_updated_at > $cutoff && $settings_updated_at <= $server_now))) {
                $settings = self::settings();
            }
        }

        self::sync_debug_log('complete');
        return array(
            'products' => $products,
            'members' => $members,
            'deleted_ids' => array_values($deleted_by_key),
            'settings' => $settings,
            'settings_updated_at' => $settings_updated_at,
            'sync_time' => $sync_time,
            'offset' => $pagination_requested ? $offset : null,
            'next_offset' => $next_offset,
            'has_more_products' => $has_more_products,
        );
    }

    /** Record global settings changes without adding a database table or schema. */
    public static function sync_pull_track_settings_change($option, $old_value = null, $new_value = null) {
        if (!in_array((string) $option, array('wsm_settings', 'woocommerce_currency'), true)) { return; }
        update_option('wsm_sync_settings_updated_at', time(), false);
    }

    /** Persist product tombstones before a hard delete; trashed products are also queried directly. */
    public static function sync_pull_track_deleted_product($post_id, $post = null) {
        $post_id = absint($post_id);
        if ($post_id < 1) { return; }
        if (!is_object($post) || !isset($post->post_type)) { $post = get_post($post_id); }
        if (!$post || !isset($post->post_type) || $post->post_type !== 'product') { return; }
        self::invalidate_rest_product_cache();
        $tombstones = get_option('wsm_sync_deleted_products', array());
        if (!is_array($tombstones)) { $tombstones = array(); }
        $tombstones[(string) $post_id] = time();
        update_option('wsm_sync_deleted_products', $tombstones, false);
    }

    /** Remove a stale tombstone if a product is restored from the trash. */
    public static function sync_pull_clear_product_tombstone($post_id, $previous_status = null) {
        $post_id = absint($post_id);
        if ($post_id < 1) { return; }
        $post = get_post($post_id);
        if (!$post || !isset($post->post_type) || $post->post_type !== 'product') { return; }
        self::invalidate_rest_product_cache();
        $tombstones = get_option('wsm_sync_deleted_products', array());
        if (!is_array($tombstones) || !isset($tombstones[(string) $post_id])) { return; }
        unset($tombstones[(string) $post_id]);
        update_option('wsm_sync_deleted_products', $tombstones, false);
    }

    /** Register option/post hooks on all requests, including dashboard deletions and settings edits. */
    public static function register_sync_pull_watchers() {
        add_action('updated_option', array(__CLASS__, 'sync_pull_track_settings_change'), 10, 3);
        add_action('added_option', array(__CLASS__, 'sync_pull_track_settings_change'), 10, 2);
        add_action('updated_option', array(__CLASS__, 'invalidate_rest_settings_cache_option'), 5, 3);
        add_action('added_option', array(__CLASS__, 'invalidate_rest_settings_cache_option'), 5, 2);
        add_action('deleted_option', array(__CLASS__, 'invalidate_rest_settings_cache_option'), 5, 1);
        add_action('woocommerce_new_product', array(__CLASS__, 'invalidate_rest_product_cache'), 10, 2);
        add_action('woocommerce_update_product', array(__CLASS__, 'invalidate_rest_product_cache'), 10, 2);
        add_action('woocommerce_new_product_variation', array(__CLASS__, 'invalidate_rest_product_cache'), 10, 2);
        add_action('woocommerce_update_product_variation', array(__CLASS__, 'invalidate_rest_product_cache'), 10, 2);
        add_action('woocommerce_product_set_stock', array(__CLASS__, 'invalidate_rest_product_cache'), 10, 1);
        add_action('woocommerce_variation_set_stock', array(__CLASS__, 'invalidate_rest_product_cache'), 10, 1);
        add_action('set_object_terms', array(__CLASS__, 'invalidate_rest_product_cache_terms'), 10, 6);
        add_action('created_product_cat', array(__CLASS__, 'invalidate_rest_product_cache'), 10, 1);
        add_action('edited_product_cat', array(__CLASS__, 'invalidate_rest_product_cache'), 10, 1);
        add_action('delete_product_cat', array(__CLASS__, 'invalidate_rest_product_cache'), 10, 1);
        add_action('before_delete_post', array(__CLASS__, 'sync_pull_track_deleted_product'), 10, 2);
        add_action('trashed_post', array(__CLASS__, 'sync_pull_track_deleted_product'), 10, 2);
        add_action('untrashed_post', array(__CLASS__, 'sync_pull_clear_product_tombstone'), 10, 2);
    }

    /** Invalidate category caches only for product/category assignments. */
    public static function invalidate_rest_product_cache_terms($object_id, $terms = null, $tt_ids = null, $taxonomy = '', $append = false, $old_tt_ids = null) {
        if ((string) $taxonomy !== 'product_cat') { return; }
        $post_type = get_post_type(absint($object_id));
        if (in_array($post_type, array('product', 'product_variation'), true)) {
            self::invalidate_rest_product_cache();
        }
    }

    /**
     * Receive an offline queue batch, persist it, then replay received rows safely.
     * The route's permission_callback performs the existing Bearer/HMAC checks.
     */
    public static function sync_bulk($request) {
        /*
         * This is a WordPress REST callback: return the REST payload and let WP_REST_Server
         * serialize/terminate the response. Do not emit a second response or exit here.
         * Capture and discard accidental output so notices cannot corrupt the JSON response.
         */
        $initial_buffer_level = ob_get_level();
        ob_start();
        try {
            try {
                $result = self::sync_bulk_process($request);
            } catch (Throwable $exception) {
                // A fatal/exception here used to escape the REST callback and make WordPress
                // print an HTML error page, which the app reported as "wsm_sync_invalid_response".
                error_log('[WSM Sync] Unhandled exception while processing a sync batch: ' . $exception->getMessage());
                $result = new WP_Error(
                    'wsm_sync_internal_error',
                    'سرور هنگام پردازش همگام‌سازی خطای داخلی داد: ' . $exception->getMessage(),
                    array('status' => 500)
                );
            }
            if (ob_get_level() > $initial_buffer_level) { ob_clean(); }
            return $result;
        } finally {
            while (ob_get_level() > $initial_buffer_level) { @ob_end_clean(); }
        }
    }

    private static function sync_bulk_process($request) {
        global $wpdb;

        $raw_body = method_exists($request, 'get_body') ? $request->get_body() : '';
        if (!is_string($raw_body) || trim($raw_body) === '') {
            return new WP_Error('wsm_sync_bulk_invalid_json', 'بدنهٔ درخواست باید JSON معتبر باشد.', array('status' => 400));
        }

        $decoded_body = json_decode($raw_body);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error('wsm_sync_bulk_invalid_json', 'بدنهٔ درخواست باید JSON معتبر باشد.', array('status' => 400));
        }

        if (is_array($decoded_body)) {
            // Also accept a top-level JSON array for simple sync clients.
            $items = $decoded_body;
        } elseif (is_object($decoded_body) && isset($decoded_body->items) && is_array($decoded_body->items)) {
            $items = $decoded_body->items;
        } else {
            return new WP_Error('wsm_sync_bulk_invalid_items', 'فهرست items در درخواست معتبر نیست.', array('status' => 400));
        }

        $total_received = count($items);
        if ($total_received > 50) {
            return new WP_Error('wsm_sync_bulk_limit_exceeded', 'حداکثر ۵۰ آیتم در هر بسته پذیرفته می‌شود.', array('status' => 400));
        }

        $device = WSM_Permissions::current_device();
        if (!$device) {
            return new WP_Error('wsm_sync_device_required', 'دستگاه احراز هویت‌شده در دسترس نیست.', array('status' => 401));
        }

        // Validate the entire batch and all item-level grants before writing any row.
        $validated_items = array();
        foreach ($items as $index => $item) {
            $item_number = (int) $index + 1;
            if (!is_object($item)) {
                return new WP_Error('wsm_sync_bulk_item_invalid', 'ساختار یکی از آیتم‌های همگام‌سازی معتبر نیست (ردیف ' . $item_number . ').', array('status' => 400));
            }

            if (!isset($item->queue_id) || !is_string($item->queue_id)) {
                return new WP_Error('wsm_sync_bulk_queue_id_invalid', 'queue_id یکی از آیتم‌ها معتبر نیست (ردیف ' . $item_number . ').', array('status' => 400));
            }
            $queue_id = strtolower(trim($item->queue_id));
            if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', $queue_id)) {
                return new WP_Error('wsm_sync_bulk_queue_id_invalid', 'queue_id یکی از آیتم‌ها باید UUID معتبر باشد (ردیف ' . $item_number . ').', array('status' => 400));
            }

            if (!isset($item->action_type) || !is_string($item->action_type) || !in_array($item->action_type, array('CREATE_SALE', 'CREATE_MEMBER', 'CREATE_MEMBERSHIP', 'CREATE_MESSAGE', 'CHANGE_ORDER_STATUS', 'SEND_CLUB_SMS', 'UPDATE_USER', 'UPDATE_SETTINGS'), true)) {
                return new WP_Error('wsm_sync_bulk_action_invalid', 'action_type یکی از آیتم‌ها پشتیبانی نمی‌شود (ردیف ' . $item_number . ').', array('status' => 400));
            }

            if (!isset($item->payload) || !is_string($item->payload) || trim($item->payload) === '') {
                return new WP_Error('wsm_sync_bulk_payload_invalid', 'payload یکی از آیتم‌ها باید یک شیء JSON معتبر باشد (ردیف ' . $item_number . ').', array('status' => 400));
            }
            $payload_object = json_decode($item->payload);
            if (json_last_error() !== JSON_ERROR_NONE || !is_object($payload_object)) {
                return new WP_Error('wsm_sync_bulk_payload_invalid', 'payload یکی از آیتم‌ها باید یک شیء JSON معتبر باشد (ردیف ' . $item_number . ').', array('status' => 400));
            }

            if ($item->action_type === 'UPDATE_SETTINGS') {
                $valid_settings = self::validate_sync_settings(json_decode($item->payload, true), $device);
                if (is_wp_error($valid_settings)) { return $valid_settings; }
            } elseif ($item->action_type === 'UPDATE_USER') {
                if (!WSM_Devices::device_can($device, 'users.manage') && !WSM_Devices::device_can($device, 'club.users.manage')) { return new WP_Error('wsm_sync_item_forbidden', 'مجوز تغییر کاربران را ندارید.', array('status' => 403)); }
                $fields = (array) $payload_object;
                if (array_diff(array_keys($fields), array('id','status','actor_user_id')) || empty($fields['id']) || !isset($fields['status'], $fields['actor_user_id']) || !in_array($fields['status'], array('active','inactive'), true) || (int) $fields['actor_user_id'] !== (int) $device->user_id) { return new WP_Error('wsm_sync_user_payload_invalid', 'صف کاربران فقط تغییر وضعیت، با هویت همان مدیر را می‌پذیرد.', array('status' => 403)); }
            } elseif ($item->action_type === 'SEND_CLUB_SMS') {
                $can_sms = WSM_Devices::device_can($device, 'club.sms.manage') ||
                    WSM_Devices::device_can($device, 'club.sms.send') ||
                    WSM_Devices::device_can($device, 'club.sms.bulk_send');
                if (!$can_sms) {
                    return new WP_Error('wsm_sync_item_forbidden', 'دستگاه مجوز ارسال پیامک باشگاه را ندارد.', array('status' => 403, 'permission' => 'club.sms.send'));
                }
            } else {
                if ($item->action_type === 'SEND_CLUB_SMS') {
                    if (!WSM_Devices::device_can($device, 'club.sms.send') &&
                        !WSM_Devices::device_can($device, 'club.sms.manage') &&
                        !WSM_Devices::device_can($device, 'club.sms.bulk_send')) {
                        return new WP_Error('wsm_sync_item_forbidden', 'دستگاه برای یکی از عملیات‌های این بسته مجوز لازم را ندارد.', array('status' => 403, 'permission' => 'club.sms.send'));
                    }
                    $required_permission = '';
                } else {
                    $required_permission = $item->action_type === 'CREATE_SALE' ? 'club.pos.create' :
                        ($item->action_type === 'CHANGE_ORDER_STATUS' ? 'orders.change_status' :
                        ($item->action_type === 'CREATE_MESSAGE' ? 'messages.send' :
                        (in_array($item->action_type, array('CREATE_MEMBER', 'CREATE_MEMBERSHIP'), true) ? 'club.members.manage' : '')));
                }
                if ($required_permission !== '' && !WSM_Devices::device_can($device, $required_permission)) {
                    return new WP_Error('wsm_sync_item_forbidden', 'دستگاه برای یکی از عملیات‌های این بسته مجوز لازم را ندارد.', array('status' => 403, 'permission' => $required_permission));
                }
            }

            $validated_items[] = array(
                'queue_id' => $queue_id,
                'action_type' => $item->action_type,
                'payload' => $item->payload,
            );
        }

        $device_id = isset($device->id) ? (int) $device->id : 0;
        if ($device_id < 1) {
            return new WP_Error('wsm_sync_device_required', 'شناسهٔ دستگاه احراز هویت‌شده معتبر نیست.', array('status' => 401));
        }

        $lock_name = self::acquire_sync_lock(10);
        if (is_wp_error($lock_name)) { return $lock_name; }

        try {
            $table = $wpdb->prefix . 'wsm_sync_logs';
            $table_sql = '`' . str_replace('`', '``', $table) . '`';
            $received = 0;
            $replayed = 0;
            $duplicates_ignored = 0;
            $new_queue_ids = array();

            foreach ($validated_items as $item) {
                $existing = $wpdb->get_row($wpdb->prepare(
                    'SELECT id, status, action_type, payload FROM ' . $table_sql . ' WHERE queue_id = %s LIMIT 1',
                    $item['queue_id']
                ));
                if (!empty($wpdb->last_error)) {
                    return new WP_Error('wsm_sync_logs_unavailable', 'خواندن جدول لاگ همگام‌سازی انجام نشد.', array('status' => 500));
                }
                if (is_object($existing) && !empty($existing->id)) {
                    if (!self::sync_queue_payload_matches($existing, $item)) {
                        return new WP_Error('wsm_sync_queue_id_conflict', 'این queue_id قبلاً با نوع عملیات یا payload دیگری ثبت شده است.', array('status' => 409));
                    }
                    $existing_status = isset($existing->status) ? strtolower((string) $existing->status) : '';
                    if ($existing_status === 'processed') {
                        // Only a row that already succeeded is a real duplicate.
                        $duplicates_ignored++;
                        continue;
                    }
                    // 'failed' or 'received': reopen the row so an explicit retry can actually run again.
                    $reopened = $wpdb->update($table, array('status' => 'received', 'error_message' => null),
                        array('id' => (int) $existing->id), array('%s', '%s'), array('%d'));
                    if ($reopened === false || !empty($wpdb->last_error)) {
                        return new WP_Error('wsm_sync_logs_unavailable', 'بازگشایی آیتم ناموفق قبلی انجام نشد.', array('status' => 500));
                    }
                    $replayed++;
                    $received++;
                    $new_queue_ids[$item['queue_id']] = true;
                    continue;
                }

                $inserted = $wpdb->insert($table, array(
                    'queue_id' => $item['queue_id'],
                    'device_id' => $device_id,
                    'action_type' => $item['action_type'],
                    'status' => 'received',
                    'payload' => $item['payload'],
                    'created_at' => self::sync_now(),
                ), array('%s', '%d', '%s', '%s', '%s', '%s'));
                if ($inserted === 1) {
                    $received++;
                    $new_queue_ids[$item['queue_id']] = true;
                    continue;
                }

                // UNIQUE(queue_id) is authoritative even if a concurrent non-REST writer races us.
                $insert_error = (string) $wpdb->last_error;
                $existing_after_insert = $wpdb->get_row($wpdb->prepare(
                    'SELECT id, status, action_type, payload FROM ' . $table_sql . ' WHERE queue_id = %s LIMIT 1',
                    $item['queue_id']
                ));
                if (!empty($wpdb->last_error)) {
                    return new WP_Error('wsm_sync_logs_unavailable', 'بررسی نتیجهٔ درج در جدول لاگ انجام نشد.', array('status' => 500));
                }
                if (is_object($existing_after_insert) && !empty($existing_after_insert->id)) {
                    if (!self::sync_queue_payload_matches($existing_after_insert, $item)) {
                        return new WP_Error('wsm_sync_queue_id_conflict', 'این queue_id قبلاً با نوع عملیات یا payload دیگری ثبت شده است.', array('status' => 409));
                    }
                    $existing_status = isset($existing_after_insert->status) ? strtolower((string) $existing_after_insert->status) : '';
                    if ($existing_status === 'processed') {
                        $duplicates_ignored++;
                        continue;
                    }
                    $wpdb->update($table, array('status' => 'received', 'error_message' => null),
                        array('id' => (int) $existing_after_insert->id), array('%s', '%s'), array('%d'));
                    if (!empty($wpdb->last_error)) {
                        return new WP_Error('wsm_sync_logs_unavailable', 'بازگشایی آیتم ناموفق قبلی انجام نشد.', array('status' => 500));
                    }
                    $replayed++;
                    $received++;
                    $new_queue_ids[$item['queue_id']] = true;
                    continue;
                }
                if ($insert_error !== '') { error_log('[WSM Sync] Failed to insert an item into the sync inbox.'); }
                return new WP_Error('wsm_sync_log_write_failed', 'ثبت آیتم در جدول لاگ همگام‌سازی انجام نشد.', array('status' => 500));
            }

            // The same lock covers insertion and replay, so no second request can claim the same received row.
            $processor = self::process_sync_batch_locked($device);
            if (is_wp_error($processor)) { return $processor; }
            $batch_processed = 0;
            $batch_failed = 0;
            $outcomes = array();
            $failed_items = array();
            foreach (array_keys($new_queue_ids) as $queue_id) {
                $outcome = isset($processor['outcomes'][$queue_id]) ? $processor['outcomes'][$queue_id] : array(
                    'queue_id' => $queue_id,
                    'action_type' => '',
                    'status' => 'failed',
                    'code' => 'wsm_sync_processing_incomplete',
                    'message' => 'پردازش این آیتم روی سرور کامل نشد؛ دوباره تلاش کنید.',
                    'http_status' => 500,
                );
                if (!isset($outcome['queue_id'])) { $outcome['queue_id'] = $queue_id; }
                $outcomes[$queue_id] = $outcome;
                if (isset($outcome['status']) && $outcome['status'] === 'processed') {
                    $batch_processed++;
                } else {
                    $batch_failed++;
                    $failed_items[] = $outcome;
                }
            }
            foreach ($validated_items as $item) {
                if (isset($outcomes[$item['queue_id']])) { continue; }
                $duplicate_outcome = array(
                    'queue_id' => $item['queue_id'],
                    'action_type' => $item['action_type'],
                    'status' => 'duplicate',
                    'code' => '',
                    'message' => 'این آیتم پیش‌تر روی سرور با موفقیت ثبت شده است.',
                    'http_status' => 200,
                );
                $duplicate_data = self::sync_duplicate_result($item);
                if (is_array($duplicate_data)) { $duplicate_outcome['data'] = $duplicate_data; }
                $outcomes[$item['queue_id']] = $duplicate_outcome;
            }
            $first_error_message = !empty($failed_items) ? (string) $failed_items[0]['message'] : '';
            if ($first_error_message === '') { $first_error_message = 'دلیل خطا در جدول لاگ همگام‌سازی ثبت شد.'; }

            return array(
                'success' => true,
                'total_received' => $total_received,
                'received' => $received,
                'replayed' => $replayed,
                'processed' => $batch_processed,
                'failed' => $batch_failed,
                'duplicates_ignored' => $duplicates_ignored,
                'outcomes' => $outcomes,
                'failed_items' => $failed_items,
                'message' => $batch_failed > 0
                    ? 'پردازش ' . $batch_failed . ' مورد ناموفق بود: ' . $first_error_message
                    : 'داده‌ها دریافت و پردازش شدند.',
            );
        } finally {
            self::release_sync_lock($lock_name);
        }
    }

    /** A queue UUID is an idempotency key for one exact operation, not a reusable token. */
    private static function sync_queue_payload_matches($existing, $item) {
        if (!is_object($existing) || !is_array($item) || !isset($existing->action_type, $existing->payload)) { return false; }
        if ((string) $existing->action_type !== (string) $item['action_type']) { return false; }
        $stored_payload = (string) $existing->payload;
        $incoming_payload = isset($item['payload']) && is_string($item['payload']) ? $item['payload'] : '';
        return $incoming_payload !== '' && hash_equals(hash('sha256', $stored_payload), hash('sha256', $incoming_payload));
    }

    /** Return only the canonical ID needed to reconcile a duplicate offline member locally. */
    private static function sync_duplicate_result($item) {
        global $wpdb;
        if (!is_array($item) || (string) $item['action_type'] !== 'CREATE_MEMBER' || !class_exists('WSM_Club_Operations')) { return null; }
        $payload = json_decode((string) $item['payload'], true);
        if (!is_array($payload)) { return null; }
        $offline_uuid = isset($payload['member_uuid']) && is_string($payload['member_uuid']) ? strtolower(trim($payload['member_uuid'])) : (isset($payload['uuid']) && is_string($payload['uuid']) ? strtolower(trim($payload['uuid'])) : '');
        if (!self::valid_sync_uuid($offline_uuid)) { return null; }
        $wpdb->last_error = '';
        $member_id = WSM_Club_Operations::find_sync_member_id($offline_uuid);
        if (is_wp_error($member_id) || (int) $member_id < 1) { return null; }
        $wpdb->last_error = '';
        $member = $wpdb->get_row($wpdb->prepare('SELECT id, member_code FROM ' . WSM_Club::table('members') . ' WHERE id = %d LIMIT 1', (int) $member_id));
        if (!empty($wpdb->last_error) || !is_object($member) || (int) $member->id < 1) { return null; }
        return array('id' => (int) $member->id, 'member_code' => isset($member->member_code) ? (string) $member->member_code : '', 'merged' => true, 'idempotent_replay' => true);
    }

    private static function is_sqlite_database() {
        global $wpdb;
        $class = isset($wpdb->dbh) && is_object($wpdb->dbh) ? get_class($wpdb->dbh) : '';
        return stripos($class, 'sqlite') !== false;
    }

    /** MySQL advisory lock; SQLite uses an exclusive local file lock instead of unsupported GET_LOCK(). */
    private static function acquire_sync_lock($timeout = 10) {
        global $wpdb;
        if (self::is_sqlite_database()) {
            if (is_resource(self::$sqlite_sync_lock_handle)) {
                return new WP_Error('wsm_sync_processor_busy', 'پردازش همگام‌سازی در حال اجرا است؛ دوباره تلاش کنید.', array('status' => 409));
            }
            $identity = (defined('DB_PATH') ? (string) DB_PATH : '') . ':' . (string) $wpdb->prefix;
            $path = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR .
                'wsm_sync_' . substr(hash('sha256', $identity), 0, 40) . '.lock';
            $handle = @fopen($path, 'c');
            if (!$handle) { return new WP_Error('wsm_sync_processor_busy', 'قفل محلی همگام‌سازی در دسترس نیست.', array('status' => 503)); }
            $deadline = microtime(true) + max(0, (int) $timeout);
            do {
                if (@flock($handle, LOCK_EX | LOCK_NB)) {
                    self::$sqlite_sync_lock_handle = $handle;
                    return 'sqlite-file-lock';
                }
                if (microtime(true) >= $deadline) { break; }
                usleep(100000);
            } while (true);
            fclose($handle);
            return new WP_Error('wsm_sync_processor_busy', 'پردازش همگام‌سازی در حال اجرا است؛ دوباره تلاش کنید.', array('status' => 409));
        }
        $lock_name = 'wsm_sync_' . substr(hash('sha256', (string) $wpdb->prefix), 0, 48);
        $result = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $lock_name, max(0, (int) $timeout)));
        if ((string) $result === '1') { return $lock_name; }
        $status = ((string) $result === '0') ? 409 : 503;
        return new WP_Error('wsm_sync_processor_busy', 'پردازش همگام‌سازی در حال اجرا است؛ دوباره تلاش کنید.', array('status' => $status));
    }

    private static function release_sync_lock($lock_name) {
        global $wpdb;
        if ((string) $lock_name === 'sqlite-file-lock') {
            $handle = self::$sqlite_sync_lock_handle;
            self::$sqlite_sync_lock_handle = null;
            if (is_resource($handle)) { @flock($handle, LOCK_UN); @fclose($handle); }
            return;
        }
        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', (string) $lock_name));
    }

    /** Public internal entry point for retrying all received rows under the same lock. */
    public static function process_sync_batch() {
        $lock_name = self::acquire_sync_lock(10);
        if (is_wp_error($lock_name)) { return $lock_name; }
        try {
            $fallback_device = WSM_Permissions::current_device();
            return self::process_sync_batch_locked($fallback_device);
        } finally {
            self::release_sync_lock($lock_name);
        }
    }

    /** Caller must hold the advisory lock. Every received row gets an isolated outcome. */
    private static function process_sync_batch_locked($fallback_device = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'wsm_sync_logs';
        $table_sql = '`' . str_replace('`', '``', $table) . '`';
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT id, queue_id, device_id, action_type, payload FROM ' . $table_sql . ' WHERE status = %s ORDER BY id ASC',
            'received'
        ));
        if (!empty($wpdb->last_error)) {
            return new WP_Error('wsm_sync_logs_unavailable', 'واکشی آیتم‌های دریافتی انجام نشد.', array('status' => 500));
        }

        $processed = 0;
        $failed = 0;
        $outcomes = array();
        foreach ((array) $rows as $row) {
            $row_id = is_object($row) && isset($row->id) ? (int) $row->id : 0;
            $queue_id = is_object($row) && isset($row->queue_id) ? strtolower((string) $row->queue_id) : '';
            $action_type = is_object($row) && isset($row->action_type) ? (string) $row->action_type : '';
            $failure = null;
            $result = null;

            try {
                $result = self::process_sync_log_record($row, $fallback_device);
            } catch (Throwable $exception) {
                $failure = array(
                    'code' => 'wsm_sync_processing_exception',
                    'message' => self::sync_error_message($exception),
                    'status' => 500,
                );
            }

            if ($failure === null && is_wp_error($result)) {
                // Keep the WP_Error code so the app can explain the real cause instead of a generic sentence.
                $error_data = $result->get_error_data();
                $failure = array(
                    'code' => (string) $result->get_error_code(),
                    'message' => (string) $result->get_error_message(),
                    'status' => is_array($error_data) && isset($error_data['status']) ? (int) $error_data['status'] : 400,
                );
            }

            if ($failure !== null) {
                if (!isset($failure['message']) || trim((string) $failure['message']) === '') {
                    $failure['message'] = 'پردازش آیتم همگام‌سازی ناموفق بود.';
                }
                $updated = $wpdb->update($table, array('status' => 'failed', 'error_message' => self::sync_failure_storage_message($failure)),
                    array('id' => $row_id, 'status' => 'received'),
                    array('%s', '%s'), array('%d', '%s'));
                if ($updated === false || (int) $updated < 1) {
                    error_log('[WSM Sync] Could not persist a failed processing state.');
                }
                $failed++;
                $outcomes[$queue_id] = array(
                    'queue_id' => $queue_id,
                    'action_type' => $action_type,
                    'status' => 'failed',
                    'code' => (string) $failure['code'],
                    'message' => (string) $failure['message'],
                    'http_status' => (int) $failure['status'],
                );
                continue;
            }

            $updated = $wpdb->update($table, array('status' => 'processed', 'error_message' => null),
                array('id' => $row_id, 'status' => 'received'),
                array('%s', '%s'), array('%d', '%s'));
            if ($updated === false || (int) $updated < 1) {
                $failed++;
                $outcomes[$queue_id] = array(
                    'queue_id' => $queue_id,
                    'action_type' => $action_type,
                    'status' => 'failed',
                    'code' => 'wsm_sync_log_status_failed',
                    'message' => 'به‌روزرسانی وضعیت آیتم به processed انجام نشد.',
                    'http_status' => 500,
                );
                continue;
            }
            $processed++;
            $outcomes[$queue_id] = array(
                'queue_id' => $queue_id,
                'action_type' => $action_type,
                'status' => 'processed',
                'code' => '',
                'message' => '',
                'http_status' => 200,
                'data' => is_array($result) ? $result : array(),
            );
        }
        return array('processed' => $processed, 'failed' => $failed, 'outcomes' => $outcomes);
    }

    /** Readable, bounded text stored in wsm_sync_logs.error_message (code is kept for later diagnosis). */
    private static function sync_failure_storage_message($failure) {
        $code = is_array($failure) && isset($failure['code']) ? trim((string) $failure['code']) : '';
        $message = is_array($failure) && isset($failure['message']) ? trim((string) $failure['message']) : '';
        $stored = $code !== '' ? '[' . $code . '] ' . $message : $message;
        if ($stored === '') { $stored = 'پردازش آیتم همگام‌سازی ناموفق بود.'; }
        if (function_exists('mb_substr')) { return mb_substr($stored, 0, 4000, 'UTF-8'); }
        return substr($stored, 0, 12000);
    }

    /**
     * Timestamp for the sync inbox/log tables.
     * WSM_Core never had a now() method (it lives in WSM_Util), so the old
     * WSM_Core::now() call raised "Call to undefined method" and killed the request
     * with an HTTP 500 before the queue row could even be written.
     */
    private static function sync_now() {
        if (function_exists('current_time')) {
            return current_time('mysql');
        }
        return gmdate('Y-m-d H:i:s');
    }

    private static function sync_error_message($exception) {
        $message = sanitize_textarea_field((string) $exception->getMessage());
        if ($message === '') { $message = 'پردازش آیتم همگام‌سازی ناموفق بود.'; }
        if (function_exists('mb_substr')) { return mb_substr($message, 0, 4000, 'UTF-8'); }
        return substr($message, 0, 12000);
    }

    /** Settings Outbox never accepts credentials, security policy, or an actor substitution. */
    private static function validate_sync_settings($payload, $device) {
        if (!is_array($payload) || array_diff(array_keys($payload), array('scope','changes','actor_user_id')) || !isset($payload['scope'],$payload['changes'],$payload['actor_user_id']) || !is_int($payload['actor_user_id']) || !$device || $payload['actor_user_id'] !== (int) $device->user_id || !is_array($payload['changes']) || !$payload['changes']) { return new WP_Error('wsm_sync_settings_invalid', 'ساختار یا هویت صف تنظیمات معتبر نیست.', array('status' => 403)); }
        if ($payload['scope'] === 'general') {
            if (!WSM_Devices::device_can($device, 'settings.edit')) { return new WP_Error('wsm_sync_settings_forbidden', 'مجوز تنظیمات عمومی برقرار نیست.', array('status' => 403)); }
            $allowed = array('settings_center','low_stock_threshold','expiry_alert_days','expiry_alert_email','expiry_alert_sms','expiry_alert_email_to','expiry_meta_key');
            if (array_diff(array_keys($payload['changes']), $allowed)) { return new WP_Error('wsm_sync_settings_sensitive', 'ذخیرهٔ آفلاین تنظیمات حساس مجاز نیست.', array('status' => 403)); }
            if (isset($payload['changes']['settings_center'])) {
                if (!is_array($payload['changes']['settings_center'])) { return new WP_Error('wsm_sync_settings_invalid', 'ساختار تنظیمات معتبر نیست.', array('status' => 400)); }
                foreach (array_keys($payload['changes']['settings_center']) as $key) { if (strpos((string) $key, 'security_') === 0) { return new WP_Error('wsm_sync_settings_sensitive', 'تنظیمات امنیتی فقط به‌صورت آنلاین ذخیره می‌شوند.', array('status' => 403)); } }
                $valid = self::sanitize_settings_center($payload['changes']['settings_center'], WSM_Util::settings());
                if (is_wp_error($valid)) { return $valid; }
            }
        } elseif ($payload['scope'] === 'club') {
            $full = WSM_Devices::device_can($device, 'club.settings.manage');
            $sms = WSM_Devices::device_can($device, 'club.sms.templates.manage') || WSM_Devices::device_can($device, 'club.sms.manage');
            if (!$full && (!$sms || array_diff(array_keys($payload['changes']), array('sms_append_portal_url','sms_expiry_days_before','sms_templates','sms_events')))) { return new WP_Error('wsm_sync_settings_forbidden', 'مجوز تنظیمات باشگاه برقرار نیست.', array('status' => 403)); }
            if (array_diff(array_keys($payload['changes']), array('sms_append_portal_url','sms_expiry_days_before','sms_templates','sms_events','portal_enabled','portal_default_amount','portal_default_gateway'))) { return new WP_Error('wsm_sync_settings_sensitive', 'تنظیمات حساس پورتال/درگاه در صف آفلاین پذیرفته نمی‌شود.', array('status' => 403)); }
        } else { return new WP_Error('wsm_sync_settings_scope', 'دامنهٔ تنظیمات آفلاین معتبر نیست.', array('status' => 400)); }
        return true;
    }

    private static function process_sync_settings($payload, $device) {
        $valid = self::validate_sync_settings($payload, $device);
        if (is_wp_error($valid)) { return $valid; }
        wp_set_current_user((int) $device->user_id);
        if ($payload['scope'] === 'club') { return WSM_Club_Operations::update_settings($payload['changes']); }
        $request = new WP_REST_Request('PUT', '/wsm/v1/settings');
        $request->set_header('Content-Type', 'application/json');
        $request->set_body(wp_json_encode($payload['changes']));
        return self::settings_update($request);
    }

    private static function process_sync_log_record($row, $fallback_device = null) {
        if (!is_object($row) || !isset($row->action_type, $row->payload)) {
            return new WP_Error('wsm_sync_record_invalid', 'ساختار رکورد لاگ همگام‌سازی معتبر نیست.', array('status' => 400));
        }
        $payload = json_decode((string) $row->payload, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($payload)) {
            return new WP_Error('wsm_sync_payload_invalid', 'JSON ذخیره‌شدهٔ آیتم معتبر نیست.', array('status' => 400));
        }

        $device_id = isset($row->device_id) ? (int) $row->device_id : 0;
        $device = $device_id > 0 ? WSM_Devices::find($device_id) : $fallback_device;
        if (!$device || !is_object($device) || empty($device->id)) {
            return new WP_Error('wsm_sync_device_missing', 'دستگاه مبدأ این آیتم پیدا نشد.', array('status' => 403));
        }
        if (!isset($device->status) || $device->status !== 'active') {
            return new WP_Error('wsm_sync_device_inactive', 'دستگاه مبدأ دیگر فعال نیست.', array('status' => 403));
        }

        $previous_device = WSM_Permissions::current_device();
        $previous_user_id = get_current_user_id();
        try {
            WSM_Permissions::set_device($device);
            $user_id = isset($device->user_id) ? (int) $device->user_id : 0;
            if ($user_id < 1 || !get_userdata($user_id) || get_user_meta($user_id, 'wsm_app_user_status', true) === 'inactive') {
                return new WP_Error('wsm_sync_account_inactive', 'حساب کاربر دستگاه مبدأ فعال نیست.', array('status' => 403));
            }
            if ($row->action_type === 'CREATE_SALE') {
                if (!WSM_Devices::device_can($device, 'club.pos.create')) {
                    return new WP_Error('wsm_sync_permission_denied', 'دستگاه مبدأ مجوز ثبت فروش ندارد.', array('status' => 403));
                }
                return self::process_sync_sale($payload, (string) $row->queue_id);
            }
            if ($row->action_type === 'CHANGE_ORDER_STATUS') {
                if (!WSM_Devices::device_can($device, 'orders.change_status')) {
                    return new WP_Error('wsm_sync_permission_denied', 'دستگاه مبدأ مجوز تغییر وضعیت سفارش را ندارد.', array('status' => 403));
                }
                $order_id = isset($payload['order_id']) && is_scalar($payload['order_id']) ? absint($payload['order_id']) : 0;
                $status = isset($payload['status']) && is_scalar($payload['status']) ? (string) $payload['status'] : '';
                $note = isset($payload['note']) && is_scalar($payload['note']) ? (string) $payload['note'] : '';
                if ($order_id < 1 || $status === '') {
                    return new WP_Error('wsm_sync_order_status_invalid', 'شناسه یا وضعیت سفارش آفلاین معتبر نیست.', array('status' => 400));
                }
                return WSM_Orders::set_status($order_id, $status, $note);
            }
            if ($row->action_type === 'CREATE_MEMBER') {
                if (!WSM_Devices::device_can($device, 'club.members.manage')) {
                    return new WP_Error('wsm_sync_permission_denied', 'دستگاه مبدأ مجوز ثبت عضو ندارد.', array('status' => 403));
                }
                return self::process_sync_member($payload);
            }
            if ($row->action_type === 'CREATE_MEMBERSHIP') {
                if (!WSM_Devices::device_can($device, 'club.members.manage')) {
                    return new WP_Error('wsm_sync_permission_denied', 'دستگاه مبدأ مجوز ثبت عضویت ندارد.', array('status' => 403));
                }
                $received = isset($payload['received_amount']) && is_scalar($payload['received_amount']) ? (float) $payload['received_amount'] : 0;
                if ($received > 0 && !WSM_Devices::device_can($device, 'club.billing.manage') && !WSM_Devices::device_can($device, 'club.payments.create')) {
                    return new WP_Error('wsm_sync_payment_permission_denied', 'دستگاه مبدأ مجوز ثبت دریافت شهریه را ندارد.', array('status' => 403));
                }
                return self::process_sync_membership($payload);
            }
            if ($row->action_type === 'CREATE_MESSAGE') {
                return WSM_Club_Operations::create_internal_message($payload, $user_id);
            }
            if ($row->action_type === 'UPDATE_SETTINGS') { return self::process_sync_settings($payload, $device); }
            if ($row->action_type === 'UPDATE_USER') {
                if (!WSM_Devices::device_can($device, 'users.manage') && !WSM_Devices::device_can($device, 'club.users.manage')) { return new WP_Error('wsm_sync_permission_denied', 'مجوز تغییر کاربران دیگر برقرار نیست.', array('status' => 403)); }
                if (array_diff(array_keys($payload), array('id','status','actor_user_id')) || empty($payload['id']) || !isset($payload['status'], $payload['actor_user_id']) || (int) $payload['actor_user_id'] !== $user_id || !in_array($payload['status'], array('active','inactive'), true)) { return new WP_Error('wsm_sync_user_payload_invalid', 'اطلاعات صف کاربر معتبر نیست.', array('status' => 403)); }
                return WSM_Auth::update_app_user((int) $payload['id'], array('status' => $payload['status']));
            }
            if ($row->action_type === 'SEND_CLUB_SMS') {
                if (!WSM_Devices::device_can($device, 'club.sms.manage') &&
                    !WSM_Devices::device_can($device, 'club.sms.send') &&
                    !WSM_Devices::device_can($device, 'club.sms.bulk_send')) {
                    return new WP_Error('wsm_sync_permission_denied', 'دستگاه مبدأ مجوز ارسال پیامک ندارد.', array('status' => 403));
                }
                wp_set_current_user($user_id);
                return WSM_Club_Operations::send_sms($payload);
            }
            return new WP_Error('wsm_sync_action_unknown', 'نوع عملیات ثبت‌شده پشتیبانی نمی‌شود.', array('status' => 400));
        } finally {
            WSM_Permissions::set_device($previous_device);
            wp_set_current_user($previous_user_id);
        }
    }

    private static function valid_sync_uuid($value) {
        return is_string($value) && preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) === 1;
    }

    private static function process_sync_membership($payload) {
        if (!is_array($payload)) {
            return new WP_Error('wsm_sync_membership_invalid', 'اطلاعات عضویت آفلاین معتبر نیست.', array('status' => 400));
        }
        return WSM_Club::create_membership_from_sync($payload);
    }

    private static function process_sync_member($payload) {
        $offline_uuid = '';
        if (array_key_exists('member_uuid', $payload) && $payload['member_uuid'] !== null && $payload['member_uuid'] !== '') {
            if (!is_string($payload['member_uuid'])) {
                return new WP_Error('wsm_sync_member_uuid_invalid', 'member_uuid عضو آفلاین معتبر نیست.', array('status' => 400));
            }
            $offline_uuid = $payload['member_uuid'];
        } elseif (isset($payload['uuid']) && is_string($payload['uuid'])) {
            $offline_uuid = $payload['uuid'];
        }
        if (!self::valid_sync_uuid($offline_uuid)) {
            return new WP_Error('wsm_sync_member_uuid_invalid', 'member_uuid عضو آفلاین معتبر نیست.', array('status' => 400));
        }
        return WSM_Club_Operations::save_member_from_sync($payload, strtolower($offline_uuid));
    }

    private static function sync_order_id_by_meta($meta_key, $meta_value) {
        global $wpdb;
        $ids = WSM_Util::order_ids_with_meta($meta_key, $meta_value);
        if (!empty($wpdb->last_error)) {
            return new WP_Error('wsm_sync_order_lookup_failed', 'بررسی سفارش همگام‌شده انجام نشد.', array('status' => 500));
        }
        return !empty($ids) ? absint(reset($ids)) : 0;
    }

    private static function ensure_sync_invoice($order_id) {
        $order = wc_get_order((int) $order_id);
        if (!$order || $order->get_meta('_wsm_invoice')) {
            return new WP_Error('wsm_sync_order_missing', 'سفارش برای صدور فاکتور پیدا نشد.', array('status' => 404));
        }
        $linked_id = absint($order->get_meta('_wsm_linked_invoice_id'));
        if ($linked_id) {
            $invoice = wc_get_order($linked_id);
            if ($invoice && $invoice->get_meta('_wsm_invoice') && absint($invoice->get_meta('_wsm_source_order_id')) === (int) $order_id) {
                return true;
            }
        }

        // Recover a saved invoice if a crash happened before its source-order link was persisted.
        global $wpdb;
        $invoice_ids = WSM_Util::order_ids_with_meta('_wsm_source_order_id', (string) (int) $order_id);
        if (!empty($wpdb->last_error)) {
            return new WP_Error('wsm_sync_invoice_lookup_failed', 'بررسی فاکتور قبلی فروش انجام نشد.', array('status' => 500));
        }
        foreach ((array) $invoice_ids as $invoice_id) {
            $candidate = wc_get_order((int) $invoice_id);
            if ($candidate && $candidate->get_meta('_wsm_invoice') && absint($candidate->get_meta('_wsm_source_order_id')) === (int) $order_id) {
                $order->update_meta_data('_wsm_linked_invoice_id', (int) $invoice_id);
                $order->save_meta_data();
                return true;
            }
        }
        $created = WSM_Invoices::create_from_order((int) $order_id);
        if (is_wp_error($created)) { return $created; }
        $order = wc_get_order((int) $order_id);
        $linked_id = $order ? absint($order->get_meta('_wsm_linked_invoice_id')) : 0;
        $invoice = $linked_id ? wc_get_order($linked_id) : false;
        if (!$invoice || !$invoice->get_meta('_wsm_invoice') || absint($invoice->get_meta('_wsm_source_order_id')) !== (int) $order_id) {
            return new WP_Error('wsm_sync_invoice_failed', 'فاکتور فروش آفلاین ساخته نشد.', array('status' => 500));
        }
        return true;
    }

    private static function process_sync_sale($payload, $queue_id) {
        global $wpdb;
        $sale_uuid = isset($payload['sale_uuid']) && is_string($payload['sale_uuid']) ? strtolower(trim($payload['sale_uuid'])) : '';
        $queue_id = strtolower(trim((string) $queue_id));
        if (!self::valid_sync_uuid($queue_id) || !self::valid_sync_uuid($sale_uuid)) {
            return new WP_Error('wsm_sync_sale_uuid_invalid', 'queue_id یا sale_uuid فروش آفلاین معتبر نیست.', array('status' => 400));
        }

        if (array_key_exists('create_invoice', $payload) && !is_scalar($payload['create_invoice'])) {
            return new WP_Error('wsm_sync_invoice_flag_invalid', 'پرچم صدور فاکتور معتبر نیست.', array('status' => 400));
        }
        if (array_key_exists('paid', $payload) && !is_scalar($payload['paid'])) {
            return new WP_Error('wsm_sync_payment_flag_invalid', 'وضعیت پرداخت فروش آفلاین معتبر نیست.', array('status' => 400));
        }
        if (array_key_exists('discount_approval_token', $payload) && (!is_string($payload['discount_approval_token']) || strlen($payload['discount_approval_token']) > 8192)) {
            return new WP_Error('wsm_sync_discount_token_invalid', 'مجوز امضاشدهٔ تخفیف فروش آفلاین معتبر نیست.', array('status' => 400));
        }
        if (array_key_exists('manager_password', $payload) || array_key_exists('manager_username', $payload)) {
            return new WP_Error('wsm_sync_finance_credentials_forbidden', 'اطلاعات ورود مدیر هرگز در صف آفلاین پذیرفته نمی‌شود.', array('status' => 400));
        }
        $create_invoice = isset($payload['create_invoice']) && rest_sanitize_boolean($payload['create_invoice']);
        if ($create_invoice && !WSM_Devices::device_can(WSM_Permissions::current_device(), 'invoices.create')) {
            return new WP_Error('wsm_sync_invoice_forbidden', 'دستگاه مبدأ مجوز صدور فاکتور ندارد.', array('status' => 403));
        }

        // Recover a previously-created order if the request died before its log status changed.
        $order_id = self::sync_order_id_by_meta('_wsm_offline_queue_id', $queue_id);
        if (is_wp_error($order_id)) { return $order_id; }
        if (!$order_id) {
            $order_id = self::sync_order_id_by_meta('_wsm_offline_sale_uuid', $sale_uuid);
            if (is_wp_error($order_id)) { return $order_id; }
        }
        if ($order_id) {
            $existing_order = wc_get_order((int) $order_id);
            if (!$existing_order || !rest_sanitize_boolean($existing_order->get_meta('_wsm_offline_sync_complete'))) {
                return new WP_Error('wsm_sync_sale_replay_incomplete', 'برای این UUID سفارش ناقص موجود است؛ از ساخت سفارش تکراری جلوگیری شد و بررسی دستی لازم است.', array('status' => 409));
            }
            if ($create_invoice) {
                $invoice = self::ensure_sync_invoice($order_id);
                if (is_wp_error($invoice)) { return $invoice; }
            }
            $replay_result = array('order_id' => (int) $order_id, 'idempotent_replay' => true);
            $replay_member_id = absint($existing_order->get_meta('_wsm_club_member_id'));
            if ($replay_member_id > 0) {
                $replay_result['member_id'] = $replay_member_id;
                $replay_result['member_balance_due'] = (float) WSM_Club::balance_due($replay_member_id);
                $replay_pos_debts = WSM_Club_Operations::pos_debt_by_member(array($replay_member_id));
                if (is_wp_error($replay_pos_debts)) {
                    return new WP_Error('wsm_sync_sale_replay_debt_failed', 'فروش قبلی شناسایی شد، اما بازخوانی ماندهٔ بدهی عضو ناموفق بود؛ همگام‌سازی باید دوباره تلاش شود.', array('status' => 500));
                }
                $replay_result['member_pos_debt_due'] = isset($replay_pos_debts[$replay_member_id]) ? (float) $replay_pos_debts[$replay_member_id] : 0.0;
                $replay_result['member_total_debt_due'] = $replay_result['member_balance_due'] + $replay_result['member_pos_debt_due'];
            }
            return $replay_result;
        }

        if (!isset($payload['items']) || !is_array($payload['items']) || !$payload['items']) {
            return new WP_Error('wsm_sync_sale_items_invalid', 'فهرست اقلام فروش آفلاین خالی یا نامعتبر است.', array('status' => 400));
        }
        $items = array();
        foreach ($payload['items'] as $item) {
            if (!is_array($item)) {
                return new WP_Error('wsm_sync_sale_item_invalid', 'یکی از اقلام فروش آفلاین معتبر نیست.', array('status' => 400));
            }
            $sku = isset($item['sku']) && is_scalar($item['sku']) ? (string) $item['sku'] : '';
            $raw_product_id = isset($item['product_id']) && is_scalar($item['product_id']) ? (string) $item['product_id'] : '';
            $product_id = preg_match('/^\d+$/D', $raw_product_id) ? absint($raw_product_id) : 0;
            if (!isset($item['qty']) || !is_scalar($item['qty'])) {
                return new WP_Error('wsm_sync_sale_quantity_invalid', 'تعداد یکی از اقلام فروش آفلاین معتبر نیست.', array('status' => 400));
            }
            $items[] = array('product_id' => $product_id, 'sku' => $sku, 'qty' => $item['qty']);
        }

        $member_identifier = isset($payload['member_identifier']) && is_scalar($payload['member_identifier']) ? trim((string) $payload['member_identifier']) : '';
        $member_uuid = '';
        if (array_key_exists('member_uuid', $payload) && $payload['member_uuid'] !== null && $payload['member_uuid'] !== '') {
            if (!is_string($payload['member_uuid'])) {
                return new WP_Error('wsm_sync_member_uuid_invalid', 'member_uuid فروش آفلاین معتبر نیست.', array('status' => 400));
            }
            $member_uuid = trim($payload['member_uuid']);
        }
        if ($member_uuid !== '') {
            if (!self::valid_sync_uuid($member_uuid)) {
                return new WP_Error('wsm_sync_member_uuid_invalid', 'member_uuid فروش آفلاین معتبر نیست.', array('status' => 400));
            }
            $mapped_member_id = WSM_Club_Operations::find_sync_member_id(strtolower($member_uuid));
            if (is_wp_error($mapped_member_id)) { return $mapped_member_id; }
            if ((int) $mapped_member_id > 0) {
                $member = $wpdb->get_row($wpdb->prepare(
                    'SELECT member_code, status FROM ' . WSM_Club::table('members') . ' WHERE id = %d LIMIT 1',
                    (int) $mapped_member_id
                ));
                if (!empty($wpdb->last_error)) {
                    return new WP_Error('wsm_sync_member_lookup_failed', 'خواندن عضو مرتبط با فروش انجام نشد.', array('status' => 500));
                }
                if (!$member || $member->status !== 'active') {
                    return new WP_Error('wsm_sync_member_inactive', 'عضو پیوندخورده با فروش آفلاین فعال نیست.', array('status' => 409));
                }
                $member_identifier = (string) $member->member_code;
            }
        }

        $method = isset($payload['method']) && is_scalar($payload['method']) ? (string) $payload['method'] : '';
        $sync_data = array(
            'items' => $items,
            'method' => $method,
            'paid' => array_key_exists('paid', $payload) ? $payload['paid'] : true,
            'discount_amount' => array_key_exists('discount_amount', $payload) ? $payload['discount_amount'] : 0,
            'discount_approval_token' => isset($payload['discount_approval_token']) && is_string($payload['discount_approval_token']) ? $payload['discount_approval_token'] : '',
            'sale_uuid' => $sale_uuid,
            'reference' => isset($payload['reference']) && is_scalar($payload['reference']) ? (string) $payload['reference'] : '',
            'create_invoice' => $create_invoice,
        );
        if (array_key_exists('currency', $payload)) { $sync_data['currency'] = $payload['currency']; }
        if ($member_identifier !== '') { $sync_data['member_identifier'] = $member_identifier; }

        $result = WSM_Club_Operations::create_pos_order($sync_data, array('queue_id' => $queue_id, 'sale_uuid' => $sale_uuid));
        if (is_wp_error($result)) { return $result; }
        if (!is_array($result) || empty($result['order_id'])) {
            return new WP_Error('wsm_sync_sale_create_failed', 'ساخت سفارش فروش آفلاین نتیجهٔ معتبری برنگرداند.', array('status' => 500));
        }
        if ($create_invoice) {
            $invoice = self::ensure_sync_invoice((int) $result['order_id']);
            if (is_wp_error($invoice)) { return $invoice; }
        }
        return $result;
    }

    /* ---------------- نشست ---------------- */

    public static function auth_recovery_request($request) {
        $b = self::body($request);
        return WSM_Auth::request_password_reset(isset($b['identifier']) ? $b['identifier'] : '');
    }

    public static function auth_recovery_reset($request) {
        $b = self::body($request);
        return WSM_Auth::reset_password(isset($b['identifier']) ? $b['identifier'] : '', isset($b['code']) ? $b['code'] : '', isset($b['new_password']) ? $b['new_password'] : '');
    }

    public static function auth_login($request) {
        $b = self::body($request);
        $remember = isset($b['remember']) && is_scalar($b['remember']) ? rest_sanitize_boolean($b['remember']) : false;
        $identifier = isset($b['identifier']) && is_scalar($b['identifier']) && trim((string) $b['identifier']) !== '' ? $b['identifier'] : (isset($b['username']) ? $b['username'] : '');
        return WSM_Auth::login($identifier, isset($b['password']) ? $b['password'] : '', array(
            'client_id' => isset($b['client_id']) ? $b['client_id'] : '',
            'device_name' => isset($b['device_name']) ? $b['device_name'] : '',
            'platform' => isset($b['platform']) ? $b['platform'] : '',
            'os_version' => isset($b['os_version']) ? $b['os_version'] : '',
            'app_version' => isset($b['app_version']) ? $b['app_version'] : '',
        ), $remember);
    }

    public static function auth_login_otp_request($request) {
        $b = self::body($request);
        $phone = isset($b['phone']) ? $b['phone'] : (isset($b['identifier']) ? $b['identifier'] : '');
        return WSM_Auth::request_login_otp($phone);
    }

    public static function auth_login_otp_verify($request) {
        $b = self::body($request);
        $remember = isset($b['remember']) && is_scalar($b['remember']) ? rest_sanitize_boolean($b['remember']) : false;
        return WSM_Auth::verify_login_otp(isset($b['phone']) ? $b['phone'] : '', isset($b['code']) ? $b['code'] : '', array(
            'client_id' => isset($b['client_id']) ? $b['client_id'] : '',
            'device_name' => isset($b['device_name']) ? $b['device_name'] : '',
            'platform' => isset($b['platform']) ? $b['platform'] : '',
            'os_version' => isset($b['os_version']) ? $b['os_version'] : '',
            'app_version' => isset($b['app_version']) ? $b['app_version'] : '',
        ), $remember);
    }

    public static function handshake($request) {
        if (!WSM_Util::is_woo_active()) {
            return WSM_Util::woo_required_error();
        }
        $b = self::body($request);
        return WSM_Auth::handshake(
            isset($b['access_key']) ? (string) $b['access_key'] : '',
            array(
                'client_id' => isset($b['client_id']) && is_scalar($b['client_id']) ? (string) $b['client_id'] : '',
                'device_name' => isset($b['device_name']) ? $b['device_name'] : '',
                'platform'    => isset($b['platform']) ? $b['platform'] : '',
                'os_version'  => isset($b['os_version']) ? $b['os_version'] : '',
                'app_version' => isset($b['app_version']) ? $b['app_version'] : '',
            )
        );
    }

    public static function refresh($request) {
        $b = self::body($request);
        return WSM_Auth::refresh(isset($b['refresh_token']) ? (string) $b['refresh_token'] : '');
    }

    public static function logout() {
        $device = WSM_Permissions::current_device();
        if ($device) {
            $result = WSM_Devices::set_status((int) $device->id, 'logout');
            if (is_wp_error($result)) { return $result; }
        }
        return array('ok' => true);
    }

    public static function user_key_issue($request) { return WSM_Auth::manage_user_access_key(self::id($request)); }
    public static function user_key_revoke($request) { return WSM_Auth::manage_user_access_key(self::id($request), true); }
    public static function user_force_logout($request) { return WSM_Auth::force_logout_user(self::id($request)); }
    public static function user_audit($request) { return WSM_Auth::user_audit(self::id($request)); }

    public static function app_users($request) { return WSM_Auth::list_app_users(); }

    public static function app_user_create($request) { return WSM_Auth::create_app_user(self::body($request)); }

    public static function app_user_update($request) { return WSM_Auth::update_app_user(self::id($request), self::body($request)); }

    public static function app_user_delete($request) { return WSM_Auth::delete_app_user(self::id($request)); }

    public static function profile_get() { return WSM_Auth::profile(); }

    public static function profile_update($request) { return WSM_Auth::update_profile(self::body($request)); }

    /** Return a single permission-scoped payload for first app load. */
    /**
     * Build the bootstrap profile without repeated permission-table reads.
     * This only serializes grants for the UI; check_request and each route's
     * permission callback remain the authorization source of truth.
     */
    private static function normalize_app_init_permissions($permissions, $catalog) {
        $clean = array();
        foreach ((array) $permissions as $permission) {
            if ($permission === 'users.super_admin.assign') { continue; }
            if (is_string($permission) && isset($catalog[$permission]) && !in_array($permission, $clean, true)) {
                $clean[] = $permission;
            }
        }
        if (in_array('users.manage', $clean, true) && isset($catalog['club.users.manage']) && !in_array('club.users.manage', $clean, true)) {
            $clean[] = 'club.users.manage';
        }
        if (in_array('club.users.manage', $clean, true) && isset($catalog['users.manage']) && !in_array('users.manage', $clean, true)) {
            $clean[] = 'users.manage';
        }
        return $clean;
    }

    private static function app_init_profile($device, $settings) {
        $user_id = (int) $device->user_id;
        // check_request() already loaded and installed the authenticated user. Reuse that
        // WP_User object; the fallback get_userdata() path uses WordPress's users cache.
        $user = function_exists('wp_get_current_user') ? wp_get_current_user() : false;
        if (!$user || !is_object($user) || (int) $user->ID !== $user_id) {
            $user = get_userdata($user_id);
        }
        $wp_admin = WSM_Permissions::is_wordpress_admin_user($user);
        $record = $wp_admin ? null : WSM_Permissions::user_permissions_record($user_id);
        $app_role = sanitize_key((string) get_user_meta($user_id, 'wsm_app_role', true));
        $presets = WSM_Permissions::presets();
        $catalog = WSM_Devices::permission_catalog();
        $all_permissions = array_keys($catalog);
        $is_super_admin = $wp_admin || ($record !== null && $record['preset'] === 'super_admin') || $app_role === 'super_admin';

        if ($is_super_admin) {
            $permissions = $all_permissions;
            $device_permissions = $all_permissions;
        } else {
            if ($record !== null) {
                $user_permissions = self::normalize_app_init_permissions($record['permissions'], $catalog);
            } elseif ($app_role !== '' && isset($presets[$app_role])) {
                $user_permissions = self::normalize_app_init_permissions($presets[$app_role]['permissions'], $catalog);
            } else {
                $user_permissions = null;
            }
            // Keep app-init grants aligned with the REST permission resolver: the
            // explicit WooCommerce capability grants order-status changes, but does
            // not widen the account to general order editing or refund permissions.
            if ($user_permissions !== null && $user && user_can($user, 'wsm_orders_edit')
                && isset($catalog['orders.change_status']) && !in_array('orders.change_status', $user_permissions, true)) {
                $user_permissions[] = 'orders.change_status';
            }

            $has_device_permissions = property_exists($device, 'permissions') && $device->permissions !== null && $device->permissions !== '';
            if (!$has_device_permissions) {
                $legacy = array('dashboard.view','products.view','products.create','products.edit','products.delete',
                    'orders.view','orders.create','orders.edit','orders.change_status','orders.refund','orders.delete','orders.history',
                    'invoices.view','invoices.create','invoices.edit','invoices.change_status','invoices.delete','invoices.print',
                    'customers.view','reports.view','devices.view','devices.manage','activity.view','settings.view','settings.edit');
                $device_permissions = array_values(array_intersect($legacy, array_keys($catalog)));
            } else {
                $raw = is_array($device->permissions) ? $device->permissions : json_decode((string) $device->permissions, true);
                if (!is_array($raw)) {
                    $device_permissions = WSM_Devices::default_permissions();
                } else {
                    $device_permissions = array();
                    foreach ($raw as $permission) {
                        if (is_string($permission) && isset($catalog[$permission]) && !in_array($permission, $device_permissions, true)) {
                            $device_permissions[] = $permission;
                        }
                    }
                }
            }

            if ($user_permissions === null) {
                $permissions = self::normalize_app_init_permissions($device_permissions, $catalog);
            } elseif (!$has_device_permissions) {
                $permissions = $user_permissions;
            } else {
                $normalized_device_permissions = self::normalize_app_init_permissions($device_permissions, $catalog);
                $permissions = self::normalize_app_init_permissions(array_intersect($user_permissions, $normalized_device_permissions), $catalog);
            }
        }

        $preset = $wp_admin ? 'super_admin' : ($record !== null ? $record['preset'] : $app_role);
        $is_super_admin = $preset === 'super_admin' || $wp_admin;
        $permission_count = $is_super_admin ? count($catalog) : count($permissions);
        $device_profile = array(
            'id' => (int) $device->id,
            'user_id' => $user_id,
            'user_login' => $user ? (string) $user->user_login : '',
            'display_name' => $user ? (string) $user->display_name : '',
            'device_name' => (string) $device->device_name,
            'platform' => (string) $device->platform,
            'os_version' => (string) $device->os_version,
            'app_version' => (string) $device->app_version,
            'ip_address' => (string) $device->ip_address,
            'status' => (string) $device->status,
            'remember_me' => isset($device->remember_me) ? (bool) $device->remember_me : false,
            'permissions' => $device_permissions,
            'block_reason' => (string) $device->block_reason,
            'last_seen' => wsm_fa_date(isset($device->last_seen) ? $device->last_seen : ''),
            'created_at' => wsm_fa_date(isset($device->created_at) ? $device->created_at : ''),
        );
        return array(
            'user' => $user ? $user->display_name : '',
            'user_id' => $user ? (int) $user->ID : 0,
            'role' => $preset,
            'role_label' => isset($presets[$preset]['label']) ? $presets[$preset]['label'] : 'سفارشی',
            'is_super_admin' => $is_super_admin,
            'is_wordpress_admin' => $user && in_array('administrator', (array) $user->roles, true),
            'permission_count' => $permission_count,
            'device' => $device_profile,
            'device_permissions' => $permissions,
            'permissions' => $permissions,
            'capabilities' => $permissions,
            'ticket_capabilities' => WSM_Permissions::ticket_capabilities_for_user($user_id),
            'store_name' => isset($settings['store_name']) ? $settings['store_name'] : '',
        );
    }

    public static function app_init($request) {
        self::arm_app_init_shutdown($request);
        $device = WSM_Permissions::current_device();
        if (!$device) {
            return new WP_Error('wsm_forbidden', 'دسترسی به این بخش ندارید.', array('status' => 401));
        }
        self::$app_init_auth_verified = true;

        // Keep the bootstrap small: profile and only the configuration needed to render the shell.
        // Reuse the computed profile grants instead of repeating permission-table lookups.
        $settings = WSM_Util::settings();
        $me = self::app_init_profile($device, $settings);
        $payload = array('me' => $me);
        $me_permissions = isset($me['device_permissions']) && is_array($me['device_permissions']) ? $me['device_permissions'] : array();
        if (in_array('settings.view', $me_permissions, true) || in_array('security.manage', $me_permissions, true)) {
            $payload['settings'] = array(
                'store_name'      => isset($settings['store_name']) ? $settings['store_name'] : '',
                'store_logo'      => isset($settings['store_logo']) ? $settings['store_logo'] : '',
                'ui_config'       => WSM_Util::clean_ui_config(isset($settings['ui_config']) ? $settings['ui_config'] : array()),
                'currency'        => get_woocommerce_currency(),
                'currency_symbol' => wsm_currency_symbol(),
                'version'         => WSM_VERSION,
            );
            // This is deliberately partial; the full /settings route remains lazy-loaded.
            $payload['settings_partial'] = true;
        }

        return $payload;
    }

    public static function me() {
        $device = WSM_Permissions::current_device();
        $user   = get_userdata((int) $device->user_id);
        $permissions = WSM_Permissions::effective_permissions($device);
        $record = WSM_Permissions::user_permissions_record((int) $device->user_id);
        $wp_admin = WSM_Permissions::is_wordpress_admin_user($user);
        $preset = $wp_admin ? 'super_admin' : ($record ? $record['preset'] : sanitize_key((string) get_user_meta((int) $device->user_id, 'wsm_app_role', true)));
        $is_super_admin = $preset === 'super_admin' || $wp_admin;
        if ($is_super_admin) {
            $permissions = array_keys(WSM_Devices::permission_catalog());
        }
        $permission_count = $is_super_admin ? count(WSM_Devices::permission_catalog()) : count($permissions);
        if (!WSM_Devices::device_can($device, 'security.manage')) {
            $permissions = array_values(array_diff($permissions, array('security.manage')));
        }
        $presets = WSM_Permissions::presets();
        return array(
            'user'               => $user ? $user->display_name : '',
            'user_id'            => $user ? (int) $user->ID : 0,
            'role'               => $preset,
            'role_label'         => isset($presets[$preset]['label']) ? $presets[$preset]['label'] : 'سفارشی',
            'is_super_admin'     => $is_super_admin,
            'is_wordpress_admin' => $user && in_array('administrator', (array) $user->roles, true),
            'permission_count'   => $permission_count,
            'device'             => WSM_Devices::format($device),
            'device_permissions' => $permissions,
            'permissions'        => $permissions,
            'capabilities'       => $permissions,
            'ticket_capabilities' => WSM_Permissions::ticket_capabilities_for_user((int) $device->user_id),
            'store_name'         => WSM_Util::settings()['store_name'],
        );
    }

    public static function settings() {
        $result = self::cached_rest_get('settings', '/settings', array(), array(__CLASS__, 'settings_uncached'));
        if (!is_array($result)) { return $result; }
        $device = WSM_Permissions::current_device();
        $is_super = $device && WSM_Permissions::is_wordpress_admin_user((int) $device->user_id) && WSM_Devices::device_can($device, 'users.super_admin.assign');
        $result['version'] = WSM_VERSION;
        $result['can_manage_security'] = (bool) $is_super;
        if (!$is_super) {
            unset($result['totp_required']);
            foreach (array_keys($result['settings_center'] ?? array()) as $key) {
                if (strpos($key, 'security_') === 0) { unset($result['settings_center'][$key]); }
            }
        }
        return $result;
    }

    public static function settings_runtime() {
        return WSM_Util::public_runtime_settings();
    }

    private static function settings_uncached() {
        $s = WSM_Util::settings();
        return array(
            'store_name'      => $s['store_name'],
            'store_logo'      => $s['store_logo'],
            'ui_config'       => WSM_Util::clean_ui_config(isset($s['ui_config']) ? $s['ui_config'] : array()),
            'postal_sender'   => array(
                'name'       => $s['postal_sender_name'],
                'company'    => $s['postal_sender_company'],
                'phone'      => $s['postal_sender_phone'],
                'email'      => $s['postal_sender_email'],
                'address_1'  => $s['postal_sender_address_1'],
                'address_2'  => $s['postal_sender_address_2'],
                'city'       => $s['postal_sender_city'],
                'state'      => $s['postal_sender_state'],
                'postcode'   => $s['postal_sender_postcode'],
                'country'    => $s['postal_sender_country'],
            ),
            'currency'        => get_woocommerce_currency(),
            'currency_symbol' => wsm_currency_symbol(),
            // Canonical values also drive POS, finance, reports and portal currency.
            'settings_center' => self::public_settings_center($s),
            'order_statuses'   => WSM_Orders::statuses(),
            'invoice_statuses' => WSM_Invoices::statuses(),
            'version'                    => WSM_VERSION,
            'expiry_alert_days'           => max(1, min(365, (int) $s['expiry_alert_days'])),
            'expiry_alert_email'          => !empty($s['expiry_alert_email']),
            'expiry_alert_sms'            => !empty($s['expiry_alert_sms']),
            'expiry_alert_email_to'       => !empty($s['expiry_alert_email_to']) ? $s['expiry_alert_email_to'] : get_option('admin_email'),
            'expiry_meta_key'             => WSM_Expiry::custom_meta_key(),
            'expiry_meta_key_in_use'      => WSM_Expiry::meta_key_in_use(),
            'expiry_meta_key_detected'    => WSM_Expiry::detected_meta_key(),
            'totp_required'               => !empty($s['totp_required']),
            // Reuse WooCommerce's existing global low-stock threshold; do not duplicate it in wsm_settings.
            'low_stock_threshold'         => max(0, min(1000000, (int) get_option('woocommerce_notify_low_stock_amount', 2))),
        );
    }

    /** Register the existing wsm_settings option with WordPress Settings API. */
    public static function register_settings_api_option() {
        if (!function_exists('register_setting')) { return; }
        register_setting('wsm_app_settings_group', 'wsm_settings', array(
            'type' => 'array',
            'sanitize_callback' => array(__CLASS__, 'sanitize_registered_settings_option'),
        ));
    }

    /** Preserve legacy option keys while sanitizing the Settings API option payload. */
    public static function sanitize_registered_settings_option($value) {
        $existing = get_option('wsm_settings', array());
        $existing = is_array($existing) ? $existing : array();
        if (!is_array($value)) { return $existing; }
        $merged = array_merge($existing, $value);
        if (array_key_exists('settings_center', $merged)) {
            $sanitized = self::sanitize_settings_center($merged['settings_center'], $merged);
            if (is_wp_error($sanitized)) {
                if (isset($existing['settings_center']) && is_array($existing['settings_center'])) { $merged['settings_center'] = $existing['settings_center']; }
                else { unset($merged['settings_center']); }
            } else { $merged = $sanitized; }
        }
        return $merged;
    }

    /** Return a safe, allow-listed view of settings-center fields stored inside wsm_settings. */
    private static function public_settings_center($settings) {
        return WSM_Util::runtime_settings($settings);
    }

    /** Validate a settings-center patch before any option is mutated. */
    private static function sanitize_settings_center($input, $settings) {
        if (!is_array($input)) {
            return new WP_Error('wsm_bad_settings_center', 'ساختار تنظیمات مرکز کنترل نامعتبر است.', array('status' => 400));
        }
        $current = self::public_settings_center($settings);
        if (array_diff(array_keys($input), array_keys($current))) { return new WP_Error('wsm_settings_unknown_field', 'فیلد ناشناخته در تنظیمات ارسال شده است.', array('status' => 400)); }
        foreach ($input as $key => $value) {
            if (is_bool($current[$key])) {
                $clean_bool = WSM_Util::settings_bool($value);
                if (is_wp_error($clean_bool)) { return $clean_bool; }
                $input[$key] = $clean_bool;
            }
        }
        foreach (array('pos_discount_limit'=>array(0,100,false),'finance_tax_rate'=>array(0,100,false),'members_max_freeze_days'=>array(1,365,true),'hardware_local_bridge_port'=>array(1,65535,true),'security_auto_logout_minutes'=>array(0,1440,true),'security_sync_interval_minutes'=>array(1,1440,true)) as $key => $bounds) {
            if (!array_key_exists($key, $input)) { continue; }
            $number = WSM_Util::settings_number($input[$key], $bounds[0], $bounds[1], $bounds[2]);
            if (is_wp_error($number)) { return $number; }
            $input[$key] = $number;
        }
        if (array_key_exists('security_require_admin_password', $input) && !$input['security_require_admin_password']) {
            return new WP_Error('wsm_sensitive_approval_required', 'تأیید مدیر برای عملیات حساس مالی و تخفیف قابل حذف نیست.', array('status' => 400));
        }
        $clean = $current;
        if (array_key_exists('store_name', $input)) {
            if (!is_scalar($input['store_name'])) { return new WP_Error('wsm_bad_settings_center_store', 'نام فروشگاه نامعتبر است.', array('status' => 400)); }
            $clean['store_name'] = trim(sanitize_text_field((string) $input['store_name']));
            if ($clean['store_name'] === '' || (function_exists('mb_strlen') ? mb_strlen($clean['store_name']) : strlen($clean['store_name'])) > 120) { return new WP_Error('wsm_bad_store_name', 'نام فروشگاه باید بین ۱ تا ۱۲۰ نویسه باشد.', array('status' => 400)); }
        }
        if (array_key_exists('currency', $input)) {
            if (!is_scalar($input['currency'])) { return new WP_Error('wsm_bad_settings_center_currency', 'واحد پول نامعتبر است.', array('status' => 400)); }
            $currency = sanitize_key((string) $input['currency']);
            if (!in_array($currency, array('toman', 'rial'), true)) { return new WP_Error('wsm_bad_settings_center_currency', 'واحد پول باید تومان یا ریال باشد.', array('status' => 400)); }
            $clean['currency'] = $currency;
        }
        if (array_key_exists('date_format', $input)) {
            if (!is_scalar($input['date_format'])) { return new WP_Error('wsm_bad_settings_center_date', 'فرمت تاریخ نامعتبر است.', array('status' => 400)); }
            $date_format = sanitize_key((string) $input['date_format']);
            if (!in_array($date_format, array('jalali', 'gregorian'), true)) { return new WP_Error('wsm_bad_settings_center_date', 'فرمت تاریخ باید شمسی یا میلادی باشد.', array('status' => 400)); }
            $clean['date_format'] = $date_format;
        }
        if (array_key_exists('timezone', $input)) {
            if (!is_scalar($input['timezone'])) { return new WP_Error('wsm_bad_settings_center_timezone', 'منطقهٔ زمانی نامعتبر است.', array('status' => 400)); }
            $timezone = trim(sanitize_text_field((string) $input['timezone']));
            $valid_timezones = timezone_identifiers_list(DateTimeZone::ALL_WITH_BC);
            $valid_offset = (bool) preg_match('/^[+-](?:(?:0[0-9]|1[0-3]):[0-5][0-9]|14:00)$/', $timezone);
            if ($timezone === '' || (!in_array($timezone, $valid_timezones, true) && $timezone !== 'UTC' && !$valid_offset)) { return new WP_Error('wsm_bad_settings_center_timezone', 'یک شناسهٔ معتبر منطقهٔ زمانی مانند Asia/Tehran وارد کنید.', array('status' => 400)); }
            $clean['timezone'] = $timezone;
        }
        if (array_key_exists('pos_discount_limit', $input)) {
            if (!is_scalar($input['pos_discount_limit']) || !is_numeric((string) $input['pos_discount_limit']) || !is_finite((float) $input['pos_discount_limit'])) { return new WP_Error('wsm_bad_settings_center_discount', 'حد تخفیف باید عددی باشد.', array('status' => 400)); }
            $discount = (float) $input['pos_discount_limit'];
            if ($discount < 0 || $discount > 100) { return new WP_Error('wsm_bad_settings_center_discount', 'حد تخفیف باید بین صفر تا ۱۰۰ درصد باشد.', array('status' => 400)); }
            $clean['pos_discount_limit'] = round($discount, 2);
        }
        if (array_key_exists('pos_allow_price_edit', $input)) {
            if (!is_scalar($input['pos_allow_price_edit'])) { return new WP_Error('wsm_bad_settings_center_price_edit', 'وضعیت ویرایش قیمت نامعتبر است.', array('status' => 400)); }
            $clean['pos_allow_price_edit'] = rest_sanitize_boolean($input['pos_allow_price_edit']);
        }
        $boolean_fields = array(
            'pos_auto_barcode_scan', 'pos_allow_zero_stock_sale', 'finance_blind_count_enabled', 'finance_auto_cogs',
            'members_allow_login_with_debt', 'products_hide_out_of_stock_pos', 'products_auto_sku',
            'hardware_auto_print_invoice', 'security_require_admin_password',
        );
        foreach ($boolean_fields as $field) {
            if (!array_key_exists($field, $input)) { continue; }
            if (!is_scalar($input[$field])) { return new WP_Error('wsm_bad_settings_center_boolean', 'یکی از گزینه‌های روشن/خاموش نامعتبر است.', array('status' => 400)); }
            $clean[$field] = rest_sanitize_boolean($input[$field]);
        }
        $numeric_fields = array(
            'finance_tax_rate' => array(0, 100, false),
            'members_max_freeze_days' => array(1, 365, true),
            'hardware_local_bridge_port' => array(1, 65535, true),
            'security_auto_logout_minutes' => array(0, 1440, true),
            'security_sync_interval_minutes' => array(1, 1440, true),
        );
        foreach ($numeric_fields as $field => $rule) {
            if (!array_key_exists($field, $input)) { continue; }
            if (!is_scalar($input[$field]) || !is_numeric((string) $input[$field]) || !is_finite((float) $input[$field])) { return new WP_Error('wsm_bad_settings_center_number', 'یکی از مقدارهای عددی تنظیمات معتبر نیست.', array('status' => 400)); }
            $number = (float) $input[$field];
            if ($number < $rule[0] || $number > $rule[1] || ($rule[2] && floor($number) !== $number)) { return new WP_Error('wsm_bad_settings_center_number', 'یکی از مقدارهای عددی تنظیمات خارج از محدودهٔ مجاز است.', array('status' => 400)); }
            $clean[$field] = $rule[2] ? (int) $number : round($number, 2);
        }
        $text_fields = array('members_code_prefix' => 24, 'hardware_barcode_prefix' => 32, 'hardware_barcode_suffix' => 32);
        foreach ($text_fields as $field => $maximum) {
            if (!array_key_exists($field, $input)) { continue; }
            if (!is_scalar($input[$field])) { return new WP_Error('wsm_bad_settings_center_text', 'یکی از متن‌های تنظیمات معتبر نیست.', array('status' => 400)); }
            $value = sanitize_text_field((string) $input[$field]);
            if (function_exists('mb_strlen') && mb_strlen($value) > $maximum) { $value = mb_substr($value, 0, $maximum); }
            elseif (strlen($value) > $maximum) { $value = substr($value, 0, $maximum); }
            $clean[$field] = $value;
        }
        $enum_fields = array(
            'pos_default_payment_mode' => array('cash', 'credit'),
            'members_expiry_behavior' => array('warning', 'inactive'),
            'hardware_printer_type' => array('auto', 'thermal', 'label', 'a4', 'none'),
        );
        foreach ($enum_fields as $field => $allowed) {
            if (!array_key_exists($field, $input)) { continue; }
            if (!is_scalar($input[$field]) || !in_array(sanitize_key((string) $input[$field]), $allowed, true)) { return new WP_Error('wsm_bad_settings_center_choice', 'یکی از انتخاب‌های تنظیمات معتبر نیست.', array('status' => 400)); }
            $clean[$field] = sanitize_key((string) $input[$field]);
        }
        $stored = isset($settings['settings_center']) && is_array($settings['settings_center']) ? $settings['settings_center'] : array();
        // Remove the assistant-added draft field superseded by the requested cash/credit default.
        unset($stored['pos_default_customer_id']);
        $settings['settings_center'] = $clean;
        return $settings;
    }

    public static function settings_update($request) {
        $body = self::body($request);
        $device = WSM_Permissions::current_device();
        $wp_admin = $device && WSM_Permissions::is_wordpress_admin_user((int) $device->user_id);
        $allowed = array('expiry_alert_days','expiry_alert_email','expiry_alert_sms','expiry_alert_email_to','expiry_meta_key','ui_config','postal_sender','settings_center','low_stock_threshold','totp_required');
        if (!$body || array_diff(array_keys($body), $allowed)) { return new WP_Error('wsm_settings_unknown_field', 'درخواست تنظیمات خالی یا دارای فیلد ناشناخته است.', array('status' => 400)); }
        $security_center_change = isset($body['settings_center']) && is_array($body['settings_center']) && array_filter(array_keys($body['settings_center']), static function($key) { return strpos((string) $key, 'security_') === 0; });
        $security_change = array_key_exists('totp_required', $body);
        if (($security_change || $security_center_change) && (!$wp_admin || !WSM_Devices::device_can($device, 'users.super_admin.assign'))) { return new WP_Error('wsm_settings_security_forbidden', 'تنظیمات امنیتی فقط برای مدیر کل قابل تغییر است.', array('status' => 403)); }
        foreach (array('totp_required','expiry_alert_email','expiry_alert_sms') as $key) {
            if (array_key_exists($key, $body)) { $value = WSM_Util::settings_bool($body[$key]); if (is_wp_error($value)) { return $value; } $body[$key] = $value; }
        }
        foreach (array('expiry_alert_days'=>array(1,365),'low_stock_threshold'=>array(0,1000000)) as $key => $range) {
            if (array_key_exists($key, $body)) { $value = WSM_Util::settings_number($body[$key], $range[0], $range[1], true); if (is_wp_error($value)) { return $value; } $body[$key] = $value; }
        }
        if ($security_change && !is_scalar($body['totp_required'])) {
            return new WP_Error('wsm_bad_totp_setting', 'مقدار الزام TOTP نامعتبر است.', array('status' => 400));
        }
        $settings_keys = array('expiry_alert_days', 'expiry_alert_email', 'expiry_alert_sms', 'expiry_alert_email_to', 'expiry_meta_key', 'ui_config', 'postal_sender', 'settings_center', 'low_stock_threshold');
        $settings_change = false;
        foreach ($settings_keys as $key) {
            if (array_key_exists($key, $body)) {
                $settings_change = true;
                break;
            }
        }
        if ($settings_change && !$wp_admin && !WSM_Devices::device_can($device, 'settings.edit')) {
            return new WP_Error('wsm_device_permission_denied', 'این دستگاه مجوز ویرایش تنظیمات عمومی را ندارد.', array('status' => 403));
        }
        if ($security_change && !$wp_admin && !WSM_Devices::device_can($device, 'security.manage')) {
            return new WP_Error('wsm_device_permission_denied', 'این دستگاه مجوز مدیریت امنیت را ندارد.', array('status' => 403));
        }
        $security_enabled = $security_change ? rest_sanitize_boolean($body['totp_required']) : false;
        $low_stock_threshold = null;
        if (array_key_exists('low_stock_threshold', $body)) {
            if (!is_scalar($body['low_stock_threshold']) || !is_numeric((string) $body['low_stock_threshold']) || !is_finite((float) $body['low_stock_threshold'])) {
                return new WP_Error('wsm_bad_low_stock_threshold', 'آستانهٔ موجودی کم باید یک عدد صحیح باشد.', array('status' => 400));
            }
            $threshold = (float) $body['low_stock_threshold'];
            if ($threshold < 0 || $threshold > 1000000 || floor($threshold) !== $threshold) {
                return new WP_Error('wsm_bad_low_stock_threshold', 'آستانهٔ موجودی کم باید عددی صحیح بین صفر تا یک میلیون باشد.', array('status' => 400));
            }
            $low_stock_threshold = (int) $threshold;
        }
        if ($security_enabled && !WSM_Crypto::available()) {
            return new WP_Error('wsm_totp_crypto_unavailable', 'برای فعال‌کردن TOTP، افزونهٔ OpenSSL در PHP باید در دسترس باشد.', array('status' => 500));
        }
        $settings = WSM_Util::settings();
        if ($security_change) {
            $settings['totp_required'] = $security_enabled ? 1 : 0;
        }
        if (array_key_exists('expiry_alert_days', $body)) {
            if (!is_scalar($body['expiry_alert_days']) || !is_numeric((string) $body['expiry_alert_days']) || !is_finite((float) $body['expiry_alert_days'])) {
                return new WP_Error('wsm_bad_expiry_days', 'تعداد روز هشدار انقضا باید عددی باشد.', array('status' => 400));
            }
            $settings['expiry_alert_days'] = max(1, min(365, (int) $body['expiry_alert_days']));
        }
        if (array_key_exists('expiry_alert_email', $body)) {
            if (!is_scalar($body['expiry_alert_email'])) {
                return new WP_Error('wsm_bad_expiry_email_flag', 'تنظیم هشدار ایمیل نامعتبر است.', array('status' => 400));
            }
            $settings['expiry_alert_email'] = rest_sanitize_boolean($body['expiry_alert_email']) ? 1 : 0;
        }
        if (array_key_exists('expiry_alert_sms', $body)) {
            if (!is_scalar($body['expiry_alert_sms'])) {
                return new WP_Error('wsm_bad_expiry_sms_flag', 'تنظیم هشدار پیامک نامعتبر است.', array('status' => 400));
            }
            $settings['expiry_alert_sms'] = rest_sanitize_boolean($body['expiry_alert_sms']) ? 1 : 0;
        }
        if (array_key_exists('expiry_alert_email_to', $body)) {
            if (!is_scalar($body['expiry_alert_email_to'])) {
                return new WP_Error('wsm_bad_expiry_email', 'نشانی ایمیل هشدار معتبر نیست.', array('status' => 400));
            }
            $email = sanitize_email((string) $body['expiry_alert_email_to']);
            if ($email !== '' && !is_email($email)) {
                return new WP_Error('wsm_bad_expiry_email', 'نشانی ایمیل هشدار معتبر نیست.', array('status' => 400));
            }
            $settings['expiry_alert_email_to'] = $email !== '' ? $email : get_option('admin_email');
        }
        if (array_key_exists('expiry_meta_key', $body)) {
            if (!is_scalar($body['expiry_meta_key'])) {
                return new WP_Error('wsm_bad_expiry_meta_key', 'کلید متای سفارشی نامعتبر است.', array('status' => 400));
            }
            $key = trim(sanitize_text_field((string) $body['expiry_meta_key']));
            if ($key !== '' && !preg_match('/^[A-Za-z0-9_:\-.]{1,120}$/', $key)) {
                return new WP_Error('wsm_bad_expiry_meta_key', 'کلید متای سفارشی نامعتبر است.', array('status' => 400));
            }
            $settings['expiry_meta_key'] = $key;
            WSM_Expiry::invalidate_detection();
        }
        if (array_key_exists('ui_config', $body)) {
            if (!is_array($body['ui_config'])) {
                return new WP_Error('wsm_bad_ui_config', 'تنظیمات رابط کاربری نامعتبر است.', array('status' => 400));
            }
            $settings['ui_config'] = WSM_Util::clean_ui_config($body['ui_config']);
        }
        if (array_key_exists('settings_center', $body)) {
            $center_settings = self::sanitize_settings_center($body['settings_center'], $settings);
            if (is_wp_error($center_settings)) { return $center_settings; }
            $settings = $center_settings;
        }
        if (array_key_exists('postal_sender', $body) && !is_array($body['postal_sender'])) {
            return new WP_Error('wsm_bad_sender', 'مشخصات فرستنده نامعتبر است.', array('status' => 400));
        }
        if (isset($body['postal_sender']) && is_array($body['postal_sender'])) {
            foreach (array('name', 'company', 'phone', 'email', 'address_1', 'address_2', 'city', 'state', 'postcode', 'country') as $sender_field) {
                if (!array_key_exists($sender_field, $body['postal_sender'])) {
                    continue;
                }
                $setting_key = 'postal_sender_' . $sender_field;
                if (!is_scalar($body['postal_sender'][$sender_field]) && $body['postal_sender'][$sender_field] !== null) {
                    return new WP_Error('wsm_bad_sender', 'یکی از مشخصات فرستنده نامعتبر است.', array('status' => 400));
                }
                $sender_value = is_scalar($body['postal_sender'][$sender_field]) ? (string) $body['postal_sender'][$sender_field] : '';
                if ($sender_field === 'email') {
                    $sender_email = sanitize_email($sender_value);
                    if ($sender_email !== '' && !is_email($sender_email)) {
                        return new WP_Error('wsm_bad_sender_email', 'ایمیل فرستنده معتبر نیست.', array('status' => 400));
                    }
                    $settings[$setting_key] = $sender_email;
                } elseif (in_array($sender_field, array('address_1', 'address_2'), true)) {
                    $settings[$setting_key] = sanitize_textarea_field($sender_value);
                } else {
                    $settings[$setting_key] = sanitize_text_field($sender_value);
                }
            }
        }
        $center_patch = isset($body['settings_center']) && is_array($body['settings_center']) ? $body['settings_center'] : array();
        if (array_key_exists('store_name', $center_patch)) { $settings['store_name'] = $settings['settings_center']['store_name']; }
        $updated = update_option('wsm_settings', $settings, false);
        if (!$updated && get_option('wsm_settings', array()) !== $settings) {
            return new WP_Error('wsm_settings_save_failed', 'ذخیرهٔ تنظیمات در پایگاه داده انجام نشد.', array('status' => 500));
        }
        if ($low_stock_threshold !== null) {
            update_option('woocommerce_notify_low_stock_amount', $low_stock_threshold);
            if ((int) get_option('woocommerce_notify_low_stock_amount', 2) !== $low_stock_threshold) {
                return new WP_Error('wsm_low_stock_threshold_save_failed', 'ذخیرهٔ آستانهٔ موجودی کم در تنظیمات WooCommerce انجام نشد.', array('status' => 500));
            }
        }
        if (array_key_exists('currency', $center_patch)) { update_option('woocommerce_currency', $settings['settings_center']['currency'] === 'rial' ? 'IRR' : 'IRT'); }
        if (array_key_exists('store_name', $center_patch)) { update_option('blogname', $settings['store_name']); }
        if (array_key_exists('timezone', $center_patch)) { update_option('timezone_string', $settings['settings_center']['timezone']); }
        if ($center_patch && class_exists('WSM_Reports')) { WSM_Reports::flush_sale_caches(); }
        if ($security_change) {
            WSM_Security::log('totp_policy_changed', 'warning', (int) $device->id, 'الزام TOTP پنل افزونه از اپ تغییر کرد.');
        }
        WSM_Activity_Log::log('update', 'settings', 0, 'تنظیمات اپ و برچسب پستی', '', 'ذخیره شد', 'success');
        return self::settings();
    }

    /* ---------------- داشبورد و گزارش ---------------- */

    public static function security_get() {
        $device = WSM_Permissions::current_device();
        if (!WSM_Devices::device_can($device, 'users.super_admin.assign')) { return new WP_Error('wsm_security_forbidden', 'فقط مدیر کل می‌تواند تنظیمات امنیت را مشاهده کند.', array('status' => 403)); }
        global $wpdb;
        $settings = WSM_Util::settings();
        $policy = get_option('wsm_security_policy', array());
        if (!is_array($policy)) { $policy = array(); }
        $policy = array_merge(array('max_attempts' => 5, 'window_minutes' => 15, 'lock_minutes' => 30), $policy);
        $rows = $wpdb->get_results('SELECT event,severity,device_id,ip_address,user_agent,details,created_at FROM ' . WSM_Security::table('security_log') . ' ORDER BY id DESC LIMIT 50', ARRAY_A);
        foreach ((array) $rows as &$row) { $row['created_at_fa'] = wsm_fa_date($row['created_at']); }
        unset($row);
        return array(
            'token_ttl_days' => max(1, min(365, (int) $settings['token_ttl_days'])),
            'key_ttl_days' => max(1, min(365, (int) $settings['key_ttl_days'])),
            'totp_required' => !empty($settings['totp_required']),
            'max_attempts' => max(1, min(20, (int) $policy['max_attempts'])),
            'window_minutes' => max(1, min(1440, (int) $policy['window_minutes'])),
            'lock_minutes' => max(1, min(1440, (int) $policy['lock_minutes'])),
            'auto_approve_devices' => (bool) get_option('wsm_auto_approve_devices', 1),
            'events' => (array) $rows,
        );
    }

    public static function security_update($request) {
        $device = WSM_Permissions::current_device();
        if (!$device || !WSM_Permissions::is_wordpress_admin_user((int) $device->user_id) || !WSM_Devices::device_can($device, 'users.super_admin.assign')) { return new WP_Error('wsm_security_forbidden', 'فقط مدیر کل می‌تواند سیاست امنیت را تغییر دهد.', array('status' => 403)); }
        $body = self::body($request);
        $ranges = array('token_ttl_days'=>array(1,365),'key_ttl_days'=>array(1,365),'max_attempts'=>array(1,20),'window_minutes'=>array(1,1440),'lock_minutes'=>array(1,1440));
        if (!$body || array_diff(array_keys($body), array_merge(array_keys($ranges), array('totp_required','auto_approve_devices','settings_center')))) { return new WP_Error('wsm_security_value_invalid', 'فیلد سیاست امنیت نامعتبر است.', array('status' => 400)); }
        foreach ($body as $key => $value) {
            if ($key === 'settings_center') { continue; }
            $clean = isset($ranges[$key]) ? WSM_Util::settings_number($value, $ranges[$key][0], $ranges[$key][1], true) : WSM_Util::settings_bool($value);
            if (is_wp_error($clean)) { return $clean; }
            $body[$key] = $clean;
        }
        if (!empty($body['totp_required']) && !WSM_Crypto::available()) { return new WP_Error('wsm_totp_crypto_unavailable', 'OpenSSL برای TOTP لازم است.', array('status' => 500)); }
        $settings = WSM_Util::settings();
        if (array_key_exists('settings_center', $body)) {
            if (!is_array($body['settings_center']) || array_diff(array_keys($body['settings_center']), array('security_auto_logout_minutes','security_sync_interval_minutes','security_require_admin_password'))) { return new WP_Error('wsm_security_value_invalid', 'فیلد سیاست امنیت معتبر نیست.', array('status'=>400)); }
            $settings = self::sanitize_settings_center($body['settings_center'], $settings);
            if (is_wp_error($settings)) { return $settings; }
        }
        $policy = wp_parse_args((array) get_option('wsm_security_policy', array()), array('max_attempts'=>5,'window_minutes'=>15,'lock_minutes'=>30));
        foreach (array('token_ttl_days','key_ttl_days','totp_required') as $key) { if (array_key_exists($key, $body)) { $settings[$key] = $body[$key]; } }
        foreach (array('max_attempts','window_minutes','lock_minutes') as $key) { if (array_key_exists($key, $body)) { $policy[$key] = $body[$key]; } }
        update_option('wsm_settings', $settings, false);
        update_option('wsm_security_policy', $policy, false);
        if (array_key_exists('auto_approve_devices', $body)) { update_option('wsm_auto_approve_devices', $body['auto_approve_devices'] ? 1 : 0, false); }
        WSM_Security::log('security_policy_changed', 'warning', (int) $device->id, 'سیاست امنیت اپ از طریق تنظیمات مدیرکل تغییر کرد.');
        return self::security_get();
    }

    public static function dashboard() {
        $cache_key = 'wsm_api_dashboard_v6_' . md5(WSM_Reports::sales_cache_epoch());
        $data = self::cached_stats($cache_key, array('WSM_Reports', 'dashboard'), 60);
        if (!is_array($data)) {
            return $data;
        }
        $can_store_sales = WSM_Permissions::has_current_permission('reports.sales') || WSM_Permissions::has_current_permission('reports.finance');
        $can_today_sales = $can_store_sales || WSM_Permissions::has_current_permission('dashboard.sales.today');
        if (!$can_today_sales && isset($data['today']) && is_array($data['today'])) {
            $data['today']['total'] = null;
            $data['today']['display'] = 'محدود';
            $data['today']['finance_restricted'] = true;
        }
        if (!$can_store_sales) {
            if (isset($data['month']) && is_array($data['month'])) {
                $data['month']['total'] = null;
                $data['month']['display'] = 'محدود';
                $data['month']['finance_restricted'] = true;
            }
            if (isset($data['last30']) && is_array($data['last30'])) {
                $data['last30']['total'] = null;
                $data['last30']['display'] = 'محدود';
                $data['last30']['finance_restricted'] = true;
            }
            $data['series'] = array();
            $data['finance_restricted'] = true;
        }
        return $data;
    }

    public static function report_sales($request) {
        return WSM_Reports::sales(
            self::scalar_param($request, 'from'),
            self::scalar_param($request, 'to'),
            array(
                'include_finance' => WSM_Permissions::has_current_permission('reports.finance'),
                'can_export'      => WSM_Permissions::has_current_permission('reports.export'),
            )
        );
    }

    public static function report_stock($request = null) {
        $params = array(
            'include_finance' => WSM_Permissions::has_current_permission('reports.finance'),
            'can_export'      => WSM_Permissions::has_current_permission('reports.export'),
        );
        if ($request instanceof WP_REST_Request) {
            foreach (array('status', 'search', 'page', 'per_page', 'all') as $key) {
                $val = self::scalar_param($request, $key);
                if ($val !== null && $val !== '') {
                    $params[$key] = $val;
                }
            }
        }
        return WSM_Reports::stock($params);
    }

    /* ---------------- محصولات ---------------- */

    public static function products_list($request) {
        $params = $request->get_params();
        $rate_limit = self::check_rest_read_rate_limit('products', WSM_Permissions::current_device_id());
        if (is_wp_error($rate_limit)) { return $rate_limit; }
        // POS uses a dedicated 50-row lightweight WooCommerce query and 15-minute transient.
        if (isset($params['pos']) && rest_sanitize_boolean($params['pos'])) {
            return WSM_Products::pos_list($params);
        }
        // Avoid creating a transient for every arbitrary search string or unbounded page.
        $search = isset($params['search']) ? trim((string) $params['search']) : '';
        $page = isset($params['page']) ? absint($params['page']) : 1;
        $per_page = isset($params['per_page']) ? absint($params['per_page']) : 20;
        $stock_status = isset($params['stock_status']) && is_scalar($params['stock_status'])
            ? (string) $params['stock_status']
            : '';
        // Inventory can be changed by WooCommerce imports and external CRUD paths. Do not serve
        // a stale availability snapshot for these filters; query WooCommerce on every request.
        if ($search !== '' || in_array($stock_status, array('instock', 'outofstock', 'onbackorder'), true) || $page > 10 || $per_page > 50) {
            return WSM_Products::list($params);
        }
        return self::cached_rest_get('products', '/products', $params, function () use ($params) {
            return WSM_Products::list($params);
        }, true);
    }

    public static function products_create($request) {
        return WSM_Products::create(self::body($request));
    }

    public static function products_barcode($request) {
        return WSM_Products::generate_barcode(self::body($request));
    }

    public static function products_expiring($request) {
        $per_page = (int) $request->get_param('per_page');
        $page = (int) $request->get_param('page');
        $per_page = $per_page > 0 ? min(50, $per_page) : 5;
        $page = $page > 0 ? min(10, $page) : 1;
        $params = array('per_page' => $per_page, 'page' => $page);
        return self::cached_rest_get('products', '/products/expiring', $params, function () use ($per_page, $page) {
            return WSM_Expiry::list($per_page, $page);
        });
    }

    public static function categories_list() {
        return self::cached_rest_get('products', '/categories', array(), function () {
            return self::categories_list_uncached();
        });
    }

    private static function categories_list_uncached() {
        if (!taxonomy_exists('product_cat')) {
            return array('items' => array());
        }
        $terms = get_terms(array(
            'taxonomy'   => 'product_cat',
            'hide_empty' => false,
            'orderby'    => 'term_order',
            'order'      => 'ASC',
        ));
        if (is_wp_error($terms) || !$terms) {
            return array('items' => array());
        }
        $parents = array();
        foreach ($terms as $term) {
            $parents[(int) $term->term_id] = (int) $term->parent;
        }
        $items = array();
        foreach ($terms as $term) {
            $level = 0;
            $parent = (int) $term->parent;
            while ($parent && isset($parents[$parent]) && $level < 8) {
                $level++;
                $parent = $parents[$parent];
            }
            $items[] = array(
                'id'     => (int) $term->term_id,
                'name'   => (string) $term->name,
                'slug'   => (string) $term->slug,
                'parent' => (int) $term->parent,
                'level'  => $level,
                'count'  => (int) $term->count,
            );
        }
        return array('items' => $items);
    }

    public static function products_get($request) {
        $id = self::id($request);
        return self::cached_rest_get('products', '/products/' . $id, array('id' => $id), function () use ($id) {
            return WSM_Products::get($id);
        });
    }

    public static function products_update($request) {
        return WSM_Products::update(self::id($request), self::body($request));
    }

    public static function products_delete($request) {
        return WSM_Products::delete(self::id($request));
    }

    public static function products_copy($request) {
        return WSM_Products::copy(self::id($request));
    }

    public static function products_image($request) {
        return WSM_Products::upload_image(self::id($request), $request->get_file_params());
    }

    /* ---------------- سفارش‌ها ---------------- */

    public static function orders_list($request) {
        return WSM_Orders::list($request->get_params());
    }

    /** Non-sensitive status labels required by order viewers, without granting settings.view. */
    public static function orders_statuses($request) {
        return WSM_Orders::statuses();
    }

    /** Change several order statuses through the same WooCommerce lifecycle hooks as a single update. */
    public static function orders_bulk_status($request) {
        $body = self::body($request);
        $raw_ids = isset($body['order_ids']) ? $body['order_ids'] : (isset($body['ids']) ? $body['ids'] : null);
        if (!is_array($raw_ids) || !$raw_ids || count($raw_ids) > 100) {
            return new WP_Error('wsm_bulk_order_ids_invalid', 'فهرست سفارش‌ها باید شامل ۱ تا ۱۰۰ شناسه باشد.', array('status' => 400));
        }
        $ids = array();
        foreach ($raw_ids as $raw_id) {
            if (!is_scalar($raw_id) || absint($raw_id) < 1) {
                return new WP_Error('wsm_bulk_order_ids_invalid', 'یکی از شناسه‌های سفارش معتبر نیست.', array('status' => 400));
            }
            $id = absint($raw_id);
            if (!in_array($id, $ids, true)) { $ids[] = $id; }
        }
        if (!$ids) { return new WP_Error('wsm_bulk_order_ids_invalid', 'فهرست سفارش‌ها خالی است.', array('status' => 400)); }
        if (!isset($body['status']) || !is_scalar($body['status'])) {
            return new WP_Error('wsm_bad_status', 'وضعیت جدید سفارش را مشخص کنید.', array('status' => 400));
        }
        $status = sanitize_key((string) $body['status']);
        if (strpos($status, 'wc-') === 0) { $status = substr($status, 3); }
        if (!in_array($status, array_column(WSM_Orders::statuses(), 'key'), true)) {
            return new WP_Error('wsm_bad_status', 'وضعیت نامعتبر است.', array('status' => 400));
        }
        if ($status === 'refunded') {
            return new WP_Error('wsm_refund_status_requires_workflow', 'وضعیت «بازپرداخت‌شده» فقط پس از ثبت بازپرداخت دارای تأیید مدیر مجاز است؛ از عملیات بازپرداخت استفاده کنید.', array('status' => 409));
        }
        $device = WSM_Permissions::current_device();
        foreach ($ids as $id) {
            $order = wc_get_order($id);
            if (!$order || $order->get_meta('_wsm_invoice')) {
                return new WP_Error('wsm_bulk_order_missing', 'یکی از سفارش‌ها پیدا نشد؛ هیچ سفارشی تغییر نکرد.', array('status' => 404, 'order_id' => $id));
            }
            if ($order->get_meta('_wsm_credit_sale') && $order->get_status() !== $status && !WSM_Devices::device_can($device, 'customers.account.manage')) {
                return new WP_Error('wsm_device_permission_denied', 'تغییر وضعیت فروش اعتباری به مجوز customers.account.manage نیاز دارد؛ هیچ سفارشی تغییر نکرد.', array('status' => 403, 'order_id' => $id));
            }
        }
        $note = isset($body['note']) && is_scalar($body['note']) ? sanitize_text_field((string) $body['note']) : '';
        $items = array();
        $failed = 0;
        foreach ($ids as $id) {
            $result = WSM_Orders::set_status($id, $status, $note);
            if (is_wp_error($result)) {
                $failed++;
                $error_data = $result->get_error_data();
                $items[] = array('order_id' => $id, 'success' => false, 'code' => $result->get_error_code(), 'message' => $result->get_error_message(), 'status' => is_array($error_data) && isset($error_data['status']) ? (int) $error_data['status'] : 400);
            } else {
                $items[] = array('order_id' => $id, 'success' => true, 'unchanged' => !empty($result['unchanged']), 'order' => $result);
            }
        }
        return array('success' => $failed === 0, 'requested' => count($ids), 'updated' => count($ids) - $failed, 'failed' => $failed, 'items' => $items);
    }

    /** Return a self-contained, escaped HTML print sheet for one order. */
    public static function orders_print($request) {
        $order = wc_get_order(self::id($request));
        if (!$order || $order->get_meta('_wsm_invoice')) {
            return new WP_Error('wsm_not_found', 'سفارش پیدا نشد.', array('status' => 404));
        }
        $data = WSM_Orders::format($order);
        $escape = static function ($value) { return esc_html((string) $value); };
        $rows = '';
        foreach ((array) $data['items'] as $item) {
            $rows .= '<tr><td>' . $escape($item['name'] ?? '') . '</td><td>' . $escape($item['qty'] ?? '') . '</td><td>' . $escape($item['total'] ?? '') . '</td></tr>';
        }
        $html = '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>سفارش #' . $escape($data['number']) . '</title><style>body{font-family:Tahoma,Arial,sans-serif;color:#111;margin:24px;direction:rtl}h1{font-size:22px}table{width:100%;border-collapse:collapse;margin-top:18px}th,td{padding:9px;border:1px solid #bbb;text-align:right}th{background:#eee}.meta{display:grid;grid-template-columns:1fr 1fr;gap:8px}.total{font-weight:bold;margin-top:16px}@media print{body{margin:8mm}.no-print{display:none}}</style></head><body><h1>سفارش #' . $escape($data['number']) . '</h1><div class="meta"><div>مشتری: ' . $escape($data['customer_name']) . '</div><div>تاریخ: ' . $escape($data['date']) . '</div><div>وضعیت: ' . $escape($data['status_label']) . '</div><div>پرداخت: ' . $escape($data['payment_method_title']) . '</div><div>موبایل: ' . $escape($data['billing']['phone'] ?? '') . '</div><div>ایمیل: ' . $escape($data['billing']['email'] ?? '') . '</div></div><table><thead><tr><th>شرح کالا</th><th>تعداد</th><th>جمع</th></tr></thead><tbody>' . $rows . '</tbody></table><p class="total">مبلغ نهایی: ' . $escape($data['total_display']) . '</p><p class="no-print">گزارش چاپی محلی؛ هیچ درخواست پرداختی ارسال نمی‌شود.</p></body></html>';
        return array('html' => $html, 'filename' => 'wsm-order-' . absint($data['id']) . '.html', 'order_id' => absint($data['id']));
    }

    public static function orders_manual($request) {
        return WSM_Orders::create_manual(self::body($request));
    }

    public static function orders_get($request) {
        return WSM_Orders::get(self::id($request));
    }

    public static function orders_update($request) {
        $id = self::id($request);
        $body = self::body($request);
        $device = WSM_Permissions::current_device();
        if (array_key_exists('status', $body)) {
            if (!is_scalar($body['status'])) {
                return new WP_Error('wsm_bad_status', 'وضعیت سفارش نامعتبر است.', array('status' => 400));
            }
            $order = wc_get_order($id);
            if ($order) {
                $next = sanitize_key((string) $body['status']);
                if (strpos($next, 'wc-') === 0) {
                    $next = substr($next, 3);
                }
                $changed = $next !== $order->get_status();
                if ($changed && !WSM_Devices::device_can($device, 'orders.change_status')) {
                    return new WP_Error('wsm_device_permission_denied', 'این دستگاه مجوز تغییر وضعیت سفارش را ندارد.', array('status' => 403));
                }
                if ($changed && !absint($order->get_meta('_wsm_linked_invoice_id')) && !WSM_Devices::device_can($device, 'invoices.create')) {
                    return new WP_Error('wsm_device_permission_denied', 'تغییر این وضعیت به‌طور خودکار فاکتور می‌سازد؛ مجوز ایجاد فاکتور لازم است.', array('status' => 403));
                }
            }
        }
        return WSM_Orders::update($id, $body);
    }

    public static function orders_delete($request) {
        return WSM_Orders::delete(self::id($request));
    }

    public static function orders_invoice($request) {
        return WSM_Invoices::create_from_order(self::id($request));
    }

    public static function orders_status($request) {
        $b = self::body($request);
        $id = self::id($request);
        $order = wc_get_order($id);
        if (array_key_exists('status', $b) && !is_scalar($b['status'])) {
            return new WP_Error('wsm_bad_status', 'وضعیت سفارش نامعتبر است.', array('status' => 400));
        }
        return WSM_Orders::set_status($id, isset($b['status']) ? $b['status'] : '', isset($b['note']) ? $b['note'] : '');
    }

    public static function orders_refund_accounts($request) {
        return WSM_Club_Operations::refund_accounts(self::id($request));
    }

    public static function orders_refund($request) {
        return WSM_Club_Operations::refund_order(self::id($request), self::body($request));
    }

    public static function orders_history($request) {
        return WSM_Orders::history(self::id($request));
    }

    /* ---------------- فاکتورها ---------------- */

    public static function invoices_statuses() {
        $s = WSM_Util::settings();
        return array(
            'statuses' => WSM_Invoices::statuses(),
            'store'    => array(
                'store_name'     => !empty($s['store_name']) ? (string) $s['store_name'] : get_bloginfo('name'),
                'store_logo'     => isset($s['store_logo']) ? (string) $s['store_logo'] : '',
                'store_phone'    => isset($s['postal_sender_phone']) ? (string) $s['postal_sender_phone'] : '',
                'store_address'  => implode('، ', array_filter(array(
                    isset($s['postal_sender_state']) ? trim((string) $s['postal_sender_state']) : '',
                    isset($s['postal_sender_city']) ? trim((string) $s['postal_sender_city']) : '',
                    isset($s['postal_sender_address_1']) ? trim((string) $s['postal_sender_address_1']) : '',
                ))),
                'store_postal'   => isset($s['postal_sender_postcode']) ? (string) $s['postal_sender_postcode'] : '',
                'currency_symbol'=> function_exists('wsm_currency_symbol') ? wsm_currency_symbol() : 'تومان',
            ),
        );
    }

    public static function invoices_list($request) {
        return WSM_Invoices::list($request->get_params());
    }

    public static function invoices_create($request) {
        $res = WSM_Invoices::create(self::body($request));
        return is_wp_error($res) ? $res : new WP_REST_Response($res, 201);
    }

    public static function invoices_get($request) {
        return WSM_Invoices::get(self::id($request));
    }

    public static function invoices_update($request) {
        $id = self::id($request);
        $body = self::body($request);
        if (array_key_exists('status', $body)) {
            if (!is_scalar($body['status'])) {
                return new WP_Error('wsm_bad_status', 'وضعیت فاکتور نامعتبر است.', array('status' => 400));
            }
            $invoice = wc_get_order($id);
            if ($invoice && $invoice->get_meta('_wsm_invoice')) {
                $formatted = WSM_Invoices::format($invoice);
                $current = isset($formatted['status']) ? WSM_Invoices::normalize_status_key($formatted['status']) : '';
                $next = WSM_Invoices::normalize_status_key($body['status']);
                if ($next !== $current && !WSM_Devices::device_can(WSM_Permissions::current_device(), 'invoices.change_status')) {
                    return new WP_Error('wsm_device_permission_denied', 'این دستگاه مجوز تغییر وضعیت فاکتور را ندارد.', array('status' => 403));
                }
            }
        }
        return WSM_Invoices::update($id, $body);
    }

    public static function invoices_delete($request) {
        return WSM_Invoices::delete(self::id($request));
    }

    public static function invoices_status($request) {
        $b = self::body($request);
        if (isset($b['status']) && !is_scalar($b['status'])) {
            return new WP_Error('wsm_bad_status', 'وضعیت فاکتور نامعتبر است.', array('status' => 400));
        }
        return WSM_Invoices::set_status(self::id($request), isset($b['status']) ? (string) $b['status'] : '', $b);
    }

    public static function invoices_copy($request) {
        $res = WSM_Invoices::duplicate(self::id($request));
        return is_wp_error($res) ? $res : new WP_REST_Response($res, 201);
    }

    public static function invoices_html($request) {
        $html = WSM_Invoices::render_html(self::id($request));
        if (is_wp_error($html)) {
            return $html;
        }
        return array('html' => $html);
    }

    public static function invoices_batch_html($request) {
        $b = self::body($request);
        $ids = array();
        if (isset($b['ids']) && is_array($b['ids'])) {
            $ids = $b['ids'];
        } elseif ($request->get_param('ids') !== null) {
            $raw = $request->get_param('ids');
            $ids = is_array($raw) ? $raw : explode(',', (string) $raw);
        }
        $html = WSM_Invoices::render_batch_html($ids);
        if (is_wp_error($html)) {
            return $html;
        }
        $clean_ids = array_values(array_unique(array_filter(array_map('absint', (array) $ids))));
        return array('html' => $html, 'count' => count($clean_ids), 'ids' => $clean_ids);
    }

    public static function invoices_label($request) {
        $html = WSM_Invoices::render_label(self::id($request));
        if (is_wp_error($html)) {
            return $html;
        }
        return array('html' => $html);
    }

    /* ---------------- مشتریان، دستگاه‌ها، فعالیت ---------------- */

    public static function customers_list($request) {
        return WSM_Customers::list($request->get_params());
    }

    public static function customers_get($request) {
        return WSM_Customers::get(self::id($request), $request->get_params());
    }

    public static function store_customers_list($request) {
        return WSM_Customers::accounts_list($request->get_params());
    }

    public static function store_customers_create($request) {
        return WSM_Customers::account_create(self::body($request));
    }

    public static function store_customer_get($request) {
        return WSM_Customers::account_get(self::id($request));
    }

    public static function store_customer_update($request) {
        return WSM_Customers::account_update(self::id($request), self::body($request));
    }

    public static function store_customer_payment($request) {
        return WSM_Customers::collect_payment(self::id($request), self::body($request));
    }

    public static function devices_list($request) {
        $rows = WSM_Devices::query(array(
            'status' => self::scalar_param($request, 'status'),
            'search' => WSM_Util::clean_text(self::scalar_param($request, 'search'), 100),
            'limit'  => (int) $request->get_param('limit') ?: 100,
        ));
        return array('items' => array_map(array('WSM_Devices', 'format'), $rows), 'counts' => WSM_Devices::count_by_status());
    }

    public static function devices_status($request) {
        $b = self::body($request);
        $action = isset($b['action']) && is_scalar($b['action']) ? (string) $b['action'] : '';
        $reason = isset($b['reason']) && is_scalar($b['reason']) ? (string) $b['reason'] : '';
        $needed = array('approve' => 'devices.approve', 'block' => 'devices.block', 'unblock' => 'devices.block', 'unlink' => 'devices.unlink', 'delete' => 'devices.delete');
        $device = WSM_Permissions::current_device();
        if (!isset($needed[$action])) { return new WP_Error('wsm_bad_action', 'عملیات نامعتبر است.', array('status' => 400)); }
        if (!WSM_Devices::device_can($device, 'devices.manage') && !WSM_Devices::device_can($device, $needed[$action])) {
            return new WP_Error('wsm_device_permission_denied', 'برای این عملیات مجوز اختصاصی دستگاه لازم است.', array('status' => 403, 'permission' => $needed[$action]));
        }
        $result = WSM_Devices::set_status(self::id($request), $action, $reason);
        return is_wp_error($result) ? $result : WSM_Devices::format($result);
    }

    /* ---------------- باشگاه ---------------- */

    public static function club_overview() {
        return self::cached_stats('wsm_api_club_overview_v2', array('WSM_Club', 'overview'));
    }

    public static function club_members($request) {
        return WSM_Club::list_members($request->get_params());
    }

    public static function club_member_create($request) {
        return WSM_Club::save_member(self::body($request));
    }

    public static function club_member_get($request) {
        return WSM_Club::get_member(self::id($request));
    }

    public static function club_member_update($request) {
        return WSM_Club::save_member(self::body($request), self::id($request));
    }

    public static function club_member_avatar($request) {
        $member_id = self::id($request);
        $member = WSM_Club::get_member($member_id);
        if (is_wp_error($member)) { return $member; }
        if (strtoupper((string) $request->get_method()) === 'DELETE') {
            if (!WSM_Club::remove_athlete_avatar($member_id)) { return new WP_Error('wsm_avatar_remove_failed', 'حذف تصویر ورزشکار تأیید نشد.', array('status' => 500)); }
            return array('ok' => true, 'avatar_url' => '');
        }
        $files = $request->get_file_params();
        $file = is_array($files) ? ($files['avatar'] ?? null) : null;
        if (!is_array($file) || !isset($file['tmp_name'], $file['size'], $file['error']) || (int) $file['error'] !== UPLOAD_ERR_OK || (int) $file['size'] < 1 || (int) $file['size'] > 2097152 || !is_uploaded_file($file['tmp_name']) && PHP_SAPI !== 'cli') {
            return new WP_Error('wsm_avatar_upload_invalid', 'یک تصویر JPEG، PNG یا WebP تا حداکثر ۲ مگابایت انتخاب کنید.', array('status' => 400));
        }
        $mime = function_exists('finfo_file') ? finfo_file(finfo_open(FILEINFO_MIME_TYPE), $file['tmp_name']) : '';
        $allowed = array('image/jpeg', 'image/png', 'image/webp');
        if (!in_array($mime, $allowed, true)) { return new WP_Error('wsm_avatar_mime_invalid', 'فقط تصویر JPEG، PNG یا WebP مجاز است.', array('status' => 400)); }
        $bytes = file_get_contents($file['tmp_name']);
        $saved = WSM_Club::store_athlete_avatar($member_id, $bytes, $mime);
        if (is_wp_error($saved)) { return $saved; }
        return array('ok' => true, 'member_id' => $member_id, 'avatar_url' => $saved['url'], 'attachment_id' => $saved['attachment_id']);
    }

    public static function club_member_archive($request) {
        return WSM_Club::archive_member(self::id($request));
    }

    public static function club_plans($request) {
        return WSM_Club::list_plans(!empty($request->get_param('all')));
    }

    public static function club_plan_create($request) {
        return WSM_Club::save_plan(self::body($request));
    }

    public static function club_plan_update($request) {
        return WSM_Club::save_plan(self::body($request), self::id($request));
    }

    public static function club_plan_archive($request) {
        return WSM_Club::archive_plan(self::id($request));
    }

    public static function club_memberships($request) {
        return WSM_Club::list_memberships($request->get_params());
    }

    public static function club_membership_create($request) {
        return WSM_Club::create_membership(self::body($request));
    }

    public static function club_payments($request) {
        return WSM_Club::list_payments($request->get_params());
    }

    public static function club_payment_create($request) {
        return WSM_Club::record_payment(self::body($request));
    }

    public static function club_attendance($request) {
        return WSM_Club::list_attendance($request->get_params());
    }

    public static function club_attendance_create($request) {
        return WSM_Club::checkin(self::body($request));
    }

    public static function club_staff($request) {
        return WSM_Club::list_staff($request->get_params());
    }

    public static function club_staff_create($request) {
        $result = WSM_Club::save_staff(self::body($request));
        return is_wp_error($result) ? $result : WSM_Club::list_staff(array('per_page' => 100));
    }

    public static function club_staff_update($request) {
        $result = WSM_Club::save_staff(self::body($request), self::id($request));
        return is_wp_error($result) ? $result : WSM_Club::list_staff(array('per_page' => 100));
    }

    public static function club_payroll($request) {
        return WSM_Club::list_payroll($request->get_params());
    }

    public static function club_payroll_create($request) {
        return WSM_Club::create_payroll(self::body($request));
    }

    public static function club_payroll_paid($request) {
        return WSM_Club::mark_payroll_paid(self::id($request), self::body($request));
    }

    public static function club_payroll_accounts($request) {
        return WSM_Club_Operations::payroll_bank_accounts();
    }

    public static function club_membership_freeze($request) {
        return WSM_Club_Operations::freeze_membership(self::id($request), self::body($request));
    }

    public static function club_membership_cancel($request) {
        return WSM_Club_Operations::cancel_membership(self::id($request), self::body($request));
    }

    private static function club_entity_list($kind, $request) {
        return WSM_Club_Operations::list_entities($kind, $request->get_params());
    }

    private static function club_entity_save($kind, $request, $id = 0) {
        return WSM_Club_Operations::save_entity($kind, self::body($request), $id);
    }

    private static function club_entity_delete($kind, $request) {
        return WSM_Club_Operations::delete_entity($kind, self::id($request));
    }

    public static function club_collections($request) { return self::club_entity_list('collections', $request); }
    public static function club_collections_create($request) { return self::club_entity_save('collections', $request); }
    public static function club_collections_update($request) { return self::club_entity_save('collections', $request, self::id($request)); }
    public static function club_collections_delete($request) { return self::club_entity_delete('collections', $request); }
    public static function club_sports($request) { return self::club_entity_list('sports', $request); }
    public static function club_sports_create($request) { return self::club_entity_save('sports', $request); }
    public static function club_sports_update($request) { return self::club_entity_save('sports', $request, self::id($request)); }
    public static function club_sports_delete($request) { return self::club_entity_delete('sports', $request); }
    public static function club_phonebook($request) { return self::club_entity_list('phonebook', $request); }
    public static function club_phonebook_create($request) { return self::club_entity_save('phonebook', $request); }
    public static function club_phonebook_update($request) { return self::club_entity_save('phonebook', $request, self::id($request)); }
    public static function club_phonebook_delete($request) { return self::club_entity_delete('phonebook', $request); }
    public static function club_phonebook_bulk($request) { return WSM_Club_Operations::bulk_phonebook_action(self::body($request)); }
    public static function club_phonebook_import($request) { return WSM_Club_Operations::import_phonebook_contacts(self::body($request)); }
    public static function club_phonebook_sms_send($request) {
        $can_view_phonebook = WSM_Permissions::has_current_permission('club.directory.view') ||
            WSM_Permissions::has_current_permission('club.directory.manage') ||
            WSM_Permissions::has_current_permission('club.phonebook.view') ||
            WSM_Permissions::has_current_permission('club.phonebook.manage');
        if (!$can_view_phonebook) {
            return new WP_Error('wsm_phonebook_sms_forbidden', 'برای ارسال از دفتر تلفن، مجوز مشاهدهٔ مخاطبان لازم است.', array('status' => 403));
        }
        $can_send_bulk = WSM_Permissions::has_current_permission('club.sms.bulk_send') ||
            WSM_Permissions::has_current_permission('club.sms.manage');
        if (!$can_send_bulk) {
            return new WP_Error('wsm_phonebook_sms_forbidden', 'مجوز ارسال گروهی پیامک ندارید.', array('status' => 403));
        }
        return WSM_Club_Operations::send_phonebook_sms(self::body($request));
    }
    public static function club_finance($request) {
        $result = WSM_Club_Operations::list_finance($request->get_params());
        if (is_wp_error($result) || !is_array($result)) { return $result; }
        $unique_rows = static function ($rows, $key = 'id') {
            if (!is_array($rows)) { return array(); }
            $out = array();
            $seen = array();
            foreach ($rows as $row) {
                if (!is_array($row)) { continue; }
                if (!isset($row[$key]) || !is_scalar($row[$key]) || (string) $row[$key] === '') { $out[] = $row; continue; }
                $id = (string) $row[$key];
                if (isset($seen[$id])) { continue; }
                $seen[$id] = true;
                $out[] = $row;
            }
            return $out;
        };
        foreach (array('items', 'accounts', 'cash_sessions', 'daily_reconciliation') as $key) {
            if (isset($result[$key])) { $result[$key] = $unique_rows($result[$key]); }
        }
        foreach (array('receivables', 'payables') as $key) {
            if (isset($result[$key]) && is_array($result[$key]) && isset($result[$key]['items'])) {
                $result[$key]['items'] = $unique_rows($result[$key]['items']);
            }
        }
        if (isset($result['finance_controls']) && is_array($result['finance_controls'])) {
            foreach (array('devices', 'gateways') as $key) {
                if (isset($result['finance_controls'][$key])) { $result['finance_controls'][$key] = $unique_rows($result['finance_controls'][$key]); }
            }
        }
        return $result;
    }
    public static function club_finance_void($request) { return WSM_Club_Operations::void_finance(self::id($request), self::body($request)); }
    public static function club_expense_create($request) { return WSM_Club_Operations::create_expense(self::body($request), 'expense'); }
    public static function club_cash_removal($request) { return WSM_Club_Operations::create_expense(self::body($request), 'cash_removal'); }
    public static function club_card_recharge($request) { return WSM_Club_Operations::recharge_card(self::body($request)); }
    public static function club_pos_create($request) {
        $body = self::body($request);
        $device = WSM_Permissions::current_device();
        $quick_action = isset($body['quick_access_action']) && is_scalar($body['quick_access_action']) ? sanitize_key((string) $body['quick_access_action']) : '';
        if ($quick_action !== '') {
            if (!in_array($quick_action, array('get', 'save', 'authorize_discount'), true)) {
                return new WP_Error('wsm_pos_quick_access_action_invalid', 'درخواست دسترسی سریع نامعتبر است.', array('status' => 400));
            }
            if ($quick_action === 'authorize_discount' && !WSM_Devices::device_can($device, 'club.pos.create')) {
                return new WP_Error('wsm_device_permission_denied', 'برای تأیید فروش تخفیف‌دار، مجوز ایجاد فروش POS لازم است.', array('status' => 403));
            }
            if ($quick_action === 'save' && !WSM_Devices::device_can($device, 'club.pos.quick_access.manage') && !WSM_Devices::device_can($device, 'club.settings.manage')) {
                return new WP_Error('wsm_device_permission_denied', 'برای مدیریت دسترسی سریع، مجوز باشگاه لازم است.', array('status' => 403));
            }
            if ($quick_action === 'get' && !WSM_Devices::device_can($device, 'club.pos.create') && !WSM_Devices::device_can($device, 'club.pos.quick_access.manage') && !WSM_Devices::device_can($device, 'club.settings.manage')) {
                return new WP_Error('wsm_device_permission_denied', 'برای مشاهدهٔ دسترسی سریع، مجوز POS لازم است.', array('status' => 403));
            }
            return WSM_Club_Operations::create_pos_order($body);
        }
        if (!WSM_Devices::device_can($device, 'club.pos.create')) {
            return new WP_Error('wsm_device_permission_denied', 'برای ثبت فروش، مجوز club.pos.create لازم است.', array('status' => 403));
        }
        if (isset($body['create_invoice']) && rest_sanitize_boolean($body['create_invoice']) && !WSM_Devices::device_can($device, 'invoices.create')) {
            return new WP_Error('wsm_device_permission_denied', 'برای صدور فاکتور، مجوز invoices.create لازم است.', array('status' => 403));
        }
        $result = WSM_Club_Operations::create_pos_order($body);
        if (!is_wp_error($result)) {
            self::invalidate_rest_product_cache();
        }
        return $result;
    }
    public static function club_reports($request) {
        global $wpdb;

        $diagnostic_id = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : uniqid('wsm-report-', true);
        $params = array();
        $report_type = 'unknown';
        $base_buffer_level = ob_get_level();
        $captured_output = '';
        $diagnostics = array();
        $diagnostic_count = 0;
        $exception_details = '';
        $result = null;

        ob_start();
        set_error_handler(function ($severity, $message, $file, $line) use (&$diagnostics, &$diagnostic_count) {
            if (!(error_reporting() & $severity)) { return false; }
            $safe_message = str_replace(array("\r", "\n", "\t"), ' ', (string) $message);
            $diagnostic_count++;
            if (count($diagnostics) < 25) {
                $diagnostics[] = array(
                    'file' => basename((string) $file),
                    'line' => (int) $line,
                    'severity' => (int) $severity,
                    'message' => substr($safe_message, 0, 500),
                );
            }
            return true;
        }, E_ALL);

        try {
            $params = is_object($request) && method_exists($request, 'get_params') ? $request->get_params() : array();
            $params = is_array($params) ? $params : array();
            $report_type = isset($params['type']) && is_scalar($params['type']) ? sanitize_key((string) $params['type']) : 'debtors';

            $date_error = null;
            foreach (array('from', 'to') as $date_key) {
                if (!array_key_exists($date_key, $params)) { continue; }
                if (!class_exists('WSM_Reports') || !is_callable(array('WSM_Reports', 'normalize_report_date'))) {
                    $date_error = new WP_Error('wsm_club_report_date_service', 'سرویس تبدیل تاریخ گزارش در دسترس نیست.', array('status' => 503));
                    break;
                }
                $normalized_date = WSM_Reports::normalize_report_date($params[$date_key]);
                if ($normalized_date === false) {
                    $date_error = new WP_Error('wsm_club_report_date_invalid', 'تاریخ گزارش باید شمسی یا میلادی معتبر باشد.', array('status' => 400));
                    break;
                }
                if ($normalized_date === '') { unset($params[$date_key]); }
                else { $params[$date_key] = $normalized_date; }
            }

            if (is_wp_error($date_error)) {
                $result = $date_error;
            } else {
                // Isolate any SQL error generated by this report from earlier requests/hooks.
                if (isset($wpdb->last_error)) { $wpdb->last_error = ''; }
                $result = WSM_Util::apply_cogs_policy(WSM_Club_Operations::report(is_array($params) ? $params : array()));
            }

            // Keep response normalization inside the guarded/output-buffered block too.
            if (!is_wp_error($result)) {
                if (!is_array($result)) {
                    $result = new WP_Error('wsm_club_report_invalid_payload', 'ساختار پاسخ گزارش معتبر نیست.', array('status' => 500));
                } elseif (!isset($result['items']) || !is_array($result['items'])) {
                    $result = new WP_Error('wsm_club_report_invalid_items', 'فهرست ردیف‌های گزارش معتبر نیست.', array('status' => 500));
                } else {
                    $result['items'] = array_values($result['items']);
                    $result['summary'] = isset($result['summary']) && is_array($result['summary']) ? $result['summary'] : array();
                    $result['charts'] = isset($result['charts']) && is_array($result['charts']) ? $result['charts'] : array();
                    if ($report_type === 'overview') {
                        foreach (array('trend', 'finance', 'attendance', 'trainers') as $chart_key) {
                            if (!isset($result['charts'][$chart_key]) || !is_array($result['charts'][$chart_key])) { $result['charts'][$chart_key] = array(); }
                        }
                    }
                    $result['count'] = isset($result['count']) && is_numeric($result['count']) ? max(0, (int) $result['count']) : count($result['items']);
                }
            }
        } catch (\Throwable $exception) {
            $exception_message = str_replace(array("\r", "\n", "\t"), ' ', (string) $exception->getMessage());
            $exception_details = get_class($exception) . ': ' . substr($exception_message, 0, 1000)
                . ' at ' . basename((string) $exception->getFile()) . ':' . (int) $exception->getLine();
            $result = new WP_Error('wsm_club_report_exception', 'تهیهٔ گزارش با خطای داخلی مواجه شد؛ گزارش خطای سرور را بررسی کنید.', array('status' => 500));
        } finally {
            restore_error_handler();
            while (ob_get_level() > $base_buffer_level) {
                $part = ob_get_clean();
                if (is_string($part)) { $captured_output = $part . $captured_output; }
            }
        }

        $log_from = isset($params['from']) && is_scalar($params['from']) ? str_replace(array("\r", "\n", "\t"), ' ', (string) $params['from']) : '';
        $log_to = isset($params['to']) && is_scalar($params['to']) ? str_replace(array("\r", "\n", "\t"), ' ', (string) $params['to']) : '';
        $request_context = 'type=' . $report_type . ' from=' . $log_from . ' to=' . $log_to;

        foreach ($diagnostics as $diagnostic) {
            error_log('[WSM Reports][' . $diagnostic_id . '] PHP diagnostic severity=' . (int) $diagnostic['severity']
                . ' at ' . $diagnostic['file'] . ':' . (int) $diagnostic['line'] . ': ' . (string) $diagnostic['message']
                . '; ' . $request_context);
        }
        if ($diagnostic_count > count($diagnostics)) {
            error_log('[WSM Reports][' . $diagnostic_id . '] Additional PHP diagnostics omitted: '
                . (int) ($diagnostic_count - count($diagnostics)) . '; ' . $request_context);
        }
        if (trim($captured_output) !== '') {
            error_log('[WSM Reports][' . $diagnostic_id . '] Suppressed unexpected output (' . strlen($captured_output) . ' bytes); ' . $request_context);
        }
        if ($exception_details !== '') {
            error_log('[WSM Reports][' . $diagnostic_id . '] Uncaught ' . $exception_details . '; ' . $request_context);
        }

        $database_error = isset($wpdb->last_error) ? trim(str_replace(array("\r", "\n", "\t"), ' ', (string) $wpdb->last_error)) : '';
        if ($database_error !== '') {
            error_log('[WSM Reports][' . $diagnostic_id . '] SQL error: DB Error; ' . $request_context);
            $database_error = 'DB Error';
        }

        $can_view_diagnostics = function_exists('current_user_can') && current_user_can('manage_options');
        $decorate_server_error = function ($error) use ($diagnostic_id, $can_view_diagnostics, $exception_details, $database_error, $request_context) {
            if (!is_wp_error($error)) { return $error; }
            $error_code = $error->get_error_code();
            $error_data = $error->get_error_data($error_code);
            $error_data = is_array($error_data) ? $error_data : array();
            $status = isset($error_data['status']) ? (int) $error_data['status'] : 0;
            if ($status < 500) { return $error; }

            error_log('[WSM Reports][' . $diagnostic_id . '] WP_Error code=' . (string) $error_code . '; ' . $request_context);
            $error_message = $error->get_error_message($error_code);
            $error_message .= ' (شناسهٔ پیگیری: ' . $diagnostic_id . ')';
            if ($can_view_diagnostics) {
                $details = array();
                if ($exception_details !== '') { $details[] = 'PHP: ' . $exception_details; }
                if ($database_error !== '') { $details[] = 'SQL: ' . substr($database_error, 0, 1000); }
                if ($details) { $error_message .= ' [' . implode(' | ', $details) . ']'; }
            }
            $error_data['diagnostic_id'] = $diagnostic_id;
            return new WP_Error($error_code, $error_message, $error_data);
        };

        if (is_wp_error($result)) { return $decorate_server_error($result); }
        return $result;
    }
    public static function club_settings($request) { return WSM_Club_Operations::public_settings(); }
    public static function club_settings_update($request) { return WSM_Club_Operations::update_settings(self::body($request)); }
    public static function club_sms_log($request) { return WSM_Club_Operations::list_sms($request->get_params()); }
    public static function club_sms_send($request) { return WSM_Club_Operations::send_sms(self::body($request)); }
    public static function club_users($request = null) { return WSM_Club_Operations::list_users(); }
    public static function club_user_create($request) { return WSM_Club_Operations::create_user(self::body($request)); }
    public static function club_user_update($request) { return WSM_Club_Operations::update_user(self::id($request), self::body($request)); }

    public static function bridge_pair_token($request) {
        $b = self::body($request);
        return WSM_Auth::create_bridge_pairing_token(isset($b['origin']) ? (string) $b['origin'] : '');
    }

    public static function bridge_pair($request) {
        $b = self::body($request);
        return WSM_Auth::pair_bridge(
            isset($b['pairing_token']) ? (string) $b['pairing_token'] : '',
            isset($b['origin']) ? (string) $b['origin'] : '',
            array(
                'device_name' => isset($b['device_name']) ? $b['device_name'] : 'WP Store Manager Local Bridge',
                'platform' => isset($b['platform']) ? $b['platform'] : 'Desktop',
                'os_version' => isset($b['os_version']) ? $b['os_version'] : '',
                'app_version' => isset($b['app_version']) ? $b['app_version'] : '',
            )
        );
    }

    public static function bridge_time($request) {
        return array('server_time' => current_time('mysql'), 'timezone' => wp_timezone_string());
    }

    public static function bridge_access_list($request) {
        return WSM_Club::access_list($request->get_params());
    }

    public static function bridge_attendance_list($request) {
        return WSM_Club::bridge_attendance_list($request->get_params());
    }

    public static function bridge_attendance($request) {
        return WSM_Club::ingest_events(self::body($request));
    }

    /** Authenticated Bridge-only Pull adapter; serial is an identifier, not authentication. */
    public static function bridge_attendance_from_zkteco($request) {
        global $wpdb;
        $device_id = WSM_Permissions::current_device_id();
        if ($device_id <= 0) { return new WP_Error('wsm_zk_device_required', 'دستگاه پل احراز نشده است.', array('status'=>403)); }
        // WordPress add_option may use an upsert, so serialize all competing
        // Bridge writers. On unsupported DBs fail closed; never bypass the lock.
        $lock_name = 'wsm_zk_' . substr(hash('sha256', (string)$wpdb->prefix), 0, 40);
        $wpdb->last_error = '';
        $locked = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $lock_name, 2));
        if ((string)$locked !== '1' || !empty($wpdb->last_error)) {
            return new WP_Error('wsm_zk_lock_unavailable', 'قفل ثبت پایانه در دسترس نیست.', array('status'=>503));
        }
        try { return self::bridge_attendance_from_zkteco_locked($request, $device_id); }
        finally { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock_name)); }
    }

    private static function bridge_attendance_from_zkteco_locked($request, $device_id) {
        global $wpdb;
        $body = self::body($request);
        $serial = isset($body['serial_number']) && is_string($body['serial_number']) ? trim($body['serial_number']) : '';
        if (!preg_match('/\A[A-Za-z0-9._:-]{1,120}\z/D', $serial)) {
            return new WP_Error('wsm_zk_serial_invalid', 'شناسهٔ پایانه معتبر نیست.', array('status'=>400));
        }
        if (empty($body['events']) || !is_array($body['events']) || count($body['events']) > 100) {
            return new WP_Error('wsm_zk_events_invalid', 'فهرست رویدادهای پایانه معتبر نیست.', array('status'=>400));
        }
        $events = array(); $client_ids = array(); $index_map = array(); $rejected = array();
        foreach (array_values($body['events']) as $index => $event) {
            if (!is_array($event)) { return new WP_Error('wsm_zk_event_invalid', 'رویداد پایانه معتبر نیست.', array('status'=>400)); }
            $uid = isset($event['device_user_id']) && is_scalar($event['device_user_id']) ? trim((string)$event['device_user_id']) : '';
            $stamp = isset($event['timestamp']) && is_string($event['timestamp']) ? trim($event['timestamp']) : '';
            $client_id = isset($event['event_id']) && is_string($event['event_id']) ? strtolower($event['event_id']) : '';
            $direction = isset($event['direction']) && is_string($event['direction']) ? strtolower(trim($event['direction'])) : 'in';
            if (!preg_match('/\A[A-Za-z0-9_-]{1,32}\z/D', $uid) || !preg_match('/\A[a-f0-9]{64}\z/D', $client_id) ||
                !in_array($direction, array('in','out'), true) ||
                !preg_match('/\A\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})?\z/D', $stamp)) {
                return new WP_Error('wsm_zk_event_invalid', 'رویداد پایانه معتبر نیست.', array('status'=>400));
            }
            try { $instant = new DateTimeImmutable($stamp, wp_timezone()); }
            catch (Exception $e) { return new WP_Error('wsm_zk_time_invalid', 'زمان رویداد معتبر نیست.', array('status'=>400)); }
            $time_errors = DateTimeImmutable::getLastErrors();
            if ((is_array($time_errors) && (!empty($time_errors['warning_count']) || !empty($time_errors['error_count']))) || $instant->getTimestamp() > time() + DAY_IN_SECONDS) {
                return new WP_Error('wsm_zk_time_invalid', 'زمان رویداد معتبر نیست.', array('status'=>400));
            }
            $preflight = WSM_Club::zkteco_entry_preflight($uid, $direction);
            if (is_wp_error($preflight)) {
                $rejected[$index] = array('index'=>$index, 'event_id'=>$client_id, 'accepted'=>false,
                    'duplicate'=>false, 'error_code'=>$preflight->get_error_code(), 'message'=>$preflight->get_error_message());
                continue;
            }
            $utc = $instant->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s\Z');
            $site_time = $instant->setTimezone(wp_timezone())->format('Y-m-d H:i:s');
            $digest = hash('sha256', $serial . "\0" . $uid . "\0" . $utc);
            $option_key = 'wsm_zk_seen_' . hash('sha256', $digest);
            $event_id = $digest;
            // A previously ingested legacy event may keep its original ID during migration.
            // Compare its content as well; an arbitrary old ID must never authorize a new event.
            $wpdb->last_error = '';
            $legacy = $wpdb->get_row($wpdb->prepare(
                'SELECT event_id,device_user_id,direction,occurred_at FROM ' . WSM_Club::table('attendance') . ' WHERE source_device_id=%d AND event_id=%s LIMIT 1',
                $device_id, $client_id
            ));
            if (!empty($wpdb->last_error)) { return new WP_Error('wsm_zk_legacy_lookup_failed', 'بررسی تکرار تردد انجام نشد.', array('status'=>500)); }
            if ($legacy && (string)$legacy->device_user_id === $uid && (string)$legacy->direction === $direction && (string)$legacy->occurred_at === $site_time) {
                $event_id = $client_id;
            }
            // INSERT IGNORE on the existing unique option_name key does not replace
            // a competing owner (unlike WordPress add_option's upsert). No raw SN/UID.
            $candidate = maybe_serialize(array('bridge_id'=>$device_id, 'event_id'=>$event_id));
            $wpdb->last_error = '';
            $stored = $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO `{$wpdb->options}` (option_name,option_value,autoload) VALUES (%s,%s,%s)",
                $option_key, $candidate, 'no'
            ));
            if ($stored === false || !empty($wpdb->last_error)) {
                return new WP_Error('wsm_zk_idempotency_failed', 'ثبت کلید تکرار انجام نشد.', array('status'=>503));
            }
            $wpdb->last_error = '';
            $mapped = maybe_unserialize($wpdb->get_var($wpdb->prepare(
                "SELECT option_value FROM `{$wpdb->options}` WHERE option_name=%s LIMIT 1", $option_key
            )));
            if (!empty($wpdb->last_error) || !is_array($mapped) || empty($mapped['bridge_id']) || empty($mapped['event_id']) ||
                !is_string($mapped['event_id']) || !preg_match('/\A[a-f0-9]{64}\z/D', $mapped['event_id'])) {
                return new WP_Error('wsm_zk_idempotency_failed', 'ثبت کلید تکرار انجام نشد.', array('status'=>503));
            }
            $owner_id = (int)$mapped['bridge_id'];
            $event_id = $mapped['event_id'];
            $wpdb->last_error = '';
            $existing = $wpdb->get_row($wpdb->prepare(
                'SELECT device_user_id,direction,occurred_at FROM ' . WSM_Club::table('attendance') . ' WHERE source_device_id=%d AND event_id=%s LIMIT 1',
                $owner_id, $event_id
            ));
            if (!empty($wpdb->last_error)) { return new WP_Error('wsm_zk_duplicate_lookup_failed', 'بررسی تکرار تردد انجام نشد.', array('status'=>500)); }
            if ($existing && ((string)$existing->device_user_id !== $uid || (string)$existing->direction !== $direction || (string)$existing->occurred_at !== $site_time)) {
                return new WP_Error('wsm_zk_event_conflict', 'رویداد تکراری با محتوای متفاوت پذیرفته نشد.', array('status'=>409));
            }
            if ($owner_id !== $device_id) {
                // Do not use a different bridge's earlier "allowed" to open a gate.
                // If its write is still pending, fail closed and allow later retry.
                $rejected[$index] = array('index'=>$index, 'event_id'=>$client_id, 'accepted'=>false,
                    'duplicate'=>(bool)$existing, 'error_code'=>$existing ? 'wsm_zk_duplicate_other_bridge' : 'wsm_zk_source_pending',
                    'message'=>$existing ? 'رویداد توسط پل دیگر ثبت شده است.' : 'ثبت رویداد در پل دیگر هنوز مشخص نیست.');
                continue;
            }
            $event['event_id'] = $event_id;
            $event['device_user_id'] = $uid;
            $event['direction'] = $direction;
            $compact_index = count($events);
            $events[] = $event;
            $index_map[$compact_index] = $index;
            $client_ids[$index] = $client_id;
        }
        // The ordinary ingestion path performs eligibility and writes its own audit.
        // SMS suppression is scoped to this call and restored even on exceptions.
        $result = $events ? WSM_Club::with_sms_events_suppressed(function() use ($events) {
            return WSM_Club::ingest_events(array('events'=>$events));
        }) : array('received'=>0, 'rejected'=>0, 'items'=>array());
        if (is_wp_error($result) || !is_array($result) || !isset($result['items']) || !is_array($result['items'])) { return $result; }
        foreach ($result['items'] as $item) {
            $compact = isset($item['index']) ? (int)$item['index'] : -1;
            if (!isset($index_map[$compact])) { return new WP_Error('wsm_zk_response_invalid', 'پاسخ تردد قابل تطبیق نیست.', array('status'=>500)); }
            $index = $index_map[$compact];
            $item['index'] = $index;
            $item['event_id'] = $client_ids[$index];
            $rejected[$index] = $item;
        }
        ksort($rejected);
        $result['items'] = array_values($rejected);
        $result['rejected'] = count(array_filter($result['items'], function($item) { return empty($item['accepted']); }));
        return $result;
    }

    public static function update_check($request) {
        return WSM_Updater::remote_info(!empty($request->get_param('force')));
    }

    public static function activity_log_alias_permission($request) {
        if (!WSM_Util::is_woo_active()) { return WSM_Util::woo_required_error(); }
        if (WSM_Security::blocked_until()) { return new WP_Error('wsm_ip_blocked', 'IP شما موقتاً مسدود است.', array('status' => 429)); }
        $token = WSM_Permissions::extract_token($request);
        if ($token === '') { return new WP_Error('wsm_no_token', 'توکن ارسال نشده است.', array('status' => 401)); }
        $device = WSM_Auth::validate_bearer($token);
        if (is_wp_error($device)) { return $device; }
        $signed = WSM_Security::verify_signature($request, $device);
        if (is_wp_error($signed)) { return $signed; }
        $user = get_userdata((int) $device->user_id);
        if (!$user || get_user_meta((int) $device->user_id, 'wsm_app_user_status', true) === 'inactive') {
            return new WP_Error('wsm_forbidden', 'دسترسی به این بخش ندارید.', array('status' => 403));
        }
        $permission_record = WSM_Permissions::user_permissions_record((int) $device->user_id);
        $legacy_manager = WSM_Permissions::is_wordpress_admin_user($user) || in_array('administrator', (array) $user->roles, true) || in_array('shop_manager', (array) $user->roles, true) || !empty($user->allcaps['manage_woocommerce']) || !empty($user->allcaps['manage_options']);
        $app_account = get_user_meta((int) $device->user_id, 'wsm_app_user_status', true) === 'active' || (string) get_user_meta((int) $device->user_id, 'wsm_app_role', true) !== '' || $permission_record !== null;
        if (!$legacy_manager && !$app_account) { return new WP_Error('wsm_forbidden', 'دسترسی به این بخش ندارید.', array('status' => 403)); }
        WSM_Permissions::set_device($device);
        if (!WSM_Devices::device_can($device, 'users.super_admin.assign')) {
            return new WP_Error('wsm_device_permission_denied', 'این دستگاه مجوز مشاهدهٔ گزارش مدیر را ندارد.', array('status' => 403));
        }
        return true;
    }

    public static function activity($request) {
        $device = WSM_Permissions::current_device();
        $can_all = $device && (WSM_Devices::device_can($device, 'activity.view') || WSM_Devices::device_can($device, 'activity.view.all'));
        $can_mine = $device && WSM_Devices::device_can($device, 'activity.view.mine');
        if (!$can_all && !$can_mine) {
            return new WP_Error('wsm_activity_forbidden', 'مجوز مشاهدهٔ فعالیت را ندارید.', array('status' => 403));
        }
        $requested_limit = (int) $request->get_param('limit');
        $requested_limit = max(1, min(1000, $requested_limit > 0 ? $requested_limit : 100));
        $ip_filter = self::scalar_param($request, 'ip');
        if ($ip_filter === '') { $ip_filter = self::scalar_param($request, 'ip_address'); }
        $args = array(
            'device_id' => absint($request->get_param('device_id')),
            'user_id'   => absint($request->get_param('user_id')),
            'action'    => self::scalar_param($request, 'action'),
            'result'    => self::scalar_param($request, 'result'),
            'date_from' => self::scalar_param($request, 'date_from'),
            'date_to'   => self::scalar_param($request, 'date_to'),
            // Fetch the API cap before the in-memory IP match, then apply the requested page size.
            'limit'     => $ip_filter !== '' ? 1000 : $requested_limit,
        );
        // A mine-only grant is always scoped to the account, regardless of caller-supplied filters.
        if (!$can_all || self::scalar_param($request, 'scope') === 'mine') {
            unset($args['device_id']);
            $args['user_id'] = (int) $device->user_id;
        }
        $items = WSM_Activity_Log::query($args);
        if ($ip_filter !== '') {
            $items = array_values(array_filter($items, function ($row) use ($ip_filter) {
                return isset($row['ip_address']) && stripos((string) $row['ip_address'], $ip_filter) !== false;
            }));
        }
        return array('items' => array_slice($items, 0, $requested_limit));
    }
    /* Phase16: portal-only adapters. All persistence uses existing WP rows; no DDL. */
    private static $portal16_actor = null;

    public static function portal16_types() {
        if(!get_role('buffet_staff'))add_role('buffet_staff','کارمند بوفه',array('read'=>true));
        register_post_type('wsm_buffet_order',array('label'=>'سفارش بوفه','public'=>false,'show_ui'=>false,'show_in_rest'=>false,'supports'=>array('title','custom-fields'),'map_meta_cap'=>true));
        register_post_type('wsm_portal_entry',array('label'=>'سوابق خصوصی پورتال','public'=>false,'show_ui'=>false,'show_in_rest'=>false,'supports'=>array('title','custom-fields'),'map_meta_cap'=>true));
    }
    public static function portal16_defaults() {
        $legacy=WSM_Club_Operations::settings();
        $m=array();foreach(array('qr_card'=>'کارت عضویت','subscription_status'=>'وضعیت اشتراک','raffle'=>'قرعه‌کشی','attendance_raffle'=>'قرعه‌کشی حضور برتر','support'=>'پشتیبانی','rules'=>'قوانین','wallet'=>'کیف پول','shop_banner'=>'فروشگاه','training_plan'=>'برنامه تمرینی','weight_bmi'=>'وزن و BMI','attendance_calendar'=>'تقویم حضور','supplement_reminder'=>'یادآور مکمل','streak'=>'زنجیره فعالیت','leaderboard'=>'۳ نفر برتر','feedback'=>'نظرات و پیشنهادات','feedback_slider'=>'بازتاب ورزشکاران','class_booking'=>'رزرو کلاس','buffet'=>'بوفه باشگاه') as $id=>$title){$m[$id]=array('enabled'=>$id!=='class_booking','title'=>$title);}
        $m['attendance_raffle']+=array('discount_percent'=>10,'expiry_days'=>30);
        $m['rules']['content']=(string)($legacy['portal_terms_text']??'');$m['wallet']['max_charge']=5000000;
        $m['shop_banner']+=array('link'=>'','image_url'=>'');$m['training_plan']['external_url']=(string)($legacy['portal_training_url']??'');
        $m['supplement_reminder']['interval_hours']=8;$m['streak']['target_days']=3;$m['leaderboard']['top_n']=3;$m['raffle']['exclude_friday_from_attendance']=true;$m['feedback_slider']+=array('require_approval'=>true,'auto_advance_seconds'=>5,'max_text_length'=>500);
        $m['buffet']+=array('require_stock'=>true,'payment_wallet'=>true,'payment_credit'=>true,'payment_cash'=>true,'notify_roles'=>array('buffet_staff','administrator'),'notify_sound'=>false,'staff_sms_enabled'=>false,'staff_sms_recipients'=>array(),'items'=>array());
        return array('general'=>array('portal_enabled'=>!empty($legacy['portal_enabled']),'portal_title'=>get_bloginfo('name')?:'باشگاه من','portal_logo_url'=>'','primary_color'=>'#6366f1','dark_mode'=>true,'welcome_message'=>'سلام {name} 👋','support_phone'=>'','support_hours'=>'۹ صبح تا ۱۰ شب'),
            'pwa'=>array('pwa_enabled'=>true,'app_name'=>get_bloginfo('name')?:'باشگاه من','app_short_name'=>'باشگاه','icon_192_url'=>'','icon_512_url'=>'','theme_color'=>'#0f0f1a','background_color'=>'#0f0f1a','show_install_button'=>true,'version'=>'2.3.0'), 'modules'=>$m);
    }
    public static function portal16_config($public=false) {
        $s=get_option('wsm_settings',array());$p=is_array($s)&&isset($s['portal'])&&is_array($s['portal'])?$s['portal']:array();
        $raw=$p;$p=array_replace_recursive(self::portal16_defaults(),$p);foreach(array('items','notify_roles','staff_sms_recipients') as $key)if(isset($raw['modules']['buffet'][$key]))$p['modules']['buffet'][$key]=$raw['modules']['buffet'][$key];
        if($public){unset($p['modules']['buffet']['notify_roles'],$p['modules']['buffet']['notify_sound'],$p['modules']['buffet']['staff_sms_enabled'],$p['modules']['buffet']['staff_sms_recipients']);$p['modules']['buffet']['items']=array_values(array_filter($p['modules']['buffet']['items'],function($i){return isset($i['active'])&&$i['active']===true;}));}
        return $p;
    }
    private static function is_excluded_from_attendance($date, $exclude_friday=true) {
        if (!$exclude_friday) { return false; }
        try {
            $local=(new DateTimeImmutable((string)$date,new DateTimeZone('Asia/Tehran')))->setTimezone(new DateTimeZone('Asia/Tehran'));
            return $local->format('w')==='5';
        } catch (Throwable $e) { return false; }
    }
    private static function portal16_error($code,$message,$status=400){return new WP_Error('wsm_portal_'.$code,$message,array('status'=>$status));}
    public static function portal16_uuid($value){return is_string($value)&&preg_match('/\A[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\z/i',$value)===1;}
    private static function portal16_is_list($v){return is_array($v)&&($v===array()||array_keys($v)===range(0,count($v)-1));}
    public static function portal16_array($v){return is_array($v);}
    public static function portal16_status_value($v){return is_string($v)&&in_array($v,array('pending','preparing','ready','delivered','cancelled'),true);}
    private static function portal16_url($s){if($s==='')return true;if(!is_string($s)||strlen($s)>1500||!filter_var($s,FILTER_VALIDATE_URL))return false;$p=wp_parse_url($s);return !empty($p['host'])&&empty($p['user'])&&empty($p['pass'])&&in_array(strtolower($p['scheme']??''),array('https','http'),true);}
    private static function portal16_number($v,$min,$max,$integer=false){return (is_int($v)||is_float($v))&&is_finite((float)$v)&&$v>=$min&&$v<=$max&&(!$integer||floor($v)===$v||is_int($v));}
    private static function portal16_validate_config($input,$defaults,$path='') {
        if(!is_array($input))return self::portal16_error('settings_type','ساختار تنظیمات باید یک شیء معتبر باشد.');
        foreach($input as $key=>$v){
            $p=$path===''?$key:$path.'.'.$key;
            if(!array_key_exists($key,$defaults))return self::portal16_error('unknown_field','فیلد ناشناخته: '.$p);
            $d=$defaults[$key];
            if($p==='modules.buffet.items'){
                if(!is_array($v)||!self::portal16_is_list($v)||count($v)>200)return self::portal16_error('items_limit','فهرست بوفه حداکثر ۲۰۰ آیتم دارد.');
                $seen=array();foreach($v as $i){$valid=self::portal16_validate_item($i);if(is_wp_error($valid))return $valid;if(isset($seen[$i['id']]))return self::portal16_error('duplicate_item','شناسهٔ آیتم تکراری است.');$seen[$i['id']]=true;}continue;
            }
            if($p==='modules.buffet.staff_sms_recipients'){$valid=self::portal16_buffet_sms_validate_recipients($v);if(is_wp_error($valid))return $valid;continue;}
            if($p==='modules.buffet.notify_roles'){
                if(!is_array($v)||!self::portal16_is_list($v)||!count($v)||count($v)>30)return self::portal16_error('roles','حداقل یک نقش دریافت‌کننده انتخاب کنید.');
                $roles=wp_roles()->roles;foreach($v as $r){if(!is_string($r)||!isset($roles[$r])||$r==='subscriber')return self::portal16_error('role_invalid','نقش دریافت اعلان معتبر نیست؛ subscriber مجاز نیست.');}continue;
            }
            if(is_array($d)){ $valid=self::portal16_validate_config($v,$d,$p);if(is_wp_error($valid))return $valid;continue; }
            if(is_bool($d)){if(!is_bool($v))return self::portal16_error('boolean','مقدار '.$p.' باید true یا false باشد.');continue;}
            if(in_array($key,array('max_charge','interval_hours','target_days','top_n','discount_percent','expiry_days','auto_advance_seconds','max_text_length'),true)){
                $bounds=array('max_charge'=>array(1,1000000000,false),'interval_hours'=>array(1,168,true),'target_days'=>array(1,365,true),'top_n'=>array(1,10,true),'discount_percent'=>array(1,100,true),'expiry_days'=>array(1,365,true),'auto_advance_seconds'=>array(3,30,true),'max_text_length'=>array(1,500,true));$b=$bounds[$key];if(!self::portal16_number($v,$b[0],$b[1],$b[2]))return self::portal16_error('number','مقدار عددی '.$p.' خارج از محدوده است.');continue;
            }
            if(!is_string($v)||mb_strlen($v)>($key==='content'?10000:($key==='welcome_message'?500:1500)))return self::portal16_error('text','متن '.$p.' معتبر نیست.');
            if(in_array($key,array('primary_color','theme_color','background_color'),true)&&!preg_match('/\A#[a-f0-9]{6}\z/i',$v))return self::portal16_error('color','رنگ باید به شکل #RRGGBB باشد.');
            if((substr($key,-4)==='_url'||$key==='link')&&!self::portal16_url($v))return self::portal16_error('url','نشانی فقط http/https معتبر می‌پذیرد.');
            if(in_array($key,array('title','portal_title','app_name','app_short_name'),true)&&(trim($v)===''||mb_strlen($v)>80))return self::portal16_error('title','عنوان نباید خالی یا بیشتر از ۸۰ نویسه باشد.');
            if($key==='version'&&!preg_match('/\A[a-zA-Z0-9._-]{1,50}\z/',$v))return self::portal16_error('version','نسخهٔ کش معتبر نیست.');
        }
        return true;
    }
    private static function portal16_validate_item($i){
        $keys=array('id','name','price','unit_type','stock','active','image_url','category');
        if(!is_array($i)||array_diff(array_keys($i),$keys)||array_diff($keys,array_keys($i)))return self::portal16_error('item_shape','تمام فیلدهای آیتم بوفه لازم است.');
        if(!self::portal16_uuid($i['id']))return self::portal16_error('item_uuid','شناسهٔ آیتم باید UUID v4 باشد.');
        if(!is_string($i['name'])||trim($i['name'])===''||mb_strlen($i['name'])>120)return self::portal16_error('item_name','نام آیتم لازم و حداکثر ۱۲۰ نویسه است.');
        if(!self::portal16_number($i['price'],0.000001,1000000000)||abs($i['price']-round($i['price'],6))>0.00000001)return self::portal16_error('item_price','قیمت باید یک عدد مثبت با حداکثر ۶ رقم اعشار باشد.');
        if(!self::portal16_number($i['stock'],0,100000000,true))return self::portal16_error('item_stock','موجودی باید عدد صحیح نامنفی باشد؛ موجودی وزنی برحسب گرم است.');
        if(!in_array($i['unit_type'],array('piece','weight_gram','weight_kilo'),true)||!is_bool($i['active'])||!self::portal16_url($i['image_url'])||!is_string($i['category'])||mb_strlen($i['category'])>80)return self::portal16_error('item_fields','واحد، وضعیت، تصویر یا دسته‌بندی معتبر نیست.');
        return true;
    }
    /** A verified WP cookie MUST have its REST nonce; app sessions keep existing HMAC checks. */
    private static function portal16_staff_auth($request){
        if(get_current_user_id()>0){if(!wp_verify_nonce((string)$request->get_header('x-wp-nonce'),'wp_rest'))return self::portal16_error('nonce','nonce معتبر لازم است.',403);return wp_get_current_user();}
        if((string)$request->get_header('authorization')===''&&(string)$request->get_header('x-wsm-token')==='')return self::portal16_error('nonce','nonce یا نشست امضاشده معتبر لازم است.',403);
        $checked=WSM_Permissions::check_request($request);
        if(is_wp_error($checked)&&!in_array($checked->get_error_code(),array('wsm_permission_unmapped','wsm_device_permission_denied'),true))return $checked;
        $d=WSM_Permissions::current_device();if(!$d||$checked===false)return self::portal16_error('staff_auth','نشست معتبر کارمند لازم است.',403);
        $u=get_userdata((int)$d->user_id);return $u?:self::portal16_error('staff_auth','حساب کارمند موجود نیست.',403);
    }
    public static function portal16_admin_permission($request){
        $u=self::portal16_staff_auth($request);if(is_wp_error($u))return $u;
        if(!user_can($u,'manage_options'))return self::portal16_error('admin_only','تنظیمات پورتال فقط برای manage_options مجاز است.',403);
        self::$portal16_actor=array('kind'=>'staff','user_id'=>(int)$u->ID);return true;
    }
    public static function portal16_staff_permission($request){
        $u=self::portal16_staff_auth($request);if(is_wp_error($u))return $u;
        $p=self::portal16_config();if(!array_intersect((array)$u->roles,(array)$p['modules']['buffet']['notify_roles']))return self::portal16_error('buffet_role','نقش شما در buffet.notify_roles مجاز نیست.',403);
        self::$portal16_actor=array('kind'=>'staff','user_id'=>(int)$u->ID);return true;
    }
    private static function portal16_athlete($r){
        $a=WSM_Club_Operations::portal16_member($r);if(is_wp_error($a))return $a;
        foreach(array('athlete_id','member_id') as $field){$requested=$r->get_param($field);if($requested!==null&&absint($requested)!==(int)$a->id)return self::portal16_error('owner','فقط داده‌های حساب احراز هویت‌شده مجاز است.',403);}
        self::$portal16_actor=array('kind'=>'athlete','member_id'=>(int)$a->id);return $a;
    }
    public static function portal16_athlete_permission($r){$a=self::portal16_athlete($r);return is_wp_error($a)?$a:true;}
    public static function portal16_menu_permission($r){
        $token=(string)$r->get_header('x-wsm-athlete-token');if($token!==''||strpos((string)$r->get_header('authorization'),'Bearer wsma_')===0)return self::portal16_athlete_permission($r);
        $u=self::portal16_staff_auth($r);if(is_wp_error($u))return $u;
        $p=self::portal16_config();if(!user_can($u,'manage_options')&&!array_intersect((array)$u->roles,array_merge(array('shop_manager'),$p['modules']['buffet']['notify_roles'])))return self::portal16_error('menu_role','دسترسی منوی بوفه مجاز نیست.',403);return true;
    }
    public static function portal16_order_permission($r){
        if((string)$r->get_header('x-wsm-athlete-token')!==''||strpos((string)$r->get_header('authorization'),'Bearer wsma_')===0)return self::portal16_athlete_permission($r);
        return self::portal16_admin_permission($r);
    }
    public static function portal16_routes(){
        $routes=array(
            array('/portal/settings','GET','portal16_settings_get','portal16_admin_permission',array()),
            array('/portal/settings','POST','portal16_settings_save','portal16_admin_permission',array('portal'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_array')))),
            array('/portal/buffet/items','GET','portal16_items_get','portal16_menu_permission',array()),
            array('/portal/buffet/items','POST','portal16_items_save','portal16_admin_permission',array('item'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_array')))),
            array('/portal/buffet/items/(?P<id>[a-fA-F0-9-]{36})','DELETE','portal16_item_delete','portal16_admin_permission',array('id'=>array('validate_callback'=>array(__CLASS__,'portal16_uuid')))),
            array('/portal/buffet/order','POST','portal16_order_create','portal16_order_permission',array('uuid'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_uuid')),'items'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_array')))),
            array('/portal/buffet/mine','GET','portal16_orders_mine','portal16_athlete_permission',array()),
            array('/portal/buffet/mine/(?P<id>\d+)','GET','portal16_order_mine','portal16_athlete_permission',array('id'=>array('validate_callback'=>function($v){return ctype_digit((string)$v)&&(int)$v>0;}))),
            array('/portal/buffet/orders','GET','portal16_orders_get','portal16_staff_permission',array()),
            array('/portal/buffet/orders/(?P<id>\d+)','PATCH','portal16_order_status','portal16_staff_permission',array('uuid'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_uuid')),'status'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_status_value')))),
            array('/portal/buffet/orders/(?P<id>\d+)','DELETE','portal16_order_cancel','portal16_staff_permission',array('uuid'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_uuid')))),
            array('/portal/buffet/pending','GET','portal16_pending','portal16_staff_permission',array()),
            array('/portal/state','GET','portal16_state','portal16_athlete_permission',array()),
            array('/portal/attendance-raffle','GET','portal16_attendance_raffle_admin','portal16_admin_permission',array()),
            array('/portal/attendance-raffle/draw','POST','portal16_attendance_raffle_draw','portal16_admin_permission',array()),
            array('/portal/supplement/schedules','POST','portal16_supplement_schedule_save','portal16_athlete_permission',array()),
            array('/portal/supplement/dose','POST','portal16_supplement_dose','portal16_athlete_permission',array()),
            array('/portal/progress','POST','portal16_progress','portal16_athlete_permission',array('uuid'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_uuid')))),
            array('/portal/feedback','POST','portal16_feedback','portal16_athlete_permission',array('uuid'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_uuid')))),
            array('/portal/feedback/list','GET','portal16_feedback_slider_list','portal16_athlete_permission',array()),
            array('/portal/feedback/submit','POST','portal16_feedback_slider_submit','portal16_athlete_permission',array('uuid'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_uuid')),'text'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_feedback_text_value')))),
            array('/club/feedback/list','GET','portal16_feedback_admin_list','portal16_admin_permission',array('status'=>array('default'=>'pending','validate_callback'=>array(__CLASS__,'portal16_feedback_status_value')),'per_page'=>array('default'=>50,'validate_callback'=>array(__CLASS__,'portal16_feedback_limit_value')))),
            array('/club/feedback/moderate','POST','portal16_feedback_moderate','portal16_admin_permission',array('post_id'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_feedback_id_value')),'action'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_feedback_action_value')),'admin_reply'=>array('validate_callback'=>array(__CLASS__,'portal16_feedback_reply_value')))),
            array('/club/feedback/block','POST','portal16_feedback_block','portal16_admin_permission',array('member_id'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_feedback_id_value')),'blocked'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_feedback_bool_value')))),
            array('/club/feedback/blocked','GET','portal16_feedback_blocked','portal16_admin_permission',array()),
            array('/portal/profile','POST','portal16_profile','portal16_athlete_permission',array('uuid'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_uuid')))),
            array('/portal/wallet/checkout','POST','portal16_wallet_checkout','portal16_athlete_permission',array('uuid'=>array('required'=>true,'validate_callback'=>array(__CLASS__,'portal16_uuid')))),
            array('/portal/media','POST','portal16_media','portal16_admin_permission',array()),
        );
        foreach($routes as $a)register_rest_route(self::NS,$a[0],array('methods'=>$a[1],'callback'=>array(__CLASS__,$a[2]),'permission_callback'=>array(__CLASS__,$a[3]),'args'=>$a[4]));
    }
    public static function portal16_menu_revision($p){$rows=array();foreach($p['modules']['buffet']['items'] as $i)if($i['active']===true)$rows[]=array('id'=>$i['id'],'unit_type'=>$i['unit_type'],'price'=>$i['price']);return hash('sha256',wp_json_encode($rows));}
    private static function portal16_check_reserved_units($p){
        $map=array_column($p['modules']['buffet']['items'],null,'id');$ids=get_posts(array('post_type'=>'wsm_buffet_order','post_status'=>'publish','numberposts'=>-1,'fields'=>'ids','meta_query'=>array(array('key'=>'status','value'=>array('pending','preparing','ready'),'compare'=>'IN'))));
        foreach($ids as $id){$o=self::portal16_order_data($id);if(!$o||empty($o['stock_reserved']))continue;foreach($o['items'] as $li){if(isset($map[$li['id']])&&$map[$li['id']]['unit_type']!==$li['unit_type'])return self::portal16_error('reserved_unit','واحد آیتم دارای سفارش فعال قابل تغییر نیست؛ ابتدا سفارش‌ها را تعیین تکلیف کنید.',409);}}return true;
    }
    private static function portal16_revision($p){return hash('sha256',wp_json_encode($p));}
    public static function portal16_settings_get($r){$p=self::portal16_config();return array('portal'=>self::portal16_buffet_sms_admin_view($p),'buffet_sms_service'=>self::portal16_buffet_sms_service(),'revision'=>self::portal16_revision($p),'roles'=>array_map(function($id,$v){return array('id'=>$id,'name'=>$v['name']);},array_keys(wp_roles()->roles),array_values(wp_roles()->roles)),'can_manage'=>true,'portal_url'=>home_url('/athlete-portal/'));}
    private static function portal16_lock(){
        $name='wsm_portal16_mutation_lock';$token=wp_generate_uuid4();
        if(!add_option($name,array('token'=>$token,'expires'=>time()+300),'',false)){
            $old=get_option($name);if(is_array($old)&&(int)($old['expires']??0)<time()){
                global $wpdb;$deleted=$wpdb->query($wpdb->prepare('DELETE FROM '.$wpdb->options.' WHERE option_name=%s AND BINARY option_value=BINARY %s',$name,maybe_serialize($old)));
                wp_cache_delete($name,'options');wp_cache_delete('notoptions','options');
                if($deleted===1&&add_option($name,array('token'=>$token,'expires'=>time()+300),'',false))return $token;
            }
            return self::portal16_error('busy','عملیات دیگری در حال ثبت است؛ با همان UUID دوباره تلاش کنید.',503);
        }
        return $token;
    }
    private static function portal16_unlock($token){$v=get_option('wsm_portal16_mutation_lock');if(is_array($v)&&hash_equals($v['token']??'',(string)$token))delete_option('wsm_portal16_mutation_lock');}
    private static function portal16_store_config($p){$s=get_option('wsm_settings',array());$s=is_array($s)?$s:array();$s['portal']=$p;$old=get_option('wsm_settings');if($old===$s)return true;return update_option('wsm_settings',$s,false);}
    public static function portal16_settings_save($r){
        $p=$r->get_param('portal');$v=self::portal16_validate_config($p,self::portal16_defaults());if(is_wp_error($v))return $v;
        $lock=self::portal16_lock();if(is_wp_error($lock))return $lock;
        try{$old=self::portal16_config();$rev=$r->get_param('revision');if($rev!==null&&(!is_string($rev)||!hash_equals(self::portal16_revision($old),$rev)))return self::portal16_error('settings_conflict','تنظیمات در صفحه‌ای دیگر تغییر کرده؛ بازخوانی کنید.',409);
            $incoming=$p;$p=array_replace_recursive($old,$p);foreach(array('items','notify_roles','staff_sms_recipients') as $key)if(isset($incoming['modules']['buffet'][$key]))$p['modules']['buffet'][$key]=$incoming['modules']['buffet'][$key];
            if(isset($incoming['modules']['buffet'])&&array_key_exists('staff_sms_recipients',$incoming['modules']['buffet'])){$prepared=self::portal16_buffet_sms_storage($p,$old);if(is_wp_error($prepared))return $prepared;$p=$prepared;}
            $unit_check=self::portal16_check_reserved_units($p);if(is_wp_error($unit_check))return $unit_check;
            if(!$p['modules']['buffet']['payment_wallet']&&!$p['modules']['buffet']['payment_credit']&&!$p['modules']['buffet']['payment_cash'])return self::portal16_error('payment_required','حداقل یک روش پرداخت بوفه باید فعال باشد.');
            if(!self::portal16_store_config($p))return self::portal16_error('save_failed','ذخیرهٔ تنظیمات تأیید نشد.',500);return self::portal16_settings_get($r);
        }finally{self::portal16_unlock($lock);}
    }
    public static function portal16_items_get($r){$p=self::portal16_config(true);if(!$p['general']['portal_enabled']||!$p['modules']['buffet']['enabled'])return self::portal16_error('buffet_disabled','بوفه یا پورتال غیرفعال است.',403);return array('items'=>$p['modules']['buffet']['items'],'policy'=>$p['modules']['buffet'],'menu_revision'=>self::portal16_menu_revision($p),'currency'=>get_woocommerce_currency());}
    public static function portal16_items_save($r){$i=$r->get_param('item');$valid=self::portal16_validate_item($i);if(is_wp_error($valid))return $valid;$lock=self::portal16_lock();if(is_wp_error($lock))return $lock;try{$p=self::portal16_config();$items=$p['modules']['buffet']['items'];$found=false;foreach($items as &$row){if($row['id']===$i['id']){$row=$i;$found=true;break;}}unset($row);if(!$found){if(count($items)>=200)return self::portal16_error('items_limit','سقف آیتم‌ها تکمیل است.');$items[]=$i;}$p['modules']['buffet']['items']=$items;$unit_check=self::portal16_check_reserved_units($p);if(is_wp_error($unit_check))return $unit_check;if(!self::portal16_store_config($p))return self::portal16_error('save_failed','ثبت آیتم تأیید نشد.',500);return array('item'=>$i,'portal'=>$p);}finally{self::portal16_unlock($lock);}}
    public static function portal16_item_delete($r){$lock=self::portal16_lock();if(is_wp_error($lock))return $lock;try{$p=self::portal16_config();$id=(string)$r['id'];$old=$p['modules']['buffet']['items'];$p['modules']['buffet']['items']=array_values(array_filter($old,function($i)use($id){return $i['id']!==$id;}));if(count($old)===count($p['modules']['buffet']['items']))return self::portal16_error('item_missing','آیتم پیدا نشد.',404);if(!self::portal16_store_config($p))return self::portal16_error('save_failed','حذف تأیید نشد.',500);return array('deleted'=>true,'id'=>$id);}finally{self::portal16_unlock($lock);}}
    private static function portal16_lookup_uuid($uuid,$type='wsm_buffet_order'){$ids=get_posts(array('post_type'=>$type,'post_status'=>array('publish','private','pending','draft','trash'),'numberposts'=>1,'fields'=>'ids','meta_key'=>'order_uuid','meta_value'=>$uuid,'suppress_filters'=>true));return $ids?(int)$ids[0]:0;}
    private static function portal16_order_data($id){$p=get_post($id);if(!$p||$p->post_type!=='wsm_buffet_order')return null;$d=get_post_meta($id,'_wsm_portal_order',true);if(!is_array($d))return null;$d['id']=(int)$id;return $d;}
    private static function portal16_order_save($id,$d){update_post_meta($id,'_wsm_portal_order',$d);foreach(array('order_uuid','athlete_id','items','total_price','payment_method','status','created_at') as $k){update_post_meta($id,$k,$k==='items'?wp_json_encode($d[$k]):$d[$k]);}clean_post_cache($id);return get_post_meta($id,'_wsm_portal_order',true)===$d;}
    private static function portal16_precision($n){$d=min(6,max(0,(int)wc_get_price_decimals()));return abs((float)$n-round((float)$n,$d))<0.0000001;}
    private static function portal16_quote($b,$lines){
        if(!is_array($lines)||!self::portal16_is_list($lines)||!count($lines)||count($lines)>50)return self::portal16_error('cart','سبد باید ۱ تا ۵۰ ردیف داشته باشد.');$menu=array_column($b['items'],null,'id');$seen=array();$out=array();$total=0;
        foreach($lines as $line){if(!is_array($line)||array_diff(array_keys($line),array('id','quantity'))||!isset($line['id'],$line['quantity'])||!self::portal16_uuid($line['id'])||isset($seen[$line['id']]))return self::portal16_error('cart_line','ردیف سبد نامعتبر یا تکراری است.');$seen[$line['id']]=true;$i=$menu[$line['id']]??null;if(!$i||$i['active']!==true)return self::portal16_error('item_unavailable','یکی از آیتم‌ها حذف یا غیرفعال شده است.',409);
            $q=$line['quantity'];if(!self::portal16_number($q,0.001,1000000))return self::portal16_error('quantity','تعداد یا وزن معتبر نیست.');
            if($i['unit_type']==='piece'){if(floor($q)!=$q||$q<1)return self::portal16_error('piece_quantity','تعداد باید صحیح و حداقل ۱ باشد.');$consume=(int)$q;$amount=$i['price']*$q;}
            else{$consume=$i['unit_type']==='weight_kilo'?$q*1000:$q;if(abs($consume-round($consume))>0.0000001||$consume<100)return self::portal16_error('weight_quantity','وزن حداقل ۱۰۰ گرم و بدون کسر گرم است.');$consume=(int)round($consume);$amount=$i['price']*$consume/1000;}
            if($b['require_stock']&&$consume>$i['stock'])return self::portal16_error('stock','موجودی کافی نیست؛ منو را بازخوانی کنید.',409);
            if(!self::portal16_precision($amount))return self::portal16_error('currency_precision','جمع ردیف با دقت پول فروشگاه سازگار نیست؛ تعداد/وزن را اصلاح کنید.',409);
            $amount=(float)wc_format_decimal($amount,wc_get_price_decimals());$total+=$amount;$out[]=array('id'=>$i['id'],'name'=>$i['name'],'unit_type'=>$i['unit_type'],'unit_price'=>$i['price'],'quantity'=>$q,'consumed_units'=>$consume,'line_total'=>$amount,'image_url'=>$i['image_url']);
        }
        if($total<=0||$total>1000000000000)return self::portal16_error('total','جمع سفارش خارج از محدوده است.');return array('items'=>$out,'total'=>(string)wc_format_decimal($total,wc_get_price_decimals()));
    }
    private static function portal16_member_for_order($r){if((self::$portal16_actor['kind']??'')==='athlete')return self::portal16_athlete($r);$id=$r->get_param('athlete_id');if(!is_int($id)||$id<1)return self::portal16_error('athlete_required','مدیر باید شناسهٔ ورزشکار را تعیین کند.');return WSM_Club_Operations::portal16_member_by_id($id);}
    public static function portal16_order_create($r){
        global $wpdb;$a=self::portal16_member_for_order($r);if(is_wp_error($a))return $a;if(!$a||$a->status!=='active')return self::portal16_error('athlete','پروندهٔ فعال پیدا نشد.',403);
        $body=$r->get_json_params();if(array_diff(array_keys($body),array('uuid','items','payment_method','athlete_id','currency','menu_revision','quoted_total')))return self::portal16_error('order_fields','فیلد غیرمجاز در سفارش.');if(isset($body['athlete_id'])&&(int)$body['athlete_id']!==(int)$a->id)return self::portal16_error('owner','سفارش فقط برای ورزشکار احرازشده مجاز است.',403);
        $uuid=strtolower((string)$body['uuid']);$hash=hash('sha256',wp_json_encode(array('athlete_id'=>(int)$a->id,'items'=>$body['items'],'payment_method'=>$body['payment_method']??'','currency'=>$body['currency']??get_woocommerce_currency(),'menu_revision'=>$body['menu_revision']??'','quoted_total'=>$body['quoted_total']??null)));
        $lock=self::portal16_lock();if(is_wp_error($lock))return $lock;$id=0;$woo_id=0;$committed=false;
        try{
            $existing=self::portal16_lookup_uuid($uuid);if($existing){$d=self::portal16_order_data($existing);if((int)$d['athlete_id']!==(int)$a->id)return self::portal16_error('uuid_owner','شناسهٔ درخواست قابل استفاده نیست.',409);if(!hash_equals($d['request_hash'],$hash))return self::portal16_error('uuid_conflict','UUID با درخواست دیگری استفاده شده است.',409);$d['replayed']=true;return $d;}
            $p=self::portal16_config();$b=$p['modules']['buffet'];if(!$p['general']['portal_enabled']||!$b['enabled'])return self::portal16_error('buffet_disabled','بوفه یا پورتال غیرفعال است.',403);
            $method=$body['payment_method']??'';if(!in_array($method,array('wallet','credit','cash'),true)||$b['payment_'.$method]!==true)return self::portal16_error('payment_disabled','روش پرداخت فعال نیست.',403);
            $currency=get_woocommerce_currency();if(!isset($body['currency'])||$body['currency']!==$currency)return self::portal16_error('currency_changed','واحد پول تغییر کرده؛ سفارش را با قیمت‌های تازه تأیید کنید.',409);
            $q=self::portal16_quote($b,$body['items']);if(is_wp_error($q))return $q;
            if(!isset($body['menu_revision'])||!is_string($body['menu_revision'])||!hash_equals(self::portal16_menu_revision($p),$body['menu_revision']))return self::portal16_error('menu_changed','قیمت یا واحد منو تغییر کرده؛ بازخوانی و تأیید دوباره لازم است.',409);
            if(!isset($body['quoted_total'])||!self::portal16_number($body['quoted_total'],0.000001,1000000000000)||abs((float)$body['quoted_total']-(float)$q['total'])>0.000001)return self::portal16_error('quote_changed','جمع تأییدشده با قیمت جاری متفاوت است؛ هیچ مبلغی کسر نشد.',409);
            if($wpdb->query('START TRANSACTION')===false)return self::portal16_error('transaction','آغاز تراکنش انجام نشد.',500);
            $id=wp_insert_post(array('post_type'=>'wsm_buffet_order','post_status'=>'publish','post_title'=>'سفارش بوفه '.$uuid,'meta_input'=>array('order_uuid'=>$uuid,'athlete_id'=>(int)$a->id,'_wsm_buffet_origin'=>((self::$portal16_actor['kind']??'')==='athlete'?'athlete_portal':'staff_admin'))),true);if(is_wp_error($id))return $id;
            if($method==='wallet'){$n=$wpdb->query($wpdb->prepare('UPDATE '.WSM_Club::table('members').' SET card_balance=card_balance-CAST(%s AS DECIMAL(20,6)),updated_at=%s WHERE id=%d AND card_balance>=CAST(%s AS DECIMAL(20,6))',$q['total'],current_time('mysql'),(int)$a->id,$q['total']));if($n!==1)return self::portal16_error('insufficient_wallet','موجودی کیف پول کافی نیست.',409);}
            if($method==='credit'){
                $woo=wc_create_order(array('status'=>'on-hold','created_via'=>'wp-store-manager'));if(is_wp_error($woo))return $woo;$woo_id=$woo->get_id();$woo->set_currency($currency);$woo->set_billing_first_name($a->first_name);$woo->set_billing_last_name($a->last_name);$woo->set_payment_method('manual');$woo->set_payment_method_title('نسیه بوفه');
                foreach($q['items'] as $li){$fee=new WC_Order_Item_Fee();$fee->set_name($li['name'].' × '.$li['quantity']);$fee->set_amount($li['line_total']);$fee->set_total($li['line_total']);$fee->set_tax_status('none');$woo->add_item($fee);}
                foreach(array('_wsm_club_pos'=>'1','_wsm_club_member_id'=>(int)$a->id,'_wsm_club_pos_debt'=>'1','_wsm_club_pos_debt_amount'=>$q['total'],'_wsm_athlete_portal_member_id'=>(int)$a->id,'_wsm_buffet_uuid'=>$uuid) as $k=>$v)$woo->update_meta_data($k,$v);$woo->set_total($q['total']);$woo->save();
                $ledger=WSM_Club_Operations::add_finance('pos_receivable',$q['total'],'بدهی بوفه '.$uuid,array('member_id'=>(int)$a->id,'order_id'=>$woo_id,'method'=>'credit_nasiye','source'=>'pos_debt','reference_id'=>'buffet:'.$uuid,'ledger_status'=>'pending','no_account'=>true));if(is_wp_error($ledger))return $ledger;
            }elseif($method==='wallet'){
                foreach(array(array('card_spend','liability'),array('pos_sale','income')) as $pair){$f=WSM_Club_Operations::add_finance($pair[0],$q['total'],'خرید بوفه '.$uuid,array('member_id'=>(int)$a->id,'method'=>'club_credit','source'=>'buffet_wallet','reference_id'=>'buffet:'.$uuid,'transaction_type'=>$pair[1],'no_account'=>true));if(is_wp_error($f))return $f;}
            }
            if($b['require_stock']){foreach($p['modules']['buffet']['items'] as &$i){foreach($q['items'] as $li){if($i['id']===$li['id'])$i['stock']-=$li['consumed_units'];}}unset($i);if(!self::portal16_store_config($p))return self::portal16_error('stock_save','ذخیره موجودی انجام نشد.',500);}
            $d=array('order_uuid'=>$uuid,'athlete_id'=>(int)$a->id,'athlete_name'=>trim($a->first_name.' '.$a->last_name),'avatar'=>'','items'=>$q['items'],'total_price'=>$q['total'],'payment_method'=>$method,'status'=>'pending','created_at'=>wp_date('c',null,new DateTimeZone('Asia/Tehran')),'updated_at'=>wp_date('c',null,new DateTimeZone('Asia/Tehran')),'currency'=>$currency,'currency_symbol'=>wsm_currency_symbol(),'request_hash'=>$hash,'wc_order_id'=>$woo_id,'stock_reserved'=>(bool)$b['require_stock'],'cash_collected'=>false,'events'=>array(array('uuid'=>$uuid,'status'=>'pending','at'=>wp_date('c',null,new DateTimeZone('Asia/Tehran')))));
            if(!self::portal16_order_save($id,$d))return self::portal16_error('order_save','ذخیره سفارش تأیید نشد.',500);
            if($wpdb->query('COMMIT')===false)return self::portal16_error('commit','ثبت نهایی تأیید نشد؛ با همان UUID بازآزمایی کنید.',500);$committed=true;$d['id']=(int)$id;
        }finally{if(!$committed){$wpdb->query('ROLLBACK');if($id&&!is_wp_error($id))clean_post_cache($id);wp_cache_delete('alloptions','options');wp_cache_delete('wsm_settings','options');}self::portal16_unlock($lock);}
        do_action('wsm_portal_buffet_saved',$id,$uuid);WSM_Club_Operations::portal16_customer_sms((int)$a->id,'buffet_purchase',$q['total']);return $d;
    }
    private static function portal16_list_orders($member=0,$pending=false){
        $args=array('post_type'=>'wsm_buffet_order','post_status'=>array('publish','trash'),'numberposts'=>100,'orderby'=>'ID','order'=>'DESC','suppress_filters'=>true);if($member){$args['meta_key']='athlete_id';$args['meta_value']=(string)$member;}if($pending)$args['meta_query']=array(array('key'=>'status','value'=>array('pending','preparing','ready'),'compare'=>'IN'));if($member)$args['numberposts']=-1;$rows=get_posts($args);$out=array();foreach($rows as $row){$d=self::portal16_order_data($row->ID);if($d&&(!$pending||in_array($d['status'],array('pending','preparing','ready'),true))){unset($d['request_hash']);$out[]=$d;}}return $out;
    }
    public static function portal16_orders_mine($r){$a=self::portal16_athlete($r);if(is_wp_error($a))return $a;$requested=$r->get_param('member_id');if($requested!==null&&absint($requested)!==(int)$a->id)return self::portal16_error('owner','سوابق فقط برای حساب احراز‌شده مجاز است.',403);return array('items'=>self::portal16_list_orders((int)$a->id));}
    public static function portal16_order_mine($r){$a=self::portal16_athlete($r);if(is_wp_error($a))return $a;$d=self::portal16_order_data((int)$r['id']);if(!$d)return self::portal16_error('order_missing','سفارش پیدا نشد.',404);if((int)$d['athlete_id']!==(int)$a->id)return self::portal16_error('owner','سفارش متعلق به حساب دیگری است.',403);unset($d['request_hash']);return $d;}
    public static function portal16_orders_get($r){return array('items'=>self::portal16_list_orders(),'poll_interval'=>7000,'silent_admin'=>true);}
    public static function portal16_pending($r){return array('items'=>self::portal16_list_orders(0,true),'poll_interval'=>7000,'notify_sound'=>self::portal16_config()['modules']['buffet']['notify_sound'],'silent_admin'=>true);}
    public static function portal16_order_cancel($r){$r->set_param('status','cancelled');return self::portal16_order_status($r);}
    public static function portal16_order_status($r){
        global $wpdb;$id=(int)$r['id'];$uuid=strtolower((string)$r['uuid']);$next=(string)$r['status'];$lock=self::portal16_lock();if(is_wp_error($lock))return $lock;$committed=false;$started=false;
        try{$d=self::portal16_order_data($id);if(!$d)return self::portal16_error('order_missing','سفارش پیدا نشد.',404);
            foreach($d['events'] as $e)if($e['uuid']===$uuid){if($e['status']!==$next)return self::portal16_error('event_conflict','UUID وضعیت با رویداد دیگری استفاده شده است.',409);$d['replayed']=true;return $d;}
            $edges=array('pending'=>array('preparing','cancelled'),'preparing'=>array('ready','cancelled'),'ready'=>array('delivered','cancelled'),'delivered'=>array(),'cancelled'=>array());
            if(!in_array($next,$edges[$d['status']]??array(),true))return self::portal16_error('status_transition','تغییر وضعیت به این ترتیب مجاز نیست.',409);
            if($d['currency']!==get_woocommerce_currency()&&($next==='cancelled'||($next==='delivered'&&$d['payment_method']==='cash')))return self::portal16_error('currency_changed','واحد پول سفارش متفاوت است؛ پیش از عملیات مالی تطبیق دهید.',409);
            if($wpdb->query('START TRANSACTION')===false)return self::portal16_error('transaction','آغاز تراکنش ناموفق بود.',500);
            $total=$d['total_price'];$a=(int)$d['athlete_id'];
            if($next==='cancelled'){
                if($d['payment_method']==='wallet'){
                    if($wpdb->query($wpdb->prepare('UPDATE '.WSM_Club::table('members').' SET card_balance=card_balance+CAST(%s AS DECIMAL(20,6)),updated_at=%s WHERE id=%d',$total,current_time('mysql'),$a))!==1)return self::portal16_error('refund','بازگردانی اعتبار انجام نشد.',500);
                    $f=WSM_Club_Operations::add_finance('card_recharge',$total,'بازگشت اعتبار بوفه '.$d['order_uuid'],array('member_id'=>$a,'method'=>'club_credit','source'=>'buffet_refund','reference_id'=>'buffet-refund:'.$d['order_uuid'],'no_account'=>true,'transaction_type'=>'liability'));if(is_wp_error($f))return $f;
                    $f=WSM_Club_Operations::add_finance('pos_refund',$total,'ابطال خرید بوفه '.$d['order_uuid'],array('member_id'=>$a,'method'=>'club_credit','source'=>'buffet_refund','reference_id'=>'buffet-refund:'.$d['order_uuid'],'no_account'=>true));if(is_wp_error($f))return $f;
                }elseif($d['payment_method']==='credit'){
                    $woo=wc_get_order((int)$d['wc_order_id']);if(!$woo)return self::portal16_error('debt_order','فاکتور بدهی یافت نشد.',409);
                    $remaining=WSM_Club_Operations::portal16_debt_due($woo);if(abs((float)$remaining-(float)$total)>0.000001)return self::portal16_error('debt_already_paid','بدهی این سفارش دریافت شده است؛ لغو نیازمند رسیدگی مالی موجود است.',409);
                    $woo->update_status('cancelled','لغو بوفه با UUID '.$uuid);$wpdb->update(WSM_Club_Operations::table('financial_ledger'),array('status'=>'void','ledger_status'=>'cancelled'),array('order_id'=>(int)$d['wc_order_id'],'kind'=>'pos_receivable'));
                }
                if($d['stock_reserved']){$p=self::portal16_config();foreach($p['modules']['buffet']['items'] as &$i)foreach($d['items'] as $li)if($i['id']===$li['id'])$i['stock']+=$li['consumed_units'];unset($i);if(!self::portal16_store_config($p))return self::portal16_error('stock_restore','بازگردانی موجودی تأیید نشد.',500);}
                wp_update_post(array('ID'=>$id,'post_status'=>'trash'));
            }elseif($next==='delivered'&&$d['payment_method']==='cash'){
                if($r->get_param('cash_received')!==true)return self::portal16_error('cash_confirmation','دریافت واقعی وجه نقد باید صریحاً تأیید شود.');
                $ctx=WSM_Club_Operations::membership_payment_finance_context('cash');if(is_wp_error($ctx))return $ctx;$session=WSM_Club_Operations::lock_open_cash_session((int)$ctx['cash_session_id'],(int)$ctx['cash_account_id'],(int)$ctx['device_id']);if(is_wp_error($session))return $session;
                $f=WSM_Club_Operations::add_finance('pos_sale',$total,'تحویل نقدی بوفه '.$d['order_uuid'],array('member_id'=>$a,'method'=>'cash','source'=>'buffet_cash','reference_id'=>'buffet:'.$d['order_uuid'],'account_id'=>(int)$ctx['account_id'],'cash_session_id'=>(int)$ctx['cash_session_id']));if(is_wp_error($f))return $f;$d['cash_collected']=true;
            }
            $d['status']=$next;$d['updated_at']=wp_date('c',null,new DateTimeZone('Asia/Tehran'));$d['events'][]=array('uuid'=>$uuid,'status'=>$next,'at'=>$d['updated_at']);unset($d['id']);if(!self::portal16_order_save($id,$d))return self::portal16_error('status_save','ثبت وضعیت تأیید نشد.',500);
            if($wpdb->query('COMMIT')===false)return self::portal16_error('commit','تأیید نهایی انجام نشد.',500);$committed=true;$d['id']=$id;
        }finally{if($started&&!$committed){$wpdb->query('ROLLBACK');clean_post_cache($id);wp_cache_delete('wsm_settings','options');wp_cache_delete('alloptions','options');}self::portal16_unlock($lock);}
        self::portal16_buffet_status_notice($d);return $d;
    }
    private static function portal16_buffet_status_notice($d){
        $member=WSM_Club_Operations::portal16_member_by_id((int)$d['athlete_id']);
        if(!$member||is_wp_error($member)||empty($member->sms_consent))return;
        $labels=array('preparing'=>'در حال آماده‌سازی است','ready'=>'آمادهٔ تحویل است','delivered'=>'تحویل شد','cancelled'=>'لغو شد');
        if(!isset($labels[$d['status']]))return;
        $message='سفارش بوفه شماره '.(int)$d['id'].' '.$labels[$d['status']].'.';
        return WSM_SMS::dispatch_to($message,(string)$member->phone,'athlete_portal_message');
    }
    private static function portal16_entry($mid,$uuid,$kind,$body,$callback=null){
        global $wpdb;$lock=self::portal16_lock();if(is_wp_error($lock))return $lock;$committed=false;$id=0;
        try{
            $hash=hash('sha256',wp_json_encode(array($mid,$kind,$body)));$id=self::portal16_lookup_uuid($uuid,'wsm_portal_entry');
            if($id){$d=get_post_meta($id,'_entry',true);if(!is_array($d)||$d['member_id']!==$mid||$d['kind']!==$kind||!hash_equals($d['hash'],$hash))return self::portal16_error('entry_conflict','UUID قبلاً برای درخواست دیگری استفاده شده است.',409);$d['replayed']=true;return $d;}
            $feedback_rate_key='';$feedback_times=array();
            if($kind==='feedback_slider'){$feedback_rate_key='wsm_feedback_slider_rate_'.absint($mid);$stored=get_transient($feedback_rate_key);$cutoff=time()-DAY_IN_SECONDS;foreach(is_array($stored)?$stored:array() as $stamp)if(is_numeric($stamp)&&(int)$stamp>$cutoff)$feedback_times[]=(int)$stamp;if(count($feedback_times)>=3)return self::portal16_error('feedback_rate_limited','در هر ۲۴ ساعت حداکثر ۳ نظر می‌توانید ثبت کنید.',429);}
            if($wpdb->query('START TRANSACTION')===false)return self::portal16_error('transaction','آغاز تراکنش انجام نشد.',500);$result=$callback?call_user_func($callback):array('ok'=>true);if(is_wp_error($result))return $result;
            $d=array('uuid'=>$uuid,'member_id'=>$mid,'kind'=>$kind,'data'=>$body,'result'=>$result,'hash'=>$hash,'created_at'=>wp_date('c',null,new DateTimeZone('Asia/Tehran')));
            $meta=array('order_uuid'=>$uuid,'athlete_id'=>$mid,'_entry'=>$d);$post=array('post_type'=>'wsm_portal_entry','post_status'=>'private','post_title'=>$kind.' '.$uuid,'meta_input'=>$meta);
            if($kind==='feedback_slider'){$post['post_author']=(int)$mid;$meta['_entry_type']='feedback';$meta['_entry_text']=(string)($body['text']??'');$meta['_entry_status']=in_array(($body['status']??''),array('pending','approved'),true)?$body['status']:'pending';$post['meta_input']=$meta;}
            $id=wp_insert_post($post,true);if(is_wp_error($id))return $id;
            if($kind==='feedback_slider'){$d['entry_id']=(int)$id;update_post_meta($id,'_entry',$d);$feedback_times[]=time();if(!set_transient($feedback_rate_key,$feedback_times,DAY_IN_SECONDS))return self::portal16_error('feedback_rate_storage','ذخیرهٔ محدودیت ارسال نظر در دسترس نیست.',503);}
            if($wpdb->query('COMMIT')===false)return self::portal16_error('commit','ثبت نهایی تأیید نشد.',500);$committed=true;return $d;
        }finally{if(!$committed){$wpdb->query('ROLLBACK');if($id&&!is_wp_error($id))clean_post_cache($id);}self::portal16_unlock($lock);}
    }
    public static function portal16_progress($r){$a=self::portal16_athlete($r);if(is_wp_error($a))return $a;if(self::portal16_config()['modules']['weight_bmi']['enabled']!==true)return self::portal16_error('module_disabled','ماژول وزن خاموش است.',403);$w=$r['weight'];$h=$r['height'];if(!self::portal16_number($w,10,500)||!self::portal16_number($h,50,260))return self::portal16_error('weight_height','وزن ۱۰ تا ۵۰۰ کیلو و قد ۵۰ تا ۲۶۰ سانتی‌متر لازم است.');if($r->get_param('athlete_id')!==null&&(int)$r['athlete_id']!==(int)$a->id)return self::portal16_error('owner','فقط اطلاعات خودتان مجاز است.',403);return self::portal16_entry((int)$a->id,strtolower($r['uuid']),'weight',array('weight'=>$w,'height'=>$h,'bmi'=>round($w/pow($h/100,2),2)));}
    public static function portal16_feedback($r){$a=self::portal16_athlete($r);if(is_wp_error($a))return $a;$kind=$r['kind']??'feedback';if(!in_array($kind,array('feedback','support'),true)||self::portal16_config()['modules'][$kind]['enabled']!==true)return self::portal16_error('module_disabled','ماژول ارسال پیام خاموش است.',403);$m=$r['message'];if(!is_string($m)||trim($m)===''||mb_strlen($m)>2000)return self::portal16_error('message','پیام باید ۱ تا ۲۰۰۰ نویسه باشد.');$text=trim(sanitize_textarea_field($m));$inner=new WP_REST_Request('POST');$inner->set_header('x-wsm-athlete-token',$r->get_header('x-wsm-athlete-token'));$inner->set_header('authorization',$r->get_header('authorization'));$inner->set_body(wp_json_encode(array('message'=>$text)));$inner->set_header('content-type','application/json');return self::portal16_entry((int)$a->id,strtolower($r['uuid']),$kind,array('message'=>$text),function()use($inner,$kind,$text){if($kind==='support')return WSM_Club_Operations::athlete_support_send_rest($inner);return array('ok'=>true,'message'=>$text);});}
    private static function portal16_feedback_blocked_ids(){
        $raw=get_option('wsm_blocked_feedback_users',array());if(!is_array($raw))return array();$ids=array();foreach($raw as $id){$id=absint($id);if($id)$ids[$id]=$id;}return array_values($ids);
    }
    public static function portal16_feedback_text_value($value,$request=null,$param=null){return is_string($value)&&trim($value)!==''&&mb_strlen(trim($value))<=500;}
    public static function portal16_feedback_status_value($value,$request=null,$param=null){return is_string($value)&&in_array($value,array('pending','approved','hidden','all'),true);}
    public static function portal16_feedback_limit_value($value,$request=null,$param=null){return (is_int($value)||ctype_digit((string)$value))&&(int)$value>=1&&(int)$value<=100;}
    public static function portal16_feedback_id_value($value,$request=null,$param=null){return (is_int($value)||ctype_digit((string)$value))&&(int)$value>0;}
    public static function portal16_feedback_action_value($value,$request=null,$param=null){return is_string($value)&&in_array($value,array('approve','reject','hide','restore'),true);}
    public static function portal16_feedback_reply_value($value,$request=null,$param=null){return $value===null||$value===''||(is_string($value)&&mb_strlen($value)<=500);}
    public static function portal16_feedback_bool_value($value,$request=null,$param=null){return is_bool($value);}
    public static function portal16_feedback_slider_submit($r){
        $athlete=self::portal16_athlete($r);if(is_wp_error($athlete))return $athlete;$config=self::portal16_config();$module=$config['modules']['feedback_slider']??array();
        if(($module['enabled']??false)!==true)return self::portal16_error('feedback_disabled','ثبت نظر در حال حاضر غیرفعال است.',403);
        if(in_array((int)$athlete->id,self::portal16_feedback_blocked_ids(),true))return self::portal16_error('feedback_blocked','امکان ثبت نظر برای این حساب فعال نیست.',403);
        $raw=$r->get_param('text');$max=max(1,min(500,(int)($module['max_text_length']??500)));if(!is_string($raw))return self::portal16_error('feedback_text','متن نظر باید رشته باشد.');$text=trim(sanitize_textarea_field(wp_unslash($raw)));
        if($text===''||mb_strlen($text)>$max)return self::portal16_error('feedback_length','متن نظر خالی یا بلندتر از حد مجاز است.');
        $status=!empty($module['require_approval'])?'pending':'approved';$entry=self::portal16_entry((int)$athlete->id,strtolower((string)$r->get_param('uuid')),'feedback_slider',array('text'=>$text,'status'=>$status),function()use($status){return array('ok'=>true,'status'=>$status);});
        if(is_wp_error($entry))return $entry;return array('ok'=>true,'post_id'=>(int)($entry['entry_id']??0),'status'=>$status,'replayed'=>!empty($entry['replayed']),'message'=>$status==='pending'?'نظر شما ثبت شد. پس از تایید نمایش داده می‌شود.':'نظر شما ثبت و منتشر شد.');
    }
    private static function portal16_feedback_member_name($member_id){
        global $wpdb;$row=$wpdb->get_row($wpdb->prepare('SELECT first_name,last_name FROM '.WSM_Club::table('members').' WHERE id=%d',(int)$member_id));if(!$row)return 'ورزشکار';$name=trim((string)$row->first_name.' '.(string)$row->last_name);return $name!==''?$name:'ورزشکار';
    }
    private static function portal16_feedback_format($post,$include_status=false){
        $mid=absint($post->post_author?:get_post_meta($post->ID,'athlete_id',true));$raw=(string)get_post_meta($post->ID,'_entry_text',true);$text=trim(sanitize_textarea_field($raw));$timestamp=$post->post_date_gmt&&$post->post_date_gmt!=='0000-00-00 00:00:00'?strtotime($post->post_date_gmt.' UTC'):strtotime($post->post_date);$date=wp_date('c',$timestamp?:time(),new DateTimeZone('Asia/Tehran'));
        $item=array('id'=>(int)$post->ID,'name'=>esc_html(self::portal16_feedback_member_name($mid)),'avatar_url'=>esc_url_raw((string)WSM_Club::athlete_avatar_url($mid)),'created_at'=>$date,'text'=>esc_html($text),'text_plain'=>$text);
        if($include_status){$item['member_id']=$mid;$item['status']=(string)get_post_meta($post->ID,'_entry_status',true);$item['admin_reply']=esc_html((string)get_post_meta($post->ID,'_admin_reply',true));$item['hidden_by']=(int)get_post_meta($post->ID,'_hidden_by',true);$item['hidden_at']=(string)get_post_meta($post->ID,'_hidden_at',true);}return $item;
    }
    public static function portal16_feedback_slider_list($r){
        $athlete=self::portal16_athlete($r);if(is_wp_error($athlete))return $athlete;$p=self::portal16_config();if(($p['modules']['feedback_slider']['enabled']??false)!==true)return self::portal16_error('feedback_disabled','اسلایدر نظرات غیرفعال است.',403);
        $posts=get_posts(array('post_type'=>'wsm_portal_entry','post_status'=>'private','numberposts'=>20,'orderby'=>'date','order'=>'DESC','suppress_filters'=>true,'meta_query'=>array(array('key'=>'_entry_type','value'=>'feedback'),array('key'=>'_entry_status','value'=>'approved'))));$items=array();foreach($posts as $post)$items[]=self::portal16_feedback_format($post,false);return array('items'=>$items,'count'=>count($items),'max_text_length'=>(int)$p['modules']['feedback_slider']['max_text_length']);
    }
    private static function portal16_feedback_admin_query($status,$limit){
        $meta=array(array('key'=>'_entry_type','value'=>'feedback','compare'=>'='));if($status!=='all')$meta[]=array('key'=>'_entry_status','value'=>$status,'compare'=>'=');
        return new WP_Query(array('post_type'=>'wsm_portal_entry','post_status'=>'private','posts_per_page'=>$limit,'orderby'=>'date','order'=>'DESC','suppress_filters'=>true,'meta_query'=>$meta,'no_found_rows'=>false));
    }
    public static function portal16_feedback_admin_list($r){
        $status=(string)$r->get_param('status');if(!in_array($status,array('pending','approved','hidden','all'),true))return self::portal16_error('feedback_status','وضعیت فیلتر معتبر نیست.');$limit=max(1,min(100,absint($r->get_param('per_page')?:50)));$query=self::portal16_feedback_admin_query($status,$limit);$items=array_map(function($post){return self::portal16_feedback_format($post,true);},$query->posts);$counts=array();foreach(array('pending','approved','hidden')as$key){$q=self::portal16_feedback_admin_query($key,1);$counts[$key]=(int)$q->found_posts;wp_reset_postdata();}return array('items'=>$items,'counts'=>$counts,'status'=>$status,'per_page'=>$limit,'total'=>(int)$query->found_posts);
    }
    public static function portal16_feedback_moderate($r){
        $id=absint($r->get_param('post_id'));$post=get_post($id);if(!$post||$post->post_type!=='wsm_portal_entry'||get_post_meta($id,'_entry_type',true)!=='feedback')return self::portal16_error('feedback_missing','نظر پیدا نشد.',404);$action=(string)$r->get_param('action');$reply=$r->get_param('admin_reply');
        if($reply!==null&&$reply!==''){if(!is_string($reply)||mb_strlen($reply)>500)return self::portal16_error('feedback_reply','پاسخ ادمین حداکثر ۵۰۰ نویسه است.');update_post_meta($id,'_admin_reply',sanitize_textarea_field($reply));}
        $status=array('approve'=>'approved','reject'=>'pending','hide'=>'hidden','restore'=>'approved')[$action]??'';if($status==='')return self::portal16_error('feedback_action','اقدام مدیریتی معتبر نیست.');update_post_meta($id,'_entry_status',$status);
        if($action==='hide'){update_post_meta($id,'_hidden_by',(int)(self::$portal16_actor['user_id']??get_current_user_id()));update_post_meta($id,'_hidden_at',current_time('mysql',true));}elseif(in_array($action,array('approve','reject','restore'),true)){delete_post_meta($id,'_hidden_by');delete_post_meta($id,'_hidden_at');}
        return array('ok'=>true,'post_id'=>$id,'status'=>$status,'action'=>$action);
    }
    public static function portal16_feedback_block($r){
        global $wpdb;$member_id=absint($r->get_param('member_id'));$member=$wpdb->get_var($wpdb->prepare('SELECT id FROM '.WSM_Club::table('members').' WHERE id=%d',$member_id));if(!$member)return self::portal16_error('feedback_member_missing','ورزشکار پیدا نشد.',404);$ids=self::portal16_feedback_blocked_ids();$blocked=$r->get_param('blocked')===true;if($blocked&&!in_array($member_id,$ids,true))$ids[]=$member_id;if(!$blocked)$ids=array_values(array_diff($ids,array($member_id)));$ids=array_values(array_unique(array_map('absint',$ids)));sort($ids,SORT_NUMERIC);if($ids)update_option('wsm_blocked_feedback_users',$ids,false);else delete_option('wsm_blocked_feedback_users');return array('ok'=>true,'member_id'=>$member_id,'blocked'=>$blocked,'blocked_ids'=>$ids);
    }
    public static function portal16_feedback_blocked($r){
        $ids=self::portal16_feedback_blocked_ids();$items=array();foreach($ids as$id)$items[]=array('member_id'=>$id,'name'=>esc_html(self::portal16_feedback_member_name($id)),'avatar_url'=>esc_url_raw((string)WSM_Club::athlete_avatar_url($id)));return array('items'=>$items,'count'=>count($items));
    }    public static function portal16_profile($r){
        $a=self::portal16_athlete($r);if(is_wp_error($a))return $a;
        $b=$r->get_json_params();if(!is_array($b))return self::portal16_error('profile_fields','ساختار مشخصات معتبر نیست.');
        if(array_diff(array_keys($b),array('uuid','first_name','last_name','national_id','email','avatar')))return self::portal16_error('profile_fields','فقط نام، نام خانوادگی، کد ملی، ایمیل و تصویر نمایه قابل ویرایش است.');
        foreach(array('first_name','last_name')as$k)if(!isset($b[$k])||!is_string($b[$k])||trim($b[$k])===''||mb_strlen($b[$k])>100)return self::portal16_error('profile_name','نام و نام خانوادگی معتبر لازم است.');
        if(!isset($b['national_id'])||!is_string($b['national_id'])||($b['national_id']!==''&&!preg_match('/\A[0-9]{10}\z/',$b['national_id'])))return self::portal16_error('national_id','کد ملی باید خالی یا ۱۰ رقم باشد.');
        $email=array_key_exists('email',$b)?$b['email']:(string)$a->email;if(!is_string($email)||($email!==''&&!is_email($email))||strlen($email)>190)return self::portal16_error('profile_email','نشانی ایمیل معتبر نیست.');
        $avatar_provided=array_key_exists('avatar',$b);$avatar_value=null;$avatar_hash='';
        if($avatar_provided){
            if(!is_string($b['avatar'])||strlen($b['avatar'])>360000)return self::portal16_error('profile_avatar','تصویر باید PNG، JPEG یا WebP و حداکثر ۲۵۶ کیلوبایت باشد.');
            if($b['avatar']!==''){
                if(!preg_match('/\Adata:image\/(png|jpeg|webp);base64,([A-Za-z0-9+\/=]+)\z/',$b['avatar'],$match))return self::portal16_error('profile_avatar','قالب تصویر معتبر نیست.');
                $bytes=base64_decode($match[2],true);if(!is_string($bytes)||strlen($bytes)>262144||!function_exists('getimagesizefromstring'))return self::portal16_error('profile_avatar','تصویر باید PNG، JPEG یا WebP و حداکثر ۲۵۶ کیلوبایت باشد.');
                $info=@getimagesizefromstring($bytes);$mime=is_array($info)?(string)($info['mime']??''):'';$allowed=array('image/png'=>'png','image/jpeg'=>'jpeg','image/webp'=>'webp');
                if(!$info||!isset($allowed[$mime])||(int)$info[0]<1||(int)$info[1]<1||(int)$info[0]>1024||(int)$info[1]>1024||$allowed[$mime]!==$match[1])return self::portal16_error('profile_avatar','محتوای تصویر یا ابعاد آن معتبر نیست.');
                $avatar_value='data:'.$mime.';base64,'.base64_encode($bytes);$avatar_hash=hash('sha256',$bytes);            }
        }
        $data=array('first_name'=>sanitize_text_field($b['first_name']),'last_name'=>sanitize_text_field($b['last_name']),'national_id'=>$b['national_id'],'email'=>sanitize_email($email));
        if($avatar_provided)$data['avatar_hash']=$avatar_hash;
        return self::portal16_entry((int)$a->id,strtolower($b['uuid']),'profile',$data,function()use($a,$data,$avatar_provided,$avatar_value){
            global $wpdb;$fields=array('first_name'=>$data['first_name'],'last_name'=>$data['last_name'],'email'=>$data['email'],'updated_at'=>current_time('mysql'));
            $ok=$wpdb->update(WSM_Club::table('members'),$fields,array('id'=>(int)$a->id));if($ok===false)return self::portal16_error('profile_save','ثبت مشخصات انجام نشد.',500);
            if($avatar_provided){$avatars=get_option('wsm_athlete_portal_avatars',array());$avatars=is_array($avatars)?$avatars:array();if($avatar_value===null)unset($avatars[(string)(int)$a->id]);else $avatars[(string)(int)$a->id]=$avatar_value;update_option('wsm_athlete_portal_avatars',$avatars,false);$saved=get_option('wsm_athlete_portal_avatars',array());if(($avatar_value===null&&isset($saved[(string)(int)$a->id]))||($avatar_value!==null&&($saved[(string)(int)$a->id]??null)!==$avatar_value))return self::portal16_error('profile_avatar_save','ذخیرهٔ تصویر نمایه تأیید نشد.',500);}            return array('ok'=>true);
        });
    }
    public static function portal16_attendance_raffle_admin($r){return WSM_Club_Operations::portal16_attendance_raffle_admin_data();}
    public static function portal16_attendance_raffle_draw($r){return WSM_Club_Operations::portal16_attendance_raffle_draw();}
    private static function portal16_supplement_option($member_id){return 'wsm_supplement_schedules_'.absint($member_id);}
    private static function portal16_supplement_normalize_schedules($input,$old=array()){
        if(!is_array($input)||!self::portal16_is_list($input)||count($input)>20)return self::portal16_error('supplement_schedules','حداکثر ۲۰ برنامهٔ مکمل مجاز است.');
        $old_by_id=array();foreach((array)$old as $prior)if(is_array($prior)&&!empty($prior['id']))$old_by_id[(string)$prior['id']]=$prior;
        $seen=array();$out=array();
        foreach($input as $s){
            $keys=array('id','name','mode','days','times','interval_hours','start_time','inventory_qty','inventory_threshold','dose_units','unit','enabled');
            if(!is_array($s)||array_diff(array_keys($s),$keys)||array_diff($keys,array_keys($s)))return self::portal16_error('supplement_shape','ساختار یکی از برنامه‌های مکمل معتبر نیست.');
            if(!self::portal16_uuid($s['id'])||isset($seen[$s['id']]))return self::portal16_error('supplement_id','شناسهٔ برنامه باید UUID یکتا باشد.');$seen[$s['id']]=true;
            if(!is_string($s['name'])||trim($s['name'])===''||mb_strlen($s['name'])>80)return self::portal16_error('supplement_name','نام مکمل باید ۱ تا ۸۰ نویسه باشد.');
            if(!in_array($s['mode'],array('times','interval'),true)||!is_bool($s['enabled']))return self::portal16_error('supplement_mode','نوع برنامه یا وضعیت فعال معتبر نیست.');
            if(!is_array($s['days'])||!self::portal16_is_list($s['days'])||!count($s['days'])||count($s['days'])>7)return self::portal16_error('supplement_days','روزهای هفته را انتخاب کنید.');$days=array();foreach($s['days'] as $d){if(!is_int($d)||$d<0||$d>6||isset($days[$d]))return self::portal16_error('supplement_days','روزهای هفته باید یکتا و از شنبه تا جمعه باشند.');$days[$d]=true;} $days=array_map('intval',array_keys($days));sort($days);
            $time_ok=function($v){return is_string($v)&&preg_match('/\\A(?:[01][0-9]|2[0-3]):[0-5][0-9]\\z/',$v)===1;};
            $times=array();$interval=0;$start='';
            if($s['mode']==='times'){if(!is_array($s['times'])||!self::portal16_is_list($s['times'])||!count($s['times'])||count($s['times'])>10)return self::portal16_error('supplement_times','حداکثر ۱۰ ساعت دقیق و دست‌کم یک ساعت لازم است.');foreach($s['times'] as $t){if(!$time_ok($t)||in_array($t,$times,true))return self::portal16_error('supplement_times','ساعت‌ها باید یکتا و با قالب ساعت‌:دقیقه باشند.');$times[]=$t;}sort($times);}
            else{if(!is_int($s['interval_hours'])||$s['interval_hours']<1||$s['interval_hours']>24||!$time_ok($s['start_time']))return self::portal16_error('supplement_interval','فاصله باید ۱ تا ۲۴ ساعت و ساعت شروع معتبر باشد.');$interval=$s['interval_hours'];$start=$s['start_time'];}
            if(!is_int($s['inventory_qty'])||$s['inventory_qty']<0||$s['inventory_qty']>100000||!is_int($s['inventory_threshold'])||$s['inventory_threshold']<0||$s['inventory_threshold']>100000||!is_int($s['dose_units'])||$s['dose_units']<1||$s['dose_units']>1000)return self::portal16_error('supplement_inventory','موجودی، آستانه یا مقدار هر دوز معتبر نیست.');
            if(!is_string($s['unit'])||mb_strlen($s['unit'])>30)return self::portal16_error('supplement_unit','واحد مصرف حداکثر ۳۰ نویسه است.');
            $prior=$old_by_id[$s['id']]??array();$consumed=is_array($prior['consumed_dose_keys']??null)?$prior['consumed_dose_keys']:array();
            $out[]=array('id'=>$s['id'],'name'=>sanitize_text_field($s['name']),'mode'=>$s['mode'],'days'=>$days,'times'=>$times,'interval_hours'=>$interval,'start_time'=>$start,'inventory_qty'=>$s['inventory_qty'],'inventory_threshold'=>$s['inventory_threshold'],'dose_units'=>$s['dose_units'],'unit'=>sanitize_text_field($s['unit']),'enabled'=>$s['enabled'],'consumed_dose_keys'=>array_slice($consumed,-300));
        }
        return $out;
    }
    private static function portal16_supplement_datetime($value){
        if(!is_string($value)||!preg_match('/\\A\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}\\z/',$value))return false;
        $dt=DateTimeImmutable::createFromFormat('!Y-m-d H:i',$value,new DateTimeZone('Asia/Tehran'));return $dt&&$dt->format('Y-m-d H:i')===$value?$dt:false;
    }
    private static function portal16_supplement_matches_time($schedule,$dt){
        $weekday=((int)$dt->format('w')+1)%7;if(!in_array($weekday,(array)$schedule['days'],true))return false;$time=$dt->format('H:i');
        if($schedule['mode']==='times')return in_array($time,(array)$schedule['times'],true);
        $start=explode(':',(string)$schedule['start_time']);$minute=(int)$start[0]*60+(int)$start[1];$now=(int)$dt->format('G')*60+(int)$dt->format('i');$delta=$now-$minute;return $delta>=0&&$delta<1440&&$delta%((int)$schedule['interval_hours']*60)===0;
    }
    public static function portal16_supplement_schedule_save($r){
        $a=self::portal16_athlete($r);if(is_wp_error($a))return $a;if(self::portal16_config()['modules']['supplement_reminder']['enabled']!==true)return self::portal16_error('module_disabled','یادآور مکمل خاموش است.',403);
        $b=$r->get_json_params();if(!is_array($b)||array_diff(array_keys($b),array('uuid','schedules'))||!self::portal16_uuid($b['uuid']??null))return self::portal16_error('supplement_request','درخواست ذخیرهٔ برنامه معتبر نیست.');
        $name=self::portal16_supplement_option((int)$a->id);$old=get_option($name,array());$normalized=self::portal16_supplement_normalize_schedules($b['schedules']??null,$old);if(is_wp_error($normalized))return $normalized;
        $result=self::portal16_entry((int)$a->id,strtolower($b['uuid']),'supplement_schedule',array('schedules'=>$normalized),function()use($name,$normalized){update_option($name,$normalized,false);$saved=get_option($name,array());if(!is_array($saved)||count($saved)!==count($normalized))return self::portal16_error('supplement_save','ذخیرهٔ برنامه‌ها تأیید نشد.',500);return array('saved'=>true,'count'=>count($saved));});
        if(is_wp_error($result))return $result;return array('ok'=>true,'schedules'=>$normalized,'idempotent_replay'=>!empty($result['replayed']));
    }
    private static function portal16_supplement_prior_snooze($member_id,$dose_key){
        $posts=get_posts(array('post_type'=>'wsm_portal_entry','post_status'=>'private','numberposts'=>500,'meta_key'=>'athlete_id','meta_value'=>absint($member_id),'orderby'=>'ID','order'=>'DESC','suppress_filters'=>true));$latest=null;
        foreach($posts as $post){$d=get_post_meta($post->ID,'_entry',true);if(!is_array($d)||($d['kind']??'')!=='supplement_dose'||($d['data']['dose_key']??'')!==$dose_key||($d['data']['action']??'')!=='snooze')continue;$when=self::portal16_supplement_datetime((string)($d['data']['snoozed_until']??''));if($when&&(!$latest||$when>$latest))$latest=$when;}return $latest;
    }
    public static function portal16_supplement_dose($r){
        $a=self::portal16_athlete($r);if(is_wp_error($a))return $a;if(self::portal16_config()['modules']['supplement_reminder']['enabled']!==true)return self::portal16_error('module_disabled','یادآور مکمل خاموش است.',403);
        $b=$r->get_json_params();$allowed=array('uuid','schedule_id','dose_key','action','scheduled_at','action_at');if(!is_array($b)||array_diff(array_keys($b),$allowed)||!self::portal16_uuid($b['uuid']??null)||!self::portal16_uuid($b['schedule_id']??null))return self::portal16_error('dose_request','درخواست ثبت دوز معتبر نیست.');
        if(!in_array($b['action']??'',array('taken','snooze','skipped'),true))return self::portal16_error('dose_action','عملیات دوز معتبر نیست.');$scheduled=self::portal16_supplement_datetime($b['scheduled_at']??'');$now=new DateTimeImmutable('now',new DateTimeZone('Asia/Tehran'));if(!$scheduled||$scheduled>$now->modify('+5 minutes')||$scheduled<$now->modify('-30 days'))return self::portal16_error('dose_time','زمان دوز باید در ۳۰ روز گذشته یا اکنون باشد.');
        $actionAt=isset($b['action_at'])?self::portal16_supplement_datetime($b['action_at']):$now;if(!$actionAt||$actionAt>$now->modify('+5 minutes')||$actionAt<$now->modify('-30 days'))return self::portal16_error('dose_action_time','زمان ثبت دوز معتبر نیست.');
        $doseKey=(string)($b['schedule_id'].'|'.$scheduled->format('Y-m-d H:i'));if(!is_string($b['dose_key']??null)||!hash_equals($doseKey,$b['dose_key']))return self::portal16_error('dose_key','شناسهٔ دوز با برنامه و زمان‌بندی مطابقت ندارد.');
        $option=self::portal16_supplement_option((int)$a->id);$schedules=get_option($option,array());$index=-1;foreach((array)$schedules as $i=>$s)if(is_array($s)&&hash_equals((string)($s['id']??''),(string)$b['schedule_id'])){$index=$i;break;}if($index<0||empty($schedules[$index]['enabled']))return self::portal16_error('dose_schedule','برنامهٔ مکمل فعال پیدا نشد.',404);$schedule=$schedules[$index];if(!self::portal16_supplement_matches_time($schedule,$scheduled))return self::portal16_error('dose_schedule_time','زمان ثبت‌شده جزو برنامهٔ معتبر این مکمل نیست.');
        $action=sanitize_key($b['action']);$snoozed=$action==='snooze'?$actionAt->modify('+15 minutes')->format('Y-m-d H:i'):'';$priorSnooze=self::portal16_supplement_prior_snooze((int)$a->id,$doseKey);$target=$priorSnooze?:$scheduled;$onTime=$action==='taken'&&abs($actionAt->getTimestamp()-$target->getTimestamp())<=3600;
        $data=array('schedule_id'=>$schedule['id'],'dose_key'=>$doseKey,'action'=>$action,'scheduled_at'=>$scheduled->format('Y-m-d H:i'),'action_at'=>$actionAt->format('Y-m-d H:i'),'snoozed_until'=>$snoozed,'on_time'=>$onTime);
        return self::portal16_entry((int)$a->id,strtolower($b['uuid']),'supplement_dose',$data,function()use($option,&$schedules,$index,$schedule,$doseKey,$action){if($action==='taken'&&!in_array($doseKey,(array)($schedule['consumed_dose_keys']??array()),true)){$schedules[$index]['inventory_qty']=max(0,(int)$schedule['inventory_qty']-(int)$schedule['dose_units']);$keys=(array)($schedule['consumed_dose_keys']??array());$keys[]=$doseKey;$schedules[$index]['consumed_dose_keys']=array_slice(array_values(array_unique($keys)),-300);update_option($option,$schedules,false);}return array('ok'=>true,'inventory_qty'=>(int)($schedules[$index]['inventory_qty']??$schedule['inventory_qty']));});
    }
    private static function portal16_supplement_adherence($member_id,$schedules,$entries){
        $tz=new DateTimeZone('Asia/Tehran');$now=new DateTimeImmutable('now',$tz);$from=$now->modify('-29 days')->setTime(0,0);$planned=array();
        foreach((array)$schedules as $s){if(!is_array($s)||empty($s['enabled']))continue;for($day=$from;$day<=$now;$day=$day->modify('+1 day')){$weekday=((int)$day->format('w')+1)%7;if(!in_array($weekday,(array)($s['days']??array()),true))continue;$times=array();if(($s['mode']??'')==='times')$times=(array)($s['times']??array());else{$p=explode(':',(string)($s['start_time']??'00:00'));$start=(int)($p[0]??0)*60+(int)($p[1]??0);for($m=$start;$m<1440;$m+=(int)($s['interval_hours']??24)*60)$times[]=sprintf('%02d:%02d',intdiv($m,60),$m%60);}foreach($times as $time){$dt=DateTimeImmutable::createFromFormat('!Y-m-d H:i',$day->format('Y-m-d').' '.$time,$tz);if($dt&&$dt<=$now)$planned[(string)$s['id'].'|'.$dt->format('Y-m-d H:i')]=true;}}}
        $taken=array();$recent=array();foreach((array)$entries as $entry){if(!is_array($entry)||($entry['kind']??'')!=='supplement_dose')continue;$d=$entry['data']??array();$date=self::portal16_supplement_datetime((string)($d['action_at']??''));if(!$date||$date<$from)continue;$recent[]=array('schedule_id'=>(string)($d['schedule_id']??''),'dose_key'=>(string)($d['dose_key']??''),'action'=>(string)($d['action']??''),'scheduled_at'=>(string)($d['scheduled_at']??''),'action_at'=>(string)($d['action_at']??''),'snoozed_until'=>(string)($d['snoozed_until']??''),'on_time'=>!empty($d['on_time']));if(!empty($d['on_time'])&&($d['action']??'')==='taken')$taken[(string)($d['dose_key']??'')]=true;}
        $count=0;foreach(array_keys($planned) as $key)if(isset($taken[$key]))$count++;$total=count($planned);usort($recent,function($a,$b){return strcmp($b['action_at'],$a['action_at']);});return array('percent'=>$total?round(100*$count/$total):0,'taken'=>$count,'planned'=>$total,'recent'=>array_slice($recent,0,100));
    }
    public static function portal16_state($r){
        global $wpdb;$a=self::portal16_athlete($r);if(is_wp_error($a))return $a;if($r->get_param('member_id')!==null&&absint($r->get_param('member_id'))!==(int)$a->id)return self::portal16_error('owner','فقط اطلاعات حساب احراز هویت‌شده مجاز است.',403);$p=self::portal16_config(true);$entries=get_posts(array('post_type'=>'wsm_portal_entry','post_status'=>'private','numberposts'=>500,'meta_key'=>'athlete_id','meta_value'=>(int)$a->id,'orderby'=>'ID','order'=>'DESC','suppress_filters'=>true));$weights=array();$national='';$profile_seen=false;$feedback=array();$supplement_entries=array();foreach($entries as $e){$d=get_post_meta($e->ID,'_entry',true);if(!is_array($d))continue;if($d['kind']==='weight')$weights[]=array('uuid'=>$d['uuid'],'created_at'=>$d['created_at'])+$d['data'];if($d['kind']==='profile'&&!$profile_seen){$national=$d['data']['national_id'];$profile_seen=true;}if(in_array($d['kind'],array('feedback','support'),true))$feedback[]=array('uuid'=>$d['uuid'],'created_at'=>$d['created_at'],'kind'=>$d['kind'],'message'=>$d['data']['message']);if(($d['kind']??'')==='supplement_dose')$supplement_entries[]=$d;}
        $timezone=new DateTimeZone('Asia/Tehran');$today=wp_date('Y-m-d',null,$timezone);$month_start=WSM_Club_Operations::portal16_jalali_month_start($today);$next_month_start=WSM_Club_Operations::portal16_jalali_month_start((new DateTimeImmutable($month_start,$timezone))->modify('+35 days')->format('Y-m-d'));$now_local=wp_date('Y-m-d H:i:s',null,$timezone);
        $att=$wpdb->get_results($wpdb->prepare('SELECT direction,decision,occurred_at FROM '.WSM_Club::table('attendance').' WHERE member_id=%d AND occurred_at >= %s AND decision=%s AND occurred_at<=%s ORDER BY occurred_at ASC LIMIT 1000',(int)$a->id,(new DateTimeImmutable($today,$timezone))->modify('-366 days')->format('Y-m-d').' 00:00:00','allowed',$now_local),ARRAY_A);
        $exclude_friday=!empty($p['modules']['raffle']['exclude_friday_from_attendance']);
        $leaders=array();
        if ($p['modules']['leaderboard']['enabled']) {
            $excluded_dates=array();
            if ($exclude_friday) {
                $date=new DateTimeImmutable($month_start,$timezone);
                $end=new DateTimeImmutable($next_month_start,$timezone);
                for (; $date<$end; $date=$date->modify('+1 day')) {
                    if (self::is_excluded_from_attendance($date->format('Y-m-d'),true)) { $excluded_dates[]=$date->format('Y-m-d'); }
                }
            }
            $sql='SELECT member_id,COUNT(DISTINCT DATE(occurred_at)) AS days FROM '.WSM_Club::table('attendance').' WHERE direction=%s AND decision=%s AND occurred_at>=%s AND occurred_at<%s AND occurred_at<=%s';
            $args=array('in','allowed',$month_start.' 00:00:00',$next_month_start.' 00:00:00',$now_local);
            if ($excluded_dates) { $sql.=' AND DATE(occurred_at) NOT IN ('.implode(',',array_fill(0,count($excluded_dates),'%s')).')'; $args=array_merge($args,$excluded_dates); }
            $sql.=' GROUP BY member_id ORDER BY days DESC,member_id ASC LIMIT %d';$args[]=(int)$p['modules']['leaderboard']['top_n'];
            $rows=$wpdb->get_results($wpdb->prepare($sql,$args),ARRAY_A);
            foreach ((array)$rows as $row) {
                $name=$wpdb->get_row($wpdb->prepare('SELECT first_name,last_name FROM '.WSM_Club::table('members').' WHERE id=%d',(int)$row['member_id']));
                $leaders[]=array('name'=>$name?trim($name->first_name).' '.mb_substr((string)$name->last_name,0,1).'…':'ورزشکار','days'=>(int)$row['days']);
            }
        }
        $days=array();foreach((array)$att as $row)if($row['direction']==='in')$days[substr($row['occurred_at'],0,10)]=true;
        $streak=0;$date=new DateTimeImmutable($today,$timezone);
        if (!isset($days[$today])&&!self::is_excluded_from_attendance($today,$exclude_friday)) { $date=$date->modify('-1 day'); }
        for ($checked=0;$checked<400&&$streak<366;$checked++,$date=$date->modify('-1 day')) {
            $day=$date->format('Y-m-d');
            if (self::is_excluded_from_attendance($day,$exclude_friday)) { continue; }
            if (!isset($days[$day])) { break; }
            $streak++;
        }
        $supplement_schedules=get_option(self::portal16_supplement_option((int)$a->id),array());if(!is_array($supplement_schedules))$supplement_schedules=array();$supplement_adherence=self::portal16_supplement_adherence((int)$a->id,$supplement_schedules,$supplement_entries);$attendance_raffle=WSM_Club_Operations::portal16_attendance_raffle_member_state((int)$a->id);$attendance_raffle['enabled']=!empty($p['modules']['attendance_raffle']['enabled']);
        return array('portal'=>$p,'menu_revision'=>self::portal16_menu_revision($p),'athlete_id'=>(int)$a->id,'wallet_transactions'=>self::portal16_wallet_history((int)$a->id),'wallet_balance'=>WSM_Club_Operations::recharge_card_balance((int)$a->id),'currency'=>get_woocommerce_currency(),'currency_symbol'=>wsm_currency_symbol(),'weights'=>$weights,'feedback'=>$feedback,'orders'=>self::portal16_list_orders((int)$a->id),'attendance'=>(array)$att,'leaderboard'=>$leaders,'streak'=>$streak,'national_id'=>$national,'attendance_raffle'=>$attendance_raffle,'supplement_schedules'=>$supplement_schedules,'supplement_adherence'=>$supplement_adherence,'timezone'=>'Asia/Tehran','month_start'=>$month_start,'server_time'=>wp_date('c',null,$timezone));
    }
    public static function portal16_media($r){
        require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
        if(!empty($_FILES['file'])){$f=$_FILES['file'];if(($f['size']??0)>2*1024*1024)return self::portal16_error('image_size','تصویر باید کمتر از ۲ مگابایت باشد.');$type=wp_check_filetype_and_ext($f['tmp_name'],$f['name'],array('jpg|jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp'));if(empty($type['type']))return self::portal16_error('image_type','فقط PNG، JPEG یا WebP مجاز است.');$id=media_handle_upload('file',0,array(),array('test_form'=>false,'mimes'=>array('jpg|jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp')));}
        else{$body=$r->get_json_params();if(!is_array($body)||!isset($body['name'],$body['data'])||!is_string($body['name'])||!is_string($body['data'])||strlen($body['data'])>2800000)return self::portal16_error('image','تصویر معتبر و کمتر از ۲ مگابایت لازم است.');$bytes=base64_decode($body['data'],true);$info=is_string($bytes)?@getimagesizefromstring($bytes):false;if(!$info||strlen($bytes)>2*1024*1024||!in_array($info['mime'],array('image/png','image/jpeg','image/webp'),true))return self::portal16_error('image_type','فقط محتوای واقعی PNG، JPEG یا WebP مجاز است.');$name=sanitize_file_name($body['name']);$ext=array('image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp')[$info['mime']];$name=pathinfo($name,PATHINFO_FILENAME).'.'.$ext;$up=wp_upload_bits($name,null,$bytes);if(!empty($up['error']))return self::portal16_error('upload','بارگذاری تصویر انجام نشد.',500);$id=wp_insert_attachment(array('post_mime_type'=>$info['mime'],'post_title'=>sanitize_text_field(pathinfo($name,PATHINFO_FILENAME)),'post_status'=>'inherit'),$up['file'],0,true);if(!is_wp_error($id))wp_update_attachment_metadata($id,wp_generate_attachment_metadata($id,$up['file']));}
        if(is_wp_error($id))return $id;return array('id'=>$id,'url'=>wp_get_attachment_url($id));
    }
    /* Opt-in staff alerts for NEW athlete-portal buffet orders only. No financial/SMS engine rewrite. */
    public static function portal16_buffet_sms_phone($value){
        if(!is_string($value)||strlen($value)>80)return '';
        $v=strtr(trim($value),array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9'));
        $v=preg_replace('/[\s().-]+/u','',$v);
        if(preg_match('/^(?:\+98|0098|98)(9[0-9]{9})$/D',$v,$m))$v='0'.$m[1];
        if(preg_match('/^09[0-9]{9}$/D',$v))return $v;
        return preg_match('/^\+[1-9][0-9]{7,14}$/D',$v)?$v:'';
    }
    private static function portal16_buffet_sms_plain_phone($r){
        if(!is_array($r)||!isset($r['phone'])||!is_string($r['phone']))return '';
        $phone=$r['phone'];if(strpos($phone,WSM_Crypto::VERSION)===0)$phone=WSM_Crypto::decrypt($phone);
        return is_string($phone)?self::portal16_buffet_sms_phone($phone):'';
    }
    private static function portal16_buffet_sms_validate_recipients($rows){
        if(!is_array($rows)||!self::portal16_is_list($rows)||count($rows)>20)return self::portal16_error('buffet_sms_limit','حداکثر ۲۰ شمارهٔ اطلاع‌رسانی مجاز است.');
        $ids=array();$keys=array('id','name','phone','enabled','all_day','from','to','days');
        foreach($rows as $r){
            if(!is_array($r)||array_diff(array_keys($r),$keys)||array_diff($keys,array_keys($r))||!self::portal16_uuid($r['id'])||isset($ids[strtolower($r['id'])]))return self::portal16_error('buffet_sms_recipient','شناسه یا ساختار دریافت‌کنندهٔ پیامک معتبر نیست.');
            $ids[strtolower($r['id'])]=true;
            if(!is_string($r['name'])||mb_strlen($r['name'])>80||self::portal16_buffet_sms_phone($r['phone'])==='')return self::portal16_error('buffet_sms_phone','نام حداکثر ۸۰ نویسه و شمارهٔ موبایل معتبر لازم است.');
            if(!is_bool($r['enabled'])||!is_bool($r['all_day']))return self::portal16_error('buffet_sms_boolean','فعال‌بودن و تمام‌روز باید boolean باشند.');
            foreach(array('from','to')as$k)if(!is_string($r[$k])||!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D',$r[$k]))return self::portal16_error('buffet_sms_hours','ساعت را با قالب ۲۴ساعته HH:MM وارد کنید.');
            if(!$r['all_day']&&$r['from']===$r['to'])return self::portal16_error('buffet_sms_window','شروع و پایان نباید یکسان باشند؛ برای ۲۴ ساعت، «تمام‌روز» را انتخاب کنید.');
            if(!is_array($r['days'])||!self::portal16_is_list($r['days'])||!count($r['days'])||count($r['days'])>7||count(array_unique($r['days']))!==count($r['days']))return self::portal16_error('buffet_sms_days','حداقل یک روز هفته انتخاب کنید.');
            foreach($r['days']as$day)if(!is_int($day)||$day<0||$day>6)return self::portal16_error('buffet_sms_days','روز هفته معتبر نیست.');
        }
        return true;
    }
    public static function portal16_buffet_sms_in_shift($r,$timestamp){
        if(!is_array($r)||($r['enabled']??null)!==true||!isset($r['days'])||!is_array($r['days'])||!is_numeric($timestamp))return false;
        $tz=new DateTimeZone('Asia/Tehran');$day=((int)wp_date('w',(int)$timestamp,$tz)+1)%7;
        if(($r['all_day']??null)===true)return in_array($day,$r['days'],true);
        $from=$r['from']??'';$to=$r['to']??'';if(!is_string($from)||!is_string($to)||!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D',$from)||!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D',$to)||$from===$to)return false;
        $minute=(int)wp_date('H',(int)$timestamp,$tz)*60+(int)wp_date('i',(int)$timestamp,$tz);$a=(int)substr($from,0,2)*60+(int)substr($from,3,2);$b=(int)substr($to,0,2)*60+(int)substr($to,3,2);
        if($a<$b)return in_array($day,$r['days'],true)&&$minute>=$a&&$minute<$b;
        // An overnight shift belongs to its START day (Saturday22 -> Sunday06).
        return ($minute>=$a&&in_array($day,$r['days'],true))||($minute<$b&&in_array(($day+6)%7,$r['days'],true));
    }
    private static function portal16_buffet_sms_admin_view($p){
        foreach($p['modules']['buffet']['staff_sms_recipients']as&$r)$r['phone']=self::portal16_buffet_sms_plain_phone($r);unset($r);return $p;
    }
    private static function portal16_buffet_sms_storage($p,$old){
        $previous=array_column($old['modules']['buffet']['staff_sms_recipients']??array(),null,'id');
        foreach($p['modules']['buffet']['staff_sms_recipients']as&$r){
            $r['id']=strtolower($r['id']);$r['name']=sanitize_text_field($r['name']);$phone=self::portal16_buffet_sms_phone($r['phone']);
            $prior=$previous[$r['id']]??null;
            if($prior&&self::portal16_buffet_sms_plain_phone($prior)===$phone&&strpos((string)$prior['phone'],WSM_Crypto::VERSION)===0)$r['phone']=$prior['phone'];
            else{$cipher=WSM_Crypto::encrypt($phone);if(!$cipher)return self::portal16_error('buffet_sms_crypto','رمزنگاری شماره‌ها در دسترس نیست؛ شماره ذخیره نشد.',500);$r['phone']=$cipher;}
            sort($r['days'],SORT_NUMERIC);
        }unset($r);return $p;
    }
    private static function portal16_buffet_sms_service(){
        return array('configured'=>class_exists('WSM_SMS')&&WSM_SMS::is_configured(),'active'=>class_exists('WSM_SMS')&&WSM_SMS::is_active(),'queue'=>function_exists('as_enqueue_async_action')?'action_scheduler':'wp_cron','timezone'=>'Asia/Tehran','server_time'=>wp_date('Y-m-d H:i',null,new DateTimeZone('Asia/Tehran')));
    }
    private static function portal16_buffet_sms_target_key($hash){return '_wsm_bf_staff_sms_target_'.$hash;}
    private static function portal16_buffet_sms_schedule($hook,$args){
        try{if(function_exists('as_enqueue_async_action'))return (int)as_enqueue_async_action($hook,$args,'wsm-buffet-staff-sms',true);
        if(!wp_next_scheduled($hook,$args))return wp_schedule_single_event(time(),$hook,$args)!==false?1:0;
        return 1;}catch(Throwable$e){return 0;}
    }
    public static function portal16_buffet_staff_sms_enqueue($order_id,$uuid=''){
        $id=absint($order_id);if(!$id||get_post_type($id)!=='wsm_buffet_order'||get_post_meta($id,'_wsm_buffet_origin',true)!=='athlete_portal')return;
        $d=self::portal16_order_data($id);if(!$d||!self::portal16_uuid($d['order_uuid']??'')||($uuid!==''&&!hash_equals((string)$d['order_uuid'],(string)$uuid)))return;
        $lock='wsm_bf_sms_plan_lock_'.$id;$token=wp_generate_uuid4();$value=array('token'=>$token,'expires'=>time()+120);
        if(!add_option($lock,$value,'',false)){
            $old=get_option($lock);if(is_array($old)&&(int)($old['expires']??0)<time()){
                global$wpdb;$deleted=$wpdb->query($wpdb->prepare('DELETE FROM '.$wpdb->options.' WHERE option_name=%s AND BINARY option_value=BINARY %s',$lock,maybe_serialize($old)));wp_cache_delete($lock,'options');wp_cache_delete('notoptions','options');
                if($deleted!==1||!add_option($lock,$value,'',false))return;
            }else return;
        }
        try{
            wp_cache_delete($id,'post_meta');if(get_post_meta($id,'_wsm_bf_staff_sms_plan',true))return;
            $b=self::portal16_config()['modules']['buffet'];$at=strtotime((string)$d['created_at']);$plan=array('order_uuid'=>$d['order_uuid'],'created_epoch'=>$at?:0,'planned_at'=>time(),'enabled'=>($b['staff_sms_enabled']??false)===true,'timezone'=>'Asia/Tehran','targets'=>array());
            if(!$plan['enabled']||!$at||$d['status']!=='pending'){update_post_meta($id,'_wsm_bf_staff_sms_plan',$plan);return;}
            $targets=array();
            foreach((array)($b['staff_sms_recipients']??array())as$r){
                if(!self::portal16_buffet_sms_in_shift($r,$at))continue;$phone=self::portal16_buffet_sms_plain_phone($r);if($phone==='')continue;
                $hash=hash_hmac('sha256',$phone,wp_salt('auth'));
                if(isset($targets[$hash])){$targets[$hash]['recipient_ids'][]=$r['id'];continue;}
                $cipher=strpos((string)$r['phone'],WSM_Crypto::VERSION)===0?$r['phone']:WSM_Crypto::encrypt($phone);if(!$cipher)continue;
                $targets[$hash]=array('recipient_ids'=>array($r['id']),'phone_cipher'=>$cipher,'status'=>'pending','queued_at'=>time(),'attempts'=>0);
            }
            foreach($targets as$hash=>$target)update_post_meta($id,self::portal16_buffet_sms_target_key($hash),$target);
            $plan['targets']=array_keys($targets);update_post_meta($id,'_wsm_bf_staff_sms_plan',$plan);
            foreach($targets as$hash=>$target){
                if(!self::portal16_buffet_sms_schedule('wsm_portal_buffet_staff_sms_send',array($id,$hash))){$target['status']='queue_failed';update_post_meta($id,self::portal16_buffet_sms_target_key($hash),$target);}
            }
        }catch(Throwable$e){update_post_meta($id,'_wsm_bf_staff_sms_plan',array('order_uuid'=>$d['order_uuid'],'status'=>'planning_failed','planned_at'=>time(),'targets'=>array()));}finally{if(get_option($lock)===$value)delete_option($lock);}
    }
    private static function portal16_buffet_sms_text($id,$d,$at){
        $names=array();foreach(array_slice($d['items'],0,3)as$i){$unit=$i['unit_type']==='piece'?'عدد':($i['unit_type']==='weight_kilo'?'کیلو':'گرم');$names[]=mb_substr(wp_strip_all_tags((string)$i['name']),0,28).' × '.$i['quantity'].' '.$unit;}
        if(count($d['items'])>3)$names[]='…';
        $name=mb_substr(wp_strip_all_tags((string)$d['athlete_name']),0,35);$time=wp_date('H:i',(int)$at,new DateTimeZone('Asia/Tehran'));
        return mb_substr('سفارش غذای جدید #'.$id."\n".$name."\n".implode('، ',$names)."\n".'جمع: '.$d['total_price'].' '.wp_strip_all_tags((string)$d['currency_symbol']).' · '.$time.' تهران',0,230);
    }
    public static function portal16_buffet_staff_sms_send($order_id,$hash){
        $id=absint($order_id);if(!$id||!is_string($hash)||!preg_match('/^[a-f0-9]{64}$/D',$hash)||get_post_type($id)!=='wsm_buffet_order'||get_post_meta($id,'_wsm_buffet_origin',true)!=='athlete_portal')return;
        wp_cache_delete($id,'post_meta');$plan=get_post_meta($id,'_wsm_bf_staff_sms_plan',true);$key=self::portal16_buffet_sms_target_key($hash);$target=get_post_meta($id,$key,true);$d=self::portal16_order_data($id);
        if(!is_array($plan)||!is_array($target)||$target['status']!=='pending'||!$d||!hash_equals((string)$plan['order_uuid'],(string)$d['order_uuid']))return;
        $b=self::portal16_config()['modules']['buffet'];$phone=WSM_Crypto::decrypt((string)$target['phone_cipher']);$phone=is_string($phone)?self::portal16_buffet_sms_phone($phone):'';
        $valid=false;
        foreach((array)($b['staff_sms_recipients']??array())as$r)if(in_array($r['id']??'',(array)$target['recipient_ids'],true)&&self::portal16_buffet_sms_plain_phone($r)===$phone&&self::portal16_buffet_sms_in_shift($r,(int)$plan['created_epoch'])){$valid=true;break;}
        if(($b['staff_sms_enabled']??false)!==true||$d['status']!=='pending'||!$valid||$phone===''||!hash_equals($hash,hash_hmac('sha256',$phone,wp_salt('auth')))){$target['status']='skipped_changed_or_cancelled';update_post_meta($id,$key,$target);return;}
        if(!WSM_SMS::is_active()){$target['status']='blocked_sms_service';update_post_meta($id,$key,$target);return;}
        // A persistent, autoload=false UUID+destination claim is atomic across order/job replays.
        // Ambiguous provider timeouts are deliberately NOT retried to avoid duplicate employee SMS.
        $claim='wsm_bf_sms_once_'.hash('sha256',$d['order_uuid'].'|'.$hash);
        if(!add_option($claim,array('order_id'=>$id,'at'=>time(),'status'=>'claimed'),'',false)){wp_cache_delete($id,'post_meta');$fresh=get_post_meta($id,$key,true);if(is_array($fresh)&&($fresh['status']??'')==='pending'){$fresh['status']='duplicate_suppressed';update_post_meta($id,$key,$fresh);}return;}
        $target['status']='claimed';$target['attempts']=(int)$target['attempts']+1;$target['attempted_at']=time();update_post_meta($id,$key,$target);
        try{$sent=WSM_SMS::dispatch_to(self::portal16_buffet_sms_text($id,$d,(int)$plan['created_epoch']),$phone,'generic');$accepted=is_array($sent)&&!empty($sent['ok']);$target['status']=$accepted?'sent':((is_array($sent)&&($sent['provider_acceptance']??'')==='unknown')?'unknown':'failed');$target['provider_acceptance']=is_array($sent)?($sent['provider_acceptance']??'not_sent'):'not_sent';}
        catch(Throwable$e){$target['status']='unknown';$target['provider_acceptance']='unknown';}
        $target['finished_at']=time();update_post_meta($id,$key,$target);update_option($claim,array('order_id'=>$id,'at'=>$target['attempted_at'],'status'=>$target['status']),false);
        if(class_exists('WSM_Activity_Log'))WSM_Activity_Log::log('notify','buffet_staff_sms',$id,'اطلاع‌رسانی کارکنان بوفه',array(),array('status'=>$target['status'],'recipient_hash'=>$hash),$target['status']==='sent'?'success':'failed');
    }

    private static function portal16_wallet_history($mid){$rows=wc_get_orders(array('type'=>array('wallet_topup','shop_order'),'limit'=>100,'status'=>array_keys(wc_get_order_statuses()),'meta_key'=>'_wsm_wallet_member_id','meta_value'=>$mid,'orderby'=>'ID','order'=>'DESC'));$out=array();foreach($rows as $o){if((int)$o->get_meta('_wsm_wallet_member_id')!==$mid||!$o->get_meta('_wsm_wallet_uuid'))continue;$date=$o->get_date_created();$out[]=array('order_id'=>$o->get_id(),'uuid'=>$o->get_meta('_wsm_wallet_uuid'),'amount'=>$o->get_meta('_wsm_wallet_amount'),'currency'=>$o->get_currency(),'status'=>$o->get_status(),'credited'=>(bool)$o->get_meta('_wsm_wallet_credited'),'created_at'=>$date?$date->format('c'):null);}return $out;}
    /* Wallet top-up: the configured Woo gateway owns payment and verification. */
    private static function portal16_wallet_lock_wait(){
        $until=microtime(true)+3.0;
        do{
            wp_cache_delete('wsm_portal16_mutation_lock','options');
            wp_cache_delete('notoptions','options');
            $lock=self::portal16_lock();if(!is_wp_error($lock))return $lock;
            if(microtime(true)>=$until)return $lock;
            usleep(50000);
        }while(true);
    }
    private static function portal16_wallet_find_uuid($uuid){
        $found=array();
        foreach(array('_wsm_wallet_uuid','_wsm_wallet_topup_uuid') as $key){
            $rows=wc_get_orders(array('type'=>array('wallet_topup','shop_order'),'limit'=>2,'meta_key'=>$key,'meta_value'=>$uuid,'return'=>'objects','status'=>array_merge(array_keys(wc_get_order_statuses()),array('trash')),'orderby'=>'ID','order'=>'ASC'));
            if(is_wp_error($rows))return $rows;
            foreach((array)$rows as $o)$found[(int)$o->get_id()]=$o;
        }
        if(count($found)>1)return self::portal16_error('wallet_uuid_ambiguous','UUID شارژ به بیش از یک سفارش وصل است؛ بررسی دستی لازم است.',409);
        return $found?reset($found):null;
    }
    private static function portal16_wallet_payment_url($order){
        $url=(string)$order->get_checkout_payment_url(false);$p=wp_parse_url($url);$h=wp_parse_url(home_url('/'));
        $ps=is_array($p)?strtolower((string)($p['scheme']??'')):'';$hs=is_array($h)?strtolower((string)($h['scheme']??'')):'';
        $pp=is_array($p)?(int)($p['port']??($ps==='https'?443:80)):0;$hp=is_array($h)?(int)($h['port']??($hs==='https'?443:80)):0;
        if(!is_array($p)||!is_array($h)||!in_array($ps,array('https','http'),true)||($hs==='https'&&$ps!=='https')||empty($p['host'])||strtolower($p['host'])!==strtolower($h['host']??'')||$pp!==$hp||!empty($p['user'])||!empty($p['pass']))return self::portal16_error('wallet_payment_url','نشانی پرداخت امن ووکامرس ساخته نشد.',500);
        return $url;
    }
    private static function portal16_wallet_response($order,$uuid,$replayed){
        $url=self::portal16_wallet_payment_url($order);if(is_wp_error($url))return $url;
        return array('order_id'=>(int)$order->get_id(),'payment_url'=>$url,'uuid'=>$uuid,'replayed'=>(bool)$replayed,'paid'=>(bool)$order->is_paid(),'credited'=>(bool)$order->get_meta('_wsm_wallet_credited'),'status'=>(string)$order->get_status(),'order_type'=>(string)$order->get_type());
    }
    public static function portal16_wallet_checkout($r){
        global $wpdb;
        $a=self::portal16_athlete($r);if(is_wp_error($a))return $a;
        $body=$r->get_json_params();
        if(!is_array($body)||array_diff(array_keys($body),array('uuid','amount','gateway_id','currency')))return self::portal16_error('wallet_fields','فقط مبلغ، ارز، درگاه و UUID شارژ پذیرفته می‌شود.');
        $p=self::portal16_config();if($p['modules']['wallet']['enabled']!==true)return self::portal16_error('module_disabled','کیف پول غیرفعال است.',403);
        $amount=$r['amount'];if(!self::portal16_number($amount,0.000001,$p['modules']['wallet']['max_charge'])||!self::portal16_precision($amount))return self::portal16_error('wallet_amount','مبلغ باید مثبت، در سقف مجاز و سازگار با دقت پول فروشگاه باشد.');
        if(!self::portal16_uuid($r['uuid']))return self::portal16_error('wallet_uuid','شناسهٔ یکتای شارژ معتبر نیست.');
        $currency=$r['currency'];if(!is_string($currency)||$currency!==get_woocommerce_currency())return self::portal16_error('currency_changed','واحد پول تغییر کرده است.',409);
        $gid=$r['gateway_id'];if(!is_string($gid)||sanitize_key($gid)!==$gid)return self::portal16_error('gateway','شناسهٔ درگاه معتبر نیست.');
        $canonical=(string)wc_format_decimal($amount,min(6,max(0,(int)wc_get_price_decimals())));$uuid=strtolower($r['uuid']);
        $hash=hash('sha256',wp_json_encode(array((int)$a->id,$canonical,$gid,$currency)));
        $legacy_hash=hash('sha256',wp_json_encode(array((int)$a->id,$amount,$gid,$currency)));
        $lock=self::portal16_wallet_lock_wait();if(is_wp_error($lock))return $lock;$in_tx=false;$order=null;
        try{
            $existing=self::portal16_wallet_find_uuid($uuid);if(is_wp_error($existing))return $existing;
            if($existing){
                $existing->read_meta_data(true);$stored=(string)$existing->get_meta('_wsm_wallet_hash');
                $match=$stored!==''&&(hash_equals($stored,$hash)||hash_equals($stored,$legacy_hash));
                if((int)$existing->get_meta('_wsm_wallet_member_id')!==(int)$a->id||!$match||$existing->get_payment_method()!==$gid||$existing->get_currency()!==$currency||(string)wc_format_decimal($existing->get_meta('_wsm_wallet_amount'),wc_get_price_decimals())!==$canonical)return self::portal16_error('wallet_uuid_conflict','UUID شارژ قبلاً برای درخواست دیگری استفاده شده است.',409);
                return self::portal16_wallet_response($existing,$uuid,true);
            }
            if(!class_exists('WSM_Wallet_Topup_Order')||!wc_get_order_type('wallet_topup'))return self::portal16_error('wallet_type','نوع مستقل شارژ ثبت نشده است.',503);
            $gateways=WC()->payment_gateways()->payment_gateways();$gateway=$gateways[$gid]??null;
            $offline=array('bacs','cheque','check','cod','cash','cashondelivery','banktransfer','manual','offline','pos','wsm_pos_cash','wsm_pos_card','wsm_pos_transfer','wsm_store_account','athlete_portal_zarinpal');
            $normalized=strtolower(preg_replace('/[^a-z0-9]+/i','',$gid));
            if(!$gateway||$gateway->enabled!=='yes'||in_array($gid,$offline,true)||in_array($normalized,$offline,true)||preg_match('/(^|_)(cash|cod|cheque|check|bacs|manual|offline|pos)(_|$)/',$gid))return self::portal16_error('gateway','درگاه آنلاین انتخابی فعال نیست.',409);
            if($wpdb->query('START TRANSACTION')===false)return self::portal16_error('wallet_transaction','آغاز ثبت سفارش شارژ انجام نشد.',503);$in_tx=true;
            $order=WSM_SMS::with_new_order_sms_suppressed(function()use($a,$canonical,$currency,$gateway,$gid,$uuid,$hash){
                $o=new WSM_Wallet_Topup_Order();$o->set_status('pending');$o->set_customer_id(0);$o->set_created_via('wp-store-manager');
                $o->set_currency($currency);$o->set_billing_first_name($a->first_name);$o->set_billing_last_name($a->last_name);$o->set_billing_phone($a->phone);$o->set_payment_method($gateway);
                $name=trim((string)$a->first_name.' '.(string)$a->last_name);$fee=new WC_Order_Item_Fee();$fee->set_name($name.' · شارژ کیف پول باشگاه');$fee->set_amount($canonical);$fee->set_total($canonical);$fee->set_tax_status('none');$o->add_item($fee);
                foreach(array('_wsm_wallet_uuid'=>$uuid,'_wsm_wallet_topup_uuid'=>$uuid,'_wsm_wallet_hash'=>$hash,'_wsm_wallet_adapter_version'=>2,'_wsm_wallet_member_id'=>(int)$a->id,'_wsm_athlete_portal_member_id'=>(int)$a->id,'_wsm_wallet_amount'=>$canonical,'_wsm_wallet_currency'=>$currency,'_wsm_wallet_gateway_id'=>$gid) as $key=>$value)$o->update_meta_data($key,$value);
                // No membership-intent marker and no manual-sale marker: this is not a plan or a POS sale.
                $o->set_total($canonical);$id=$o->save();if(!$id)throw new RuntimeException('wallet_order_save');return $o;
            });
            $reply=self::portal16_wallet_response($order,$uuid,false);if(is_wp_error($reply))return $reply;
            if($wpdb->query('COMMIT')===false)return self::portal16_error('wallet_commit','پایان ثبت سفارش انجام نشد؛ همان UUID را دوباره بفرستید.',503);$in_tx=false;
            return $reply;
        }catch(Throwable $e){return self::portal16_error('wallet_checkout_failed','ساخت سفارش شارژ انجام نشد؛ همان UUID را دوباره بفرستید.',500);}
        finally{if($in_tx)$wpdb->query('ROLLBACK');self::portal16_unlock($lock);}
    }
    public static function portal16_wallet_paid($order_id,$ignored=null){
        global $wpdb;
        $o=wc_get_order((int)$order_id);if(!$o)return;$o->read_meta_data(true);
        // The historical credited order (including order13) is never written or re-credited.
        if($o->get_meta('_wsm_wallet_credited'))return;
        $uuid=(string)$o->get_meta('_wsm_wallet_uuid');if(!self::portal16_uuid($uuid)||!$o->is_paid())return;
        $lock=self::portal16_wallet_lock_wait();
        if(is_wp_error($lock)){if(!wp_next_scheduled('wsm_portal16_wallet_retry',array((int)$order_id)))wp_schedule_single_event(time()+30,'wsm_portal16_wallet_retry',array((int)$order_id));return;}
        $in_tx=false;$success=false;$error=null;
        try{
            $o=wc_get_order((int)$order_id);$o->read_meta_data(true);if($o->get_meta('_wsm_wallet_credited')||!$o->is_paid())return;
            $mid=(int)$o->get_meta('_wsm_wallet_member_id');$uuid=(string)$o->get_meta('_wsm_wallet_uuid');$amount=(string)$o->get_meta('_wsm_wallet_amount');$table=WSM_Club_Operations::table('financial_ledger');$ref='wallet:'.$uuid;
            // No source predicate: legacy source names must not defeat UUID idempotency.
            $done=$wpdb->get_row($wpdb->prepare('SELECT id,member_id,order_id,amount,transaction_type FROM '.$table.' WHERE reference_id=%s AND status=%s ORDER BY id ASC LIMIT 1',$ref,'posted'),ARRAY_A);
            if($done){
                if((int)$done['member_id']!==$mid||abs((float)$done['amount']-(float)$amount)>0.000001||$done['transaction_type']!=='liability')throw new RuntimeException('wallet_reference_conflict');
                if($o->get_type()==='wallet_topup'&&(int)$done['order_id']===(int)$o->get_id()){$o->update_meta_data('_wsm_wallet_credited',(int)$done['id']);$o->save_meta_data();$success=true;}
            }else{
                if($o->get_type()!=='wallet_topup')throw new RuntimeException('wallet_legacy_uncredited_review');
                $currency=(string)$o->get_meta('_wsm_wallet_currency');$gid=(string)$o->get_meta('_wsm_wallet_gateway_id');
                $expected_hash=hash('sha256',wp_json_encode(array($mid,$amount,$gid,$currency)));
                if(!self::portal16_uuid($uuid)||$mid<1||!is_numeric($amount)||!is_finite((float)$amount)||(float)$amount<=0||!self::portal16_precision((float)$amount)||abs((float)$o->get_total()-(float)$amount)>0.000001||$currency!==$o->get_currency()||$currency!==get_woocommerce_currency()||$gid===''||$gid!==$o->get_payment_method()||!hash_equals((string)$o->get_meta('_wsm_wallet_hash'),$expected_hash))throw new RuntimeException('wallet_paid_integrity');
                $account=$wpdb->get_row('SELECT id,account_key,account_type,is_active FROM '.WSM_Club_Operations::table('financial_accounts').' WHERE id=5',ARRAY_A);
                if(!$account||(int)$account['is_active']!==1||$account['account_key']!=='club_credit_liability'||$account['account_type']!=='virtual')throw new RuntimeException('wallet_account5_unavailable');
                if($wpdb->query('START TRANSACTION')===false)throw new RuntimeException('wallet_transaction_start');$in_tx=true;
                $member=$wpdb->get_row($wpdb->prepare('SELECT id,first_name,last_name,status,card_balance FROM '.WSM_Club::table('members').' WHERE id=%d FOR UPDATE',$mid));
                if(!$member||$member->status!=='active')throw new RuntimeException('wallet_member_inactive');
                $title=trim((string)$member->first_name.' '.(string)$member->last_name).' · شارژ کیف پول '.$uuid;
                $f=WSM_Club_Operations::add_finance('wallet_topup',$amount,$title,array('member_id'=>$mid,'order_id'=>(int)$o->get_id(),'method'=>'online','source'=>'portal_wallet_topup','reference_id'=>$ref,'account_id'=>5,'account_delta'=>$amount,'transaction_type'=>'liability','description'=>'شارژ تأییدشده توسط درگاه بومی ووکامرس'));
                if(is_wp_error($f)||!(int)$f)throw new RuntimeException('wallet_ledger_failed');
                $posted=$wpdb->get_row($wpdb->prepare('SELECT kind,transaction_type,source,status,account_id,order_id FROM '.$table.' WHERE id=%d',(int)$f),ARRAY_A);
                if(!$posted||$posted['kind']!=='wallet_topup'||$posted['transaction_type']!=='liability'||$posted['source']!=='portal_wallet_topup'||$posted['status']!=='posted'||(int)$posted['account_id']!==5||(int)$posted['order_id']!==(int)$o->get_id())throw new RuntimeException('wallet_ledger_integrity');
                // Ledger first. Both the liability and the balance update commit atomically.
                $updated=$wpdb->query($wpdb->prepare('UPDATE '.WSM_Club::table('members').' SET card_balance=card_balance+CAST(%s AS DECIMAL(20,6)),updated_at=%s WHERE id=%d AND status=%s',$amount,current_time('mysql'),$mid,'active'));
                if($updated!==1)throw new RuntimeException('wallet_balance_failed');
                $o->update_meta_data('_wsm_wallet_credited',(int)$f);$o->update_meta_data('_wsm_wallet_credited_at',wp_date('c',null,new DateTimeZone('Asia/Tehran')));$o->save_meta_data();
                $o->read_meta_data(true);if((int)$o->get_meta('_wsm_wallet_credited')!==(int)$f)throw new RuntimeException('wallet_credit_marker_failed');
                if($wpdb->query('COMMIT')===false)throw new RuntimeException('wallet_transaction_commit');$in_tx=false;$success=true;
            }
        }catch(Throwable $e){$error=sanitize_key($e->getMessage());}
        finally{if($in_tx){$wpdb->query('ROLLBACK');if($o)$o->read_meta_data(true);}self::portal16_unlock($lock);}
        if($error){
            $o=wc_get_order((int)$order_id);$o->read_meta_data(true);$o->update_meta_data('_wsm_wallet_reconcile_error',$error);$tries=(int)$o->get_meta('_wsm_wallet_retry_count');$o->update_meta_data('_wsm_wallet_retry_count',$tries+1);$o->save_meta_data();
            if($tries<5&&!wp_next_scheduled('wsm_portal16_wallet_retry',array((int)$order_id)))wp_schedule_single_event(time()+60,'wsm_portal16_wallet_retry',array((int)$order_id));
            self::portal16_wallet_notice((int)$order_id,'error');return;
        }
        if($success)self::portal16_wallet_notice((int)$order_id,'success');
    }
    public static function portal16_wallet_failed($order_id,$ignored=null){
        $o=wc_get_order((int)$order_id);if(!$o)return;$o->read_meta_data(true);
        if($o->get_type()!=='wallet_topup'||!self::portal16_uuid((string)$o->get_meta('_wsm_wallet_uuid'))||$o->get_meta('_wsm_wallet_credited')||$o->get_status()!=='failed')return;
        self::portal16_wallet_notice((int)$order_id,'failed');
    }
    public static function portal16_wallet_notice($order_id,$kind='success'){
        global $wpdb;
        if(!in_array($kind,array('success','failed','error'),true))return;
        $lock=self::portal16_wallet_lock_wait();
        if(is_wp_error($lock)){if(!wp_next_scheduled('wsm_portal16_wallet_notice_retry',array((int)$order_id,$kind)))wp_schedule_single_event(time()+30,'wsm_portal16_wallet_notice_retry',array((int)$order_id,$kind));return;}
        $order=null;$member=null;$claimed=false;
        try{
            $order=wc_get_order((int)$order_id);if(!$order)return;$order->read_meta_data(true);
            if($order->get_type()!=='wallet_topup'||!self::portal16_uuid((string)$order->get_meta('_wsm_wallet_uuid')))return;
            $key='_wsm_wallet_notice_'.$kind.'_claimed';if($order->get_meta($key))return;
            $credited=(bool)$order->get_meta('_wsm_wallet_credited');
            if($kind==='success'&&!$credited)return;
            if($kind==='failed'){
                if($credited||$order->get_status()!=='failed')return;
                $exists=$wpdb->get_var($wpdb->prepare('SELECT id FROM '.WSM_Club_Operations::table('financial_ledger').' WHERE reference_id=%s AND status=%s LIMIT 1','wallet:'.$order->get_meta('_wsm_wallet_uuid'),'posted'));
                if($exists)return;
            }
            $member=WSM_Club_Operations::portal16_member_by_id((int)$order->get_meta('_wsm_wallet_member_id'));if(!$member||is_wp_error($member))return;
            $order->update_meta_data($key,time());$order->save_meta_data();$claimed=true;
        }finally{self::portal16_unlock($lock);}
        if(!$claimed)return;
        $amount=(string)$order->get_meta('_wsm_wallet_amount');$currency=function_exists('wsm_currency_symbol')?wsm_currency_symbol():$order->get_currency();$customer_ok=false;$admin_ok=null;
        if($kind==='success'){
            $sent=WSM_Club_Operations::portal16_customer_sms((int)$member->id,'wallet_topup',$amount);$customer_ok=is_array($sent)&&!empty($sent['ok']);
            // No manager SMS on success; existing notify_new_order also skips the member-id marker.
        }else{
            if(!empty($member->sms_consent)){
                $message=$kind==='failed'?'پرداخت شارژ کیف پول به مبلغ '.$amount.' '.$currency.' ناموفق بود؛ موجودی شما تغییر نکرد.':'پرداخت تأیید شد اما ثبت شارژ کیف پول نیازمند بررسی باشگاه است؛ سفارش '.(int)$order_id;
                $sent=WSM_SMS::dispatch_to($message,(string)$member->phone,'athlete_portal_message');$customer_ok=is_array($sent)&&!empty($sent['ok']);
            }
            $admin_ok=WSM_Security::notify_sms('خطای مالی شارژ کیف پول؛ سفارش '.(int)$order_id.'؛ ورزشکار '.trim((string)$member->first_name.' '.(string)$member->last_name).'؛ وضعیت '.($kind==='failed'?'پرداخت ناموفق':'نیازمند تطبیق دفتر مالی').'.');
        }
        $order->update_meta_data('_wsm_wallet_notice_'.$kind.'_customer_ok',$customer_ok?1:0);
        if($admin_ok!==null)$order->update_meta_data('_wsm_wallet_notice_'.$kind.'_admin_ok',$admin_ok?1:0);
        $order->save_meta_data();
    }
    public static function portal16_wallet_return($url,$order){if(is_object($order)&&$order->get_meta('_wsm_wallet_uuid'))return add_query_arg('wallet_return','1',home_url('/athlete-portal/'));return $url;}

    public static function portal16_asset_response($kind){
        $p=self::portal16_config(true);$base=home_url('/athlete-portal/');nocache_headers();header('X-Content-Type-Options: nosniff');
        if($kind==='manifest'){
            header('Content-Type: application/manifest+json; charset=UTF-8');$pwa=$p['pwa'];$icons=array();foreach(array(192,512)as$size)$icons[]=array('src'=>$pwa['icon_'.$size.'_url']?:WSM_URL.'wsm-app/icon-'.$size.'.png','sizes'=>$size.'x'.$size,'type'=>'image/png','purpose'=>'any');
            echo wp_json_encode(array('id'=>$base,'name'=>$pwa['app_name'],'short_name'=>$pwa['app_short_name'],'start_url'=>$base,'scope'=>$base,'lang'=>'fa','dir'=>'rtl','display'=>'standalone','background_color'=>$pwa['background_color'],'theme_color'=>$pwa['theme_color'],'orientation'=>'portrait','icons'=>$icons),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
        }
        if($kind==='worker'){header('Content-Type: application/javascript; charset=UTF-8');header('Service-Worker-Allowed: '.wp_parse_url($base,PHP_URL_PATH));echo 'self.WSM_PORTAL_WORKER_CONFIG='.wp_json_encode(array('version'=>$p['pwa']['version'].'-2.3.0','home'=>$base,'api'=>rest_url('wsm/v1/portal/'),'legacyApi'=>rest_url('wsm/v1/athlete-portal/'),'assets'=>array(WSM_URL.'wsm-app/icon-192.png',WSM_URL.'wsm-app/icon-512.png',WSM_URL.'wsm-app/fonts/Vazirmatn-Variable.woff2'))).";\n";readfile(WSM_PATH.'wsm-app/sw.js');exit;}
        status_header(404);exit;
    }

}

// Register the existing option with WordPress Settings API early enough for admin_init.
// The app's authenticated REST writes are independently protected by Bearer/HMAC timestamp+nonce.
add_action('admin_init', array('WSM_Rest_API', 'register_settings_api_option'), 5);

// Register delta-sync observers as soon as the REST class is loaded.
WSM_Rest_API::register_sync_pull_watchers();

// Portal16 routes and native Woo wallet callbacks; existing payment processors remain unchanged.
add_action('init',array('WSM_Rest_API','portal16_types'),3);
add_action('rest_api_init',array('WSM_Rest_API','portal16_routes'),21);
add_action('wsm_portal_buffet_saved',array('WSM_Rest_API','portal16_buffet_staff_sms_enqueue'),10,2);
add_action('wsm_portal_buffet_staff_sms_send',array('WSM_Rest_API','portal16_buffet_staff_sms_send'),10,2);
foreach(array('woocommerce_payment_complete','woocommerce_order_status_processing','woocommerce_order_status_completed','wsm_portal16_wallet_retry') as $portal16_paid_hook)add_action($portal16_paid_hook,array('WSM_Rest_API','portal16_wallet_paid'),30,2);
add_action('woocommerce_order_status_failed',array('WSM_Rest_API','portal16_wallet_failed'),30,2);
add_action('wsm_portal16_wallet_notice_retry',array('WSM_Rest_API','portal16_wallet_notice'),30,2);
add_filter('woocommerce_get_return_url',array('WSM_Rest_API','portal16_wallet_return'),100,2);
