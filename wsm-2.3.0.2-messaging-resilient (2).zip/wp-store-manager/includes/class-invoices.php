<?php
/**
 * فاکتور فروش: هر فاکتور یک سفارش ووکامرس با متای _wsm_invoice=1 است.
 * شامل: یکپارچگی مالی ریالی/تومانی، قفل‌شدن اسناد مالی صادرشده، ابطال رسمی و همگام‌سازی صندوق،
 * فیلتر بازهٔ تاریخ شمسی، جستجوی دقیق بدون تداخل فازی اعداد، و چاپ تکی/گروهی با بارکد و کیوآرکد SVG.
 */

if (!defined('ABSPATH')) {
    exit;
}

class WSM_Invoices {

    const STATUSES = array('draft', 'unpaid', 'sent', 'paid', 'cancelled');

    /** فهرست وضعیت‌های استاندارد فاکتور برای فیلتر و فرم‌ها. */
    public static function statuses() {
        return array(
            array('key' => 'unpaid',    'label' => 'پرداخت‌نشده'),
            array('key' => 'paid',      'label' => 'پرداخت‌شده'),
            array('key' => 'cancelled', 'label' => 'لغوشده'),
            array('key' => 'draft',     'label' => 'پیش‌نویس'),
            array('key' => 'sent',      'label' => 'ارسال‌شده'),
        );
    }

    public static function label($status) {
        $labels = array(
            'draft'     => 'پیش‌نویس',
            'unpaid'    => 'پرداخت‌نشده',
            'sent'      => 'ارسال‌شده',
            'paid'      => 'پرداخت‌شده',
            'cancelled' => 'لغوشده',
        );
        return isset($labels[$status]) ? $labels[$status] : $status;
    }

    /** تبدیل ارقام فارسی/عربی و جداکننده‌های هزارگان به لاتین استاندارد. */
    public static function latinize_digits($value) {
        return strtr((string) $value, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
            '٬' => '',  '٫' => '.', '،' => '',
        ));
    }

    /** استانداردسازی کلید وضعیت (پشتیبانی از alias ابطال/void). */
    public static function normalize_status_key($status) {
        $key = sanitize_key((string) $status);
        if (strpos($key, 'wc-') === 0) {
            $key = substr($key, 3);
        }
        if ($key === 'void' || $key === 'voided') {
            return 'cancelled';
        }
        return $key;
    }

    /** وضعیت مؤثر فاکتور روی رکورد سفارش. */
    public static function effective_status(WC_Order $o) {
        if ((bool) $o->get_meta('_wsm_invoice_voided')) {
            return 'cancelled';
        }
        $meta = self::normalize_status_key($o->get_meta('_wsm_invoice_status'));
        if ($meta !== '' && in_array($meta, self::STATUSES, true)) {
            return $meta;
        }
        return self::status_from_order($o->get_status());
    }

    /** آیا سند فاکتور قفل شده است و ویرایش اقلام/مبالغ آن مجاز نیست؟ */
    public static function is_immutable(WC_Order $o) {
        $status = self::effective_status($o);
        if (in_array($status, array('paid', 'cancelled'), true)) {
            return true;
        }
        if ((bool) $o->get_meta('_wsm_invoice_voided')) {
            return true;
        }
        if (absint($o->get_meta('_wsm_source_order_id')) > 0) {
            return true;
        }
        if (absint($o->get_meta('_wsm_invoice_finance_id')) > 0) {
            return true;
        }
        return false;
    }

    /** نگاشت وضعیت استاندارد ووکامرس به وضعیت فاکتور. */
    public static function status_from_order($status) {
        $status = sanitize_key((string) $status);
        if (strpos($status, 'wc-') === 0) {
            $status = substr($status, 3);
        }
        if (in_array($status, array('draft', 'auto-draft', 'checkout-draft', ''), true)) {
            return 'draft';
        }
        if (in_array($status, array('cancelled', 'failed', 'refunded'), true)) {
            return 'cancelled';
        }
        if (in_array($status, array('processing', 'completed'), true)) {
            return 'paid';
        }
        if ($status === 'pending') {
            return 'unpaid';
        }
        if ($status === 'on-hold') {
            return 'sent';
        }
        return 'sent';
    }

    /** اطلاعات گیرنده برای برچسب؛ نشانی ارسال بر صورتحساب اولویت دارد. */
    private static function postal_recipient(WC_Order $o) {
        $saved    = $o->get_meta('_wsm_postal_recipient', true);
        $saved    = is_array($saved) ? $saved : array();
        $shipping = $o->get_address('shipping');
        $billing  = $o->get_address('billing');
        $shipping = is_array($shipping) ? $shipping : array();
        $billing  = is_array($billing) ? $billing : array();

        $shipping_name  = trim((isset($shipping['first_name']) ? $shipping['first_name'] : '') . ' ' . (isset($shipping['last_name']) ? $shipping['last_name'] : ''));
        $billing_name   = trim((isset($billing['first_name']) ? $billing['first_name'] : '') . ' ' . (isset($billing['last_name']) ? $billing['last_name'] : ''));
        $shipping_phone = method_exists($o, 'get_shipping_phone') ? (string) $o->get_shipping_phone() : (string) $o->get_meta('_shipping_phone');
        $fallback = array(
            'name'      => $shipping_name !== '' ? $shipping_name : $billing_name,
            'company'   => !empty($shipping['company']) ? $shipping['company'] : (isset($billing['company']) ? $billing['company'] : ''),
            'phone'     => $shipping_phone !== '' ? $shipping_phone : (string) $o->get_billing_phone(),
            'address_1' => !empty($shipping['address_1']) ? $shipping['address_1'] : (isset($billing['address_1']) ? $billing['address_1'] : ''),
            'address_2' => !empty($shipping['address_2']) ? $shipping['address_2'] : (isset($billing['address_2']) ? $billing['address_2'] : ''),
            'city'      => !empty($shipping['city']) ? $shipping['city'] : (isset($billing['city']) ? $billing['city'] : ''),
            'state'     => !empty($shipping['state']) ? $shipping['state'] : (isset($billing['state']) ? $billing['state'] : ''),
            'postcode'  => !empty($shipping['postcode']) ? $shipping['postcode'] : (isset($billing['postcode']) ? $billing['postcode'] : ''),
            'country'   => !empty($shipping['country']) ? $shipping['country'] : (isset($billing['country']) ? $billing['country'] : 'IR'),
        );
        $recipient = array();
        foreach ($fallback as $key => $value) {
            $recipient[$key] = array_key_exists($key, $saved) ? (string) $saved[$key] : (string) $value;
        }
        $recipient['address'] = $recipient['address_1'];
        return $recipient;
    }

    private static function discount_of($type, $value, $base) {
        $value = max(0, (float) $value);
        if ($type === 'percent') {
            $value = min(100, $value);
            return round($base * $value / 100);
        }
        if ($type === 'amount') {
            return min($value, $base);
        }
        return 0.0;
    }

    /** اعتبارسنجی عدد نامنفی مالی پیش از ارسال به ووکامرس (با پشتیبانی از ارقام فارسی). */
    private static function numeric_amount($value, $label) {
        if (!is_scalar($value)) {
            return new WP_Error('wsm_amount_invalid', $label . ' نامعتبر است.', array('status' => 400));
        }
        $raw = str_replace(',', '', trim(self::latinize_digits((string) $value)));
        if ($raw === '') {
            return 0.0;
        }
        if (!is_numeric($raw) || !is_finite((float) $raw) || (float) $raw < 0 || (float) $raw > 1000000000000) {
            return new WP_Error('wsm_amount_invalid', $label . ' باید عددی و نامنفی باشد.', array('status' => 400));
        }
        return (float) $raw;
    }

    /** اعتبارسنجی و محاسبهٔ ورودی فاکتور دستی. */
    private static function normalize($data) {
        if (!is_array($data)) {
            return new WP_Error('wsm_invoice_data_invalid', 'اطلاعات فاکتور نامعتبر است.', array('status' => 400));
        }
        $items_in = isset($data['items']) && is_array($data['items']) ? $data['items'] : array();
        if (!count($items_in)) {
            return new WP_Error('wsm_items_empty', 'حداقل یک قلم کالا لازم است.', array('status' => 400));
        }
        if (count($items_in) > 500) {
            return new WP_Error('wsm_items_limit', 'هر فاکتور حداکثر می‌تواند ۵۰۰ قلم داشته باشد.', array('status' => 400));
        }

        $items = array();
        foreach ($items_in as $it) {
            if (!is_array($it)) {
                return new WP_Error('wsm_items_invalid', 'یکی از اقلام فاکتور نامعتبر است.', array('status' => 400));
            }
            $pid_raw = isset($it['product_id']) ? $it['product_id'] : 0;
            if (!is_scalar($pid_raw)) {
                return new WP_Error('wsm_items_invalid', 'شناسهٔ کالا نامعتبر است.', array('status' => 400));
            }
            $pid     = (int) self::latinize_digits((string) $pid_raw);
            $qty_raw = isset($it['qty']) ? $it['qty'] : (isset($it['quantity']) ? $it['quantity'] : 1);
            $qty_lat = is_scalar($qty_raw) ? trim(self::latinize_digits((string) $qty_raw)) : '';
            $qty     = ($qty_lat !== '' && filter_var($qty_lat, FILTER_VALIDATE_INT) !== false) ? (int) $qty_lat : 0;
            if ($qty < 1 || $qty > 100000) {
                return new WP_Error('wsm_items_invalid', 'تعداد هر قلم باید بین ۱ تا ۱۰۰٬۰۰۰ باشد.', array('status' => 400));
            }
            if (isset($it['name']) && !is_scalar($it['name'])) {
                return new WP_Error('wsm_items_invalid', 'نام قلم کالا نامعتبر است.', array('status' => 400));
            }
            $name  = WSM_Util::clean_text(isset($it['name']) ? $it['name'] : '', 255);
            $price = null;
            $raw_price_field = array_key_exists('price', $it) ? $it['price'] : (array_key_exists('unit_price', $it) ? $it['unit_price'] : '');
            if ($raw_price_field !== '' && $raw_price_field !== null) {
                if (!is_scalar($raw_price_field)) {
                    return new WP_Error('wsm_price_invalid', 'قیمت قلم نامعتبر است.', array('status' => 400));
                }
                $price_str = str_replace(',', '', trim(self::latinize_digits((string) $raw_price_field)));
                $price_fmt = wc_format_decimal($price_str);
                if (!is_numeric($price_fmt) || !is_finite((float) $price_fmt) || (float) $price_fmt < 0 || (float) $price_fmt > 1000000000000) {
                    return new WP_Error('wsm_price_invalid', 'قیمت قلم باید عددی و نامنفی باشد.', array('status' => 400));
                }
                $price = (float) $price_fmt;
            }
            $product = $pid ? wc_get_product($pid) : null;
            if ($pid && !$product) {
                return new WP_Error('wsm_product_missing', 'محصول #' . $pid . ' پیدا نشد.', array('status' => 400));
            }
            if ($product) {
                $name  = $name ?: $product->get_name();
                $price = $price === null ? (float) $product->get_price() : $price;
            }
            if ($name === '') {
                return new WP_Error('wsm_name_required', 'نام قلم کالا الزامی است.', array('status' => 400));
            }
            $price     = max(0.0, (float) $price);
            $dtype_raw = isset($it['discount_type']) && is_scalar($it['discount_type']) ? (string) $it['discount_type'] : '';
            $dtype     = in_array($dtype_raw, array('percent', 'amount'), true) ? $dtype_raw : 'none';
            $dval_raw  = isset($it['discount_value']) ? $it['discount_value'] : 0;
            $dval      = self::numeric_amount($dval_raw, 'تخفیف قلم');
            if (is_wp_error($dval)) { return $dval; }

            $gross = $price * $qty;
            $disc  = self::discount_of($dtype, $dval, $gross);
            $items[] = array(
                'product'    => $product,
                'product_id' => $pid,
                'name'       => $name,
                'qty'        => $qty,
                'unit'       => $price,
                'gross'      => $gross,
                'line_disc'  => $disc,
                'net'        => $gross - $disc,
                'dtype'      => $dtype,
                'dval'       => $dval,
                'sku'        => isset($it['sku']) && is_scalar($it['sku']) ? WSM_Util::clean_text((string) $it['sku'], 80) : '',
            );
        }

        $base_net        = 0.0;
        $line_disc_total = 0.0;
        $gross_total     = 0.0;
        foreach ($items as $row) {
            $base_net        += $row['net'];
            $line_disc_total += $row['line_disc'];
            $gross_total     += $row['gross'];
        }

        if (isset($data['discount']) && !is_array($data['discount'])) {
            return new WP_Error('wsm_discount_invalid', 'تخفیف فاکتور نامعتبر است.', array('status' => 400));
        }
        $discount_input = isset($data['discount']) && is_array($data['discount']) ? $data['discount'] : array();
        $dtype_raw = isset($discount_input['type']) && is_scalar($discount_input['type'])
            ? (string) $discount_input['type']
            : (isset($data['discount_type']) && is_scalar($data['discount_type']) ? (string) $data['discount_type'] : '');
        $dtype_all = in_array($dtype_raw, array('percent', 'amount'), true) ? $dtype_raw : 'none';
        $dval_source = array_key_exists('value', $discount_input)
            ? $discount_input['value']
            : (isset($data['discount_value']) ? $data['discount_value'] : 0);
        $dval_all = self::numeric_amount($dval_source, 'تخفیف فاکتور');
        if (is_wp_error($dval_all)) { return $dval_all; }

        $order_disc = self::discount_of($dtype_all, $dval_all, $base_net);
        $after      = max(0.0, $base_net - $order_disc);

        $tax_pct = self::numeric_amount(isset($data['tax_percent']) ? $data['tax_percent'] : 0, 'درصد مالیات');
        if (is_wp_error($tax_pct)) { return $tax_pct; }
        $tax_pct = min(100.0, $tax_pct);

        if (array_key_exists('tax', $data) && (!array_key_exists('tax_percent', $data) || (float) $tax_pct <= 0.0)) {
            $tax = self::numeric_amount($data['tax'], 'مالیات');
            if (is_wp_error($tax)) { return $tax; }
        } else {
            $tax = round($after * $tax_pct / 100);
        }

        $ship_source = array_key_exists('shipping_amount', $data)
            ? $data['shipping_amount']
            : (isset($data['shipping']) ? $data['shipping'] : 0);
        $shipping = self::numeric_amount($ship_source, 'هزینهٔ ارسال');
        if (is_wp_error($shipping)) { return $shipping; }

        $total = $after + $tax + $shipping;

        return array(
            'items'       => $items,
            'gross_total' => $gross_total,
            'line_disc'   => $line_disc_total,
            'order_disc'  => $order_disc,
            'dtype_all'   => $dtype_all,
            'dval_all'    => $dval_all,
            'tax_pct'     => $tax_pct,
            'tax'         => $tax,
            'shipping'    => $shipping,
            'total'       => $total,
        );
    }

    /** اعمال اقلام و مشخصات خریدار/گیرنده روی رکورد فاکتور. */
    private static function apply_to_order(WC_Order $o, $calc, $data) {
        foreach (array_keys($o->get_items(array('line_item', 'fee', 'shipping'))) as $item_id) {
            $o->remove_item($item_id);
        }

        foreach ($calc['items'] as $row) {
            $item = new WC_Order_Item_Product();
            if ($row['product']) {
                $item->set_product($row['product']);
            } elseif (!empty($row['product_id'])) {
                $item->set_product_id((int) $row['product_id']);
            }
            $item->set_name($row['name']);
            $item->set_quantity($row['qty']);
            $item->set_subtotal($row['gross']);
            $item->set_total($row['net']);
            $item->set_taxes(array('total' => array(), 'subtotal' => array()));
            $item->add_meta_data('_wsm_unit_price', $row['unit'], true);
            $item->add_meta_data('_wsm_disc_type', $row['dtype'], true);
            $item->add_meta_data('_wsm_disc_value', $row['dval'], true);
            if (!empty($row['sku'])) {
                $item->add_meta_data('_wsm_manual_sku', $row['sku'], true);
            }
            $o->add_item($item);
        }

        if ($calc['order_disc'] > 0) {
            $fee = new WC_Order_Item_Fee();
            $fee->set_name('تخفیف فاکتور');
            $fee->set_amount(-$calc['order_disc']);
            $fee->set_total(-$calc['order_disc']);
            $fee->set_tax_status('none');
            $fee->add_meta_data('_wsm_fee_kind', 'discount', true);
            $o->add_item($fee);
        }
        if ($calc['tax'] > 0) {
            $fee = new WC_Order_Item_Fee();
            $fee->set_name($calc['tax_pct'] > 0 ? ('مالیات (' . $calc['tax_pct'] . '٪)') : 'مالیات');
            $fee->set_amount($calc['tax']);
            $fee->set_total($calc['tax']);
            $fee->set_tax_status('none');
            $fee->add_meta_data('_wsm_fee_kind', 'tax', true);
            $o->add_item($fee);
        }
        if ($calc['shipping'] > 0) {
            $ship = new WC_Order_Item_Shipping();
            $ship->set_method_title('هزینهٔ ارسال');
            $ship->set_total($calc['shipping']);
            $ship->set_taxes(array('total' => array()));
            $o->add_item($ship);
        }

        $o->set_cart_tax(0);
        $o->set_shipping_tax(0);
        $o->set_discount_total($calc['line_disc'] + $calc['order_disc']);
        $o->set_shipping_total($calc['shipping']);
        $o->set_total($calc['total']);

        $buyer = isset($data['buyer']) && is_array($data['buyer']) ? $data['buyer'] : array();
        $buyer_name = WSM_Util::clean_text(isset($buyer['name']) ? $buyer['name'] : '', 160);
        if ($buyer_name !== '') {
            $parts = preg_split('/\s+/u', $buyer_name, 2);
            $o->set_billing_first_name(isset($parts[0]) ? $parts[0] : '');
            $o->set_billing_last_name(isset($parts[1]) ? $parts[1] : '');
        } else {
            $o->set_billing_first_name(WSM_Util::clean_text(isset($buyer['first_name']) ? $buyer['first_name'] : '', 100));
            $o->set_billing_last_name(WSM_Util::clean_text(isset($buyer['last_name']) ? $buyer['last_name'] : '', 100));
        }
        $buyer_phone = isset($buyer['mobile']) && $buyer['mobile'] !== ''
            ? $buyer['mobile']
            : (isset($buyer['phone']) ? $buyer['phone'] : '');
        $o->set_billing_phone(sanitize_text_field(self::latinize_digits($buyer_phone)));
        $o->set_billing_email(sanitize_email(isset($buyer['email']) ? $buyer['email'] : ''));
        $o->set_billing_address_1(WSM_Util::clean_text(isset($buyer['address']) ? $buyer['address'] : '', 255));
        if (isset($buyer['city']))     { $o->set_billing_city(WSM_Util::clean_text($buyer['city'], 100)); }
        if (isset($buyer['state']))    { $o->set_billing_state(WSM_Util::clean_text($buyer['state'], 100)); }
        if (isset($buyer['postcode'])) { $o->set_billing_postcode(sanitize_text_field(self::latinize_digits($buyer['postcode']))); }
        if (isset($buyer['company']))  { $o->set_billing_company(WSM_Util::clean_text($buyer['company'], 150)); }
        $o->update_meta_data('_wsm_buyer_national_id', sanitize_text_field(self::latinize_digits(isset($buyer['national_id']) ? $buyer['national_id'] : '')));

        $recipient_input = isset($data['recipient']) && is_array($data['recipient']) ? $data['recipient'] : array();
        if (isset($recipient_input['address']) && !isset($recipient_input['address_1'])) {
            $recipient_input['address_1'] = $recipient_input['address'];
        }
        $recipient_fallback  = self::postal_recipient($o);
        $saved_recipient     = $o->get_meta('_wsm_postal_recipient', true);
        $has_saved_recipient = is_array($saved_recipient);
        $recipient_sanitizers = array(
            'name'      => function ($value) { return WSM_Util::clean_text($value, 150); },
            'company'   => function ($value) { return WSM_Util::clean_text($value, 150); },
            'phone'     => function ($value) { return sanitize_text_field(WSM_Invoices::latinize_digits($value)); },
            'address_1' => function ($value) { return sanitize_textarea_field($value); },
            'address_2' => function ($value) { return sanitize_textarea_field($value); },
            'city'      => function ($value) { return WSM_Util::clean_text($value, 100); },
            'state'     => function ($value) { return WSM_Util::clean_text($value, 100); },
            'postcode'  => function ($value) { return sanitize_text_field(WSM_Invoices::latinize_digits($value)); },
            'country'   => function ($value) { return WSM_Util::clean_text($value, 100); },
        );
        $recipient = array();
        foreach ($recipient_sanitizers as $field => $sanitize_value) {
            $has_input = array_key_exists($field, $recipient_input) && is_scalar($recipient_input[$field]);
            $value     = $has_input ? $sanitize_value((string) $recipient_input[$field]) : '';
            if ($has_input && ($value !== '' || $has_saved_recipient)) {
                $recipient[$field] = $value;
            } else {
                $recipient[$field] = isset($recipient_fallback[$field]) ? (string) $recipient_fallback[$field] : '';
            }
        }
        $o->update_meta_data('_wsm_postal_recipient', $recipient);
        $o->set_shipping_first_name($recipient['name']);
        $o->set_shipping_last_name('');
        $o->set_shipping_company($recipient['company']);
        $o->set_shipping_address_1($recipient['address_1']);
        $o->set_shipping_address_2($recipient['address_2']);
        $o->set_shipping_city($recipient['city']);
        $o->set_shipping_state($recipient['state']);
        $o->set_shipping_postcode($recipient['postcode']);
        $o->set_shipping_country($recipient['country'] ?: 'IR');
        if (method_exists($o, 'set_shipping_phone')) {
            $o->set_shipping_phone($recipient['phone']);
        } else {
            $o->update_meta_data('_shipping_phone', $recipient['phone']);
        }

        $o->update_meta_data('_wsm_discount_type', $calc['dtype_all']);
        $o->update_meta_data('_wsm_discount_value', $calc['dval_all']);
        $o->update_meta_data('_wsm_tax_percent', $calc['tax_pct']);
        $o->set_customer_note(sanitize_textarea_field(isset($data['note']) ? $data['note'] : ''));
        if (isset($data['custom_fields']) && is_array($data['custom_fields'])) {
            WSM_Util::save_custom_field_values($o, 'invoices', $data['custom_fields']);
        }
    }

    /** همگام‌سازی وضعیت داخلی سفارش ووکامرس فاکتور با وضعیت فاکتور. */
    private static function sync_wc_status(WC_Order $o, $invoice_status) {
        $map = array(
            'draft'     => 'pending',
            'unpaid'    => 'pending',
            'sent'      => 'on-hold',
            'paid'      => 'completed',
            'cancelled' => 'cancelled',
        );
        $o->set_status(isset($map[$invoice_status]) ? $map[$invoice_status] : 'pending');
    }

    /** ایجاد فاکتور دستی جدید. */
    public static function create($data) {
        $calc = self::normalize($data);
        if (is_wp_error($calc)) {
            return $calc;
        }
        $status = 'unpaid';
        if (isset($data['status'])) {
            if (!is_scalar($data['status'])) {
                return new WP_Error('wsm_bad_status', 'وضعیت فاکتور نامعتبر است.', array('status' => 400));
            }
            $status = self::normalize_status_key($data['status']);
            if (!in_array($status, self::STATUSES, true)) {
                return new WP_Error('wsm_bad_status', 'وضعیت فاکتور نامعتبر است.', array('status' => 400));
            }
        }

        $o = wc_create_order(array('status' => 'pending'));
        if (is_wp_error($o)) {
            return $o;
        }
        $o->update_meta_data('_wsm_invoice', 1);
        $o->update_meta_data('_wsm_invoice_status', $status);
        if ($status === 'cancelled') {
            $o->update_meta_data('_wsm_invoice_voided', '1');
            $o->update_meta_data('_wsm_invoice_voided_at', current_time('mysql'));
        }
        $o->set_created_via('wp-store-manager');
        self::apply_to_order($o, $calc, $data);
        self::sync_wc_status($o, $status);
        $o->save();

        if ($status === 'paid') {
            $ledger_res = self::record_invoice_payment_in_ledger($o, is_array($data) ? $data : array());
            if (is_wp_error($ledger_res)) {
                return $ledger_res;
            }
        }

        WSM_Activity_Log::log('invoice', 'invoice', $o->get_id(), 'فاکتور INV-' . $o->get_id(), '', $calc['total'], 'success');
        return self::format(wc_get_order($o->get_id()));
    }

    /**
     * ساخت فاکتور قفل‌شده از روی سفارش موجود بدون دستکاری سفارش اصلی.
     * اگر فاکتور فعال قبلی وجود داشته باشد همان سند قفل‌شده برگردانده می‌شود؛
     * اگر فاکتور قبلی ابطال شده باشد در تاریخچهٔ ابطال حفظ شده و فاکتور جایگزین صادر می‌شود.
     */
    public static function create_from_order($order_id) {
        $source = wc_get_order((int) $order_id);
        if (!$source || $source->get_meta('_wsm_invoice')) {
            return new WP_Error('wsm_order_not_found', 'سفارش برای صدور فاکتور پیدا نشد.', array('status' => 404));
        }

        $linked_id = absint($source->get_meta('_wsm_linked_invoice_id'));
        if ($linked_id > 0) {
            $existing = wc_get_order($linked_id);
            if ($existing && $existing->get_meta('_wsm_invoice') && absint($existing->get_meta('_wsm_source_order_id')) === (int) $source->get_id()) {
                $existing_status = self::effective_status($existing);
                if ($existing_status !== 'cancelled') {
                    // سند مالی صادرشده قفل است و حتی در صورت تغییر بعدی سفارش، اقلام و مبالغ آن تغییر نمی‌کند!
                    return self::format($existing);
                }
                // فاکتور قبلی باطل شده است: هرگز نباید زنده شود؛ در تاریخچهٔ ابطالی ذخیره و سند جدید صادر شود.
                $voided_history = $source->get_meta('_wsm_voided_invoice_ids');
                $voided_ids     = is_array($voided_history) ? array_map('absint', $voided_history) : array();
                if (!in_array($linked_id, $voided_ids, true)) {
                    $voided_ids[] = $linked_id;
                }
                $source->update_meta_data('_wsm_voided_invoice_ids', array_values(array_filter($voided_ids)));
                $source->delete_meta_data('_wsm_linked_invoice_id');
                $source->save_meta_data();
            } else {
                $source->delete_meta_data('_wsm_linked_invoice_id');
                $source->save_meta_data();
            }
        }

        $source_items = $source->get_items('line_item');
        if (!$source_items) {
            return new WP_Error('wsm_order_items_empty', 'این سفارش قلم کالایی ندارد و فاکتور از آن ساخته نشد.', array('status' => 400));
        }

        $invoice_status = self::status_from_order($source->get_status());
        $invoice = wc_create_order(array('status' => 'pending'));
        if (is_wp_error($invoice)) {
            return $invoice;
        }
        $invoice->set_created_via('wp-store-manager');
        $invoice->set_currency($source->get_currency());
        $invoice->set_customer_id($source->get_customer_id());
        $invoice->set_address($source->get_address('billing'), 'billing');
        $invoice->set_address($source->get_address('shipping'), 'shipping');
        if (method_exists($source, 'get_shipping_phone') && method_exists($invoice, 'set_shipping_phone')) {
            $invoice->set_shipping_phone($source->get_shipping_phone());
        }
        $invoice->update_meta_data('_wsm_postal_recipient', self::postal_recipient($source));

        foreach (array('_wsm_club_member_id', '_wsm_club_member_code', '_wsm_club_card_number', '_wsm_buyer_national_id') as $meta_key) {
            $meta_val = $source->get_meta($meta_key, true);
            if ($meta_val !== '' && $meta_val !== null) {
                $invoice->update_meta_data($meta_key, $meta_val);
            }
        }

        $line_disc_total = 0.0;
        foreach ($source_items as $source_item) {
            if (!($source_item instanceof WC_Order_Item_Product)) {
                continue;
            }
            $qty   = max(1, (int) $source_item->get_quantity());
            $gross = (float) $source_item->get_subtotal();
            $net   = (float) $source_item->get_total();
            $disc  = max(0.0, $gross - $net);
            $line_disc_total += $disc;

            $item    = new WC_Order_Item_Product();
            $product = $source_item->get_product();
            if ($product) {
                $item->set_product($product);
            } else {
                $item->set_product_id((int) $source_item->get_product_id());
                $item->set_variation_id((int) $source_item->get_variation_id());
            }
            $item->set_name($source_item->get_name());
            $item->set_quantity($qty);
            $item->set_subtotal($gross);
            $item->set_total($net);
            // جلوگیری از دوبار شمرده‌شدن مالیات: مالیات سفارش یک‌بار در ردیف مالیات ثبت می‌شود.
            $item->set_taxes(array('total' => array(), 'subtotal' => array()));
            $unit_price = $qty > 0 ? ($gross / $qty) : 0.0;
            $item->add_meta_data('_wsm_unit_price', $unit_price, true);
            $item->add_meta_data('_wsm_disc_type', $disc > 0 ? 'amount' : 'none', true);
            $item->add_meta_data('_wsm_disc_value', $disc, true);
            $invoice->add_item($item);
        }

        $order_fee_disc = 0.0;
        foreach ($source->get_items('fee') as $source_fee) {
            if (!($source_fee instanceof WC_Order_Item_Fee)) {
                continue;
            }
            $kind = (string) $source_fee->get_meta('_wsm_fee_kind');
            if ($kind === 'tax') {
                continue;
            }
            $ftot = (float) $source_fee->get_total();
            $fee  = new WC_Order_Item_Fee();
            $fee->set_name($source_fee->get_name());
            $fee->set_amount($ftot);
            $fee->set_total($ftot);
            $fee->set_tax_status('none');
            $fee->set_taxes(array('total' => array()));
            if ($kind === 'discount' || $ftot < 0) {
                $fee->add_meta_data('_wsm_fee_kind', 'discount', true);
                $order_fee_disc += abs($ftot);
            } elseif ($kind !== '') {
                $fee->add_meta_data('_wsm_fee_kind', $kind, true);
            }
            $invoice->add_item($fee);
        }

        // احتساب کوپن/تخفیف سطح سفارش که فراتر از تفاوت خطوط باشد
        $extra_coupon_disc = max(0.0, (float) $source->get_discount_total() - $line_disc_total);
        if ($extra_coupon_disc > 0.009) {
            $dfee = new WC_Order_Item_Fee();
            $dfee->set_name('تخفیف کوپن سفارش');
            $dfee->set_amount(-$extra_coupon_disc);
            $dfee->set_total(-$extra_coupon_disc);
            $dfee->set_tax_status('none');
            $dfee->add_meta_data('_wsm_fee_kind', 'discount', true);
            $invoice->add_item($dfee);
            $order_fee_disc += $extra_coupon_disc;
        }

        foreach ($source->get_items('shipping') as $source_ship) {
            if (!($source_ship instanceof WC_Order_Item_Shipping)) {
                continue;
            }
            $ship = new WC_Order_Item_Shipping();
            $ship->set_method_title($source_ship->get_method_title() ?: 'هزینهٔ ارسال');
            $ship->set_method_id($source_ship->get_method_id() ?: 'flat_rate');
            $ship->set_total((float) $source_ship->get_total());
            $ship->set_taxes(array('total' => array()));
            $invoice->add_item($ship);
        }

        $tax_total = (float) $source->get_total_tax();
        if ($tax_total > 0) {
            $tfee = new WC_Order_Item_Fee();
            $tfee->set_name('مالیات');
            $tfee->set_amount($tax_total);
            $tfee->set_total($tax_total);
            $tfee->set_tax_status('none');
            $tfee->add_meta_data('_wsm_fee_kind', 'tax', true);
            $invoice->add_item($tfee);
        }

        $invoice->update_meta_data('_wsm_invoice', 1);
        $invoice->update_meta_data('_wsm_invoice_status', $invoice_status);
        $invoice->update_meta_data('_wsm_source_order_id', (int) $source->get_id());
        $invoice->update_meta_data('_wsm_source_order_number', (string) $source->get_order_number());
        $invoice->update_meta_data('_wsm_discount_type', $order_fee_disc > 0 ? 'amount' : 'none');
        $invoice->update_meta_data('_wsm_discount_value', $order_fee_disc);
        $invoice->update_meta_data('_wsm_tax_percent', 0);
        if ($invoice_status === 'cancelled') {
            $invoice->update_meta_data('_wsm_invoice_voided', '1');
            $invoice->update_meta_data('_wsm_invoice_voided_at', current_time('mysql'));
            $invoice->update_meta_data('_wsm_invoice_void_reason', 'صدور از سفارش لغوشده #' . $source->get_order_number());
        }

        $invoice->set_customer_note($source->get_customer_note());
        $invoice->set_cart_tax(0);
        $invoice->set_shipping_tax(0);
        $invoice->set_discount_total($line_disc_total + $order_fee_disc);
        $invoice->set_shipping_total((float) $source->get_shipping_total());
        $invoice->set_total((float) $source->get_total());
        self::sync_wc_status($invoice, $invoice_status);
        $invoice->save();

        $source->update_meta_data('_wsm_linked_invoice_id', (int) $invoice->get_id());
        $source->save_meta_data();

        WSM_Activity_Log::log(
            'invoice',
            'invoice',
            $invoice->get_id(),
            'فاکتور INV-' . $invoice->get_id(),
            'سفارش #' . $source->get_order_number(),
            $invoice->get_total(),
            'success'
        );
        return self::format(wc_get_order($invoice->get_id()));
    }

    /** همگام‌سازی خودکار وضعیت سفارش اصلی با فاکتور مرتبط (به‌ویژه ابطال هنگام لغو سفارش). */
    public static function sync_source_order_status($order_id, $old_status, $new_status, $order = null) {
        $source = $order instanceof WC_Order ? $order : wc_get_order((int) $order_id);
        if (!$source || $source->get_meta('_wsm_invoice')) {
            return;
        }
        $linked_id = absint($source->get_meta('_wsm_linked_invoice_id'));
        if ($linked_id <= 0) {
            return;
        }
        $invoice = wc_get_order($linked_id);
        if (!$invoice || !$invoice->get_meta('_wsm_invoice')) {
            return;
        }
        $current = self::effective_status($invoice);
        // فاکتور ابطال‌شده هرگز نباید به‌صورت خودکار از حالت ابطال خارج شود.
        if ($current === 'cancelled') {
            return;
        }
        $mapped = self::status_from_order($new_status);
        if ($mapped === $current) {
            return;
        }
        if ($mapped === 'cancelled') {
            self::void_invoice_internal(
                $invoice,
                'ابطال خودکار در پی لغو سفارش #' . $source->get_order_number(),
                true
            );
            return;
        }
        $invoice->update_meta_data('_wsm_invoice_status', $mapped);
        self::sync_wc_status($invoice, $mapped);
        $invoice->save();
        if ($mapped === 'paid') {
            self::record_invoice_payment_in_ledger($invoice, array('from_order_sync' => true));
        }
    }

    /** ویرایش فاکتور دستی پیش از پرداخت/ابطال؛ اسناد قطعی یا متصل به سفارش قفل هستند (409). */
    public static function update($id, $data) {
        $o = wc_get_order((int) $id);
        if (!$o || !$o->get_meta('_wsm_invoice')) {
            return new WP_Error('wsm_not_found', 'فاکتور پیدا نشد.', array('status' => 404));
        }
        if (self::is_immutable($o)) {
            return new WP_Error(
                'wsm_invoice_immutable',
                'این فاکتور سند مالی قطعی یا متصل به سفارش است و اقلام یا مبالغ آن قفل شده‌اند؛ تنها پس از ابطال می‌توان فاکتور جایگزین صادر کرد.',
                array('status' => 409)
            );
        }
        $calc = self::normalize($data);
        if (is_wp_error($calc)) {
            return $calc;
        }
        $prev_status = self::effective_status($o);
        $next_status = $prev_status;
        if (isset($data['status'])) {
            if (!is_scalar($data['status'])) {
                return new WP_Error('wsm_bad_status', 'وضعیت فاکتور نامعتبر است.', array('status' => 400));
            }
            $st = self::normalize_status_key($data['status']);
            if (!in_array($st, self::STATUSES, true)) {
                return new WP_Error('wsm_bad_status', 'وضعیت فاکتور نامعتبر است.', array('status' => 400));
            }
            $next_status = $st;
            $o->update_meta_data('_wsm_invoice_status', $st);
            if ($st === 'cancelled') {
                $o->update_meta_data('_wsm_invoice_voided', '1');
                $o->update_meta_data('_wsm_invoice_voided_at', current_time('mysql'));
            }
        }
        $before = $o->get_total();
        self::apply_to_order($o, $calc, $data);
        self::sync_wc_status($o, $next_status);
        $o->save();

        if ($prev_status !== 'paid' && $next_status === 'paid') {
            $ledger_res = self::record_invoice_payment_in_ledger($o, is_array($data) ? $data : array());
            if (is_wp_error($ledger_res)) {
                return $ledger_res;
            }
        }

        WSM_Activity_Log::log('update', 'invoice', $o->get_id(), 'فاکتور INV-' . $o->get_id(), $before, $calc['total'], 'success');
        return self::format(wc_get_order($o->get_id()));
    }

    /** تغییر وضعیت فاکتور به همراه همگام‌سازی اتمیک صندوق/دفتر کل مالی و قواعد ابطال. */
    public static function set_status($id, $status, $extra = array()) {
        $status = self::normalize_status_key($status);
        if (!in_array($status, self::STATUSES, true)) {
            return new WP_Error('wsm_bad_status', 'وضعیت نامعتبر است.', array('status' => 400));
        }
        $o = wc_get_order((int) $id);
        if (!$o || !$o->get_meta('_wsm_invoice')) {
            return new WP_Error('wsm_not_found', 'فاکتور پیدا نشد.', array('status' => 404));
        }

        $before = self::effective_status($o);
        if ($before === 'cancelled' && $status !== 'cancelled') {
            return new WP_Error(
                'wsm_invoice_already_voided',
                'فاکتور ابطال‌شده غیرقابل بازگردانی است؛ در صورت نیاز فاکتور جدید صادر کنید.',
                array('status' => 409)
            );
        }
        if ($before === 'paid' && !in_array($status, array('paid', 'cancelled'), true)) {
            return new WP_Error(
                'wsm_invoice_paid_locked',
                'فاکتور پرداخت‌شده را نمی‌توان به وضعیت پرداخت‌نشده بازگرداند؛ تنها امکان ابطال وجود دارد.',
                array('status' => 409)
            );
        }

        if ($status === 'cancelled') {
            $reason = (is_array($extra) && !empty($extra['reason']) && is_scalar($extra['reason']))
                ? WSM_Util::clean_text((string) $extra['reason'], 200)
                : 'ابطال سند فاکتور';
            $void_res = self::void_invoice_internal($o, $reason, false);
            if (is_wp_error($void_res)) {
                return $void_res;
            }
            WSM_Activity_Log::log('update', 'invoice', $o->get_id(), 'فاکتور INV-' . $o->get_id(), $before, 'cancelled', 'success');
            return self::format(wc_get_order($o->get_id()));
        }

        $o->update_meta_data('_wsm_invoice_status', $status);
        self::sync_wc_status($o, $status);
        $o->save();

        if ($status === 'paid') {
            $ledger_res = self::record_invoice_payment_in_ledger($o, is_array($extra) ? $extra : array());
            if (is_wp_error($ledger_res)) {
                return $ledger_res;
            }
        }

        WSM_Activity_Log::log('update', 'invoice', $o->get_id(), 'فاکتور INV-' . $o->get_id(), $before, $status, 'success');
        return self::format(wc_get_order($o->get_id()));
    }

    /** ثبت دریافت وجه فاکتور در صندوق/دفتر کل مالی به‌صورت Idempotent و بدون ثبت مضاعف. */
    private static function record_invoice_payment_in_ledger(WC_Order $invoice, array $extra = array()) {
        global $wpdb;
        $amount = round((float) $invoice->get_total(), 2);
        if ($amount <= 0 || !class_exists('WSM_Club_Operations')) {
            return 0;
        }
        WSM_Club_Operations::ensure_financial_core();
        $ledger_table = $wpdb->prefix . 'wsm_club_financial_ledger';
        $invoice_id   = (int) $invoice->get_id();
        $source_id    = absint($invoice->get_meta('_wsm_source_order_id'));

        $existing_inv_row = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$ledger_table} WHERE order_id = %d AND source = 'invoice_payment' AND status = 'posted' LIMIT 1",
            $invoice_id
        ));
        if ($existing_inv_row > 0) {
            if (absint($invoice->get_meta('_wsm_invoice_finance_id')) !== $existing_inv_row) {
                $invoice->update_meta_data('_wsm_invoice_finance_id', (int) $existing_inv_row);
                $invoice->save_meta_data();
            }
            return $existing_inv_row;
        }

        if ($source_id > 0) {
            $existing_order_row = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$ledger_table} WHERE order_id = %d AND status = 'posted' AND transaction_type = 'income' LIMIT 1",
                $source_id
            ));
            if ($existing_order_row > 0) {
                $invoice->update_meta_data('_wsm_invoice_finance_id', (int) $existing_order_row);
                $invoice->update_meta_data('_wsm_invoice_finance_origin', 'source_order');
                $invoice->save_meta_data();
                return $existing_order_row;
            }
        }

        $method_raw = isset($extra['payment_method']) && is_scalar($extra['payment_method'])
            ? sanitize_key((string) $extra['payment_method'])
            : 'cash';
        $method = in_array($method_raw, array('cash', 'card', 'bank_transfer'), true) ? $method_raw : 'cash';

        $finance_id = WSM_Club_Operations::add_finance(
            'pos_sale',
            $amount,
            'وصول فاکتور INV-' . $invoice_id,
            array(
                'order_id'         => $invoice_id,
                'method'           => $method,
                'source'           => 'invoice_payment',
                'reference'        => 'INV-' . $invoice_id,
                'reference_id'     => 'invoice:' . $invoice_id,
                'transaction_type' => 'income',
                'description'      => 'ثبت دریافت وجه فاکتور INV-' . $invoice_id . ' در صندوق',
            )
        );
        if (is_wp_error($finance_id)) {
            return $finance_id;
        }

        $invoice->update_meta_data('_wsm_invoice_finance_id', (int) $finance_id);
        $invoice->update_meta_data('_wsm_invoice_finance_origin', 'invoice_payment');
        $invoice->update_meta_data('_wsm_invoice_paid_at', current_time('mysql'));
        $invoice->save_meta_data();

        if ($source_id > 0 && empty($extra['from_order_sync'])) {
            $src = wc_get_order($source_id);
            if ($src && in_array($src->get_status(), array('pending', 'on-hold'), true) && !$src->get_meta('_wsm_credit_sale')) {
                $src->add_order_note('وجه فاکتور مرتبط INV-' . $invoice_id . ' وصول و در صندوق ثبت شد.');
                $src->save();
            }
        }
        return (int) $finance_id;
    }

    /** ابطال رسمی سند فاکتور و برگشت اتمیک تراکنش وصول فاکتور از صندوق در صورت وجود. */
    private static function void_invoice_internal(WC_Order $invoice, $reason = 'ابطال فاکتور', $from_order_sync = false) {
        global $wpdb;
        $invoice_id = (int) $invoice->get_id();
        $reason     = WSM_Util::clean_text((string) $reason, 200) ?: 'ابطال فاکتور';

        if (class_exists('WSM_Club_Operations')) {
            WSM_Club_Operations::ensure_financial_core();
            $ledger_table   = $wpdb->prefix . 'wsm_club_financial_ledger';
            $accounts_table = $wpdb->prefix . 'wsm_club_financial_accounts';

            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$ledger_table} WHERE order_id = %d AND source = 'invoice_payment' AND status = 'posted'",
                $invoice_id
            ), ARRAY_A);

            if (!empty($rows)) {
                $now = current_time('mysql');
                $uid = get_current_user_id();
                $wpdb->query('BEGIN');
                foreach ($rows as $row) {
                    $delta      = isset($row['account_delta']) ? (float) $row['account_delta'] : (float) ($row['amount'] ?? 0);
                    $account_id = isset($row['account_id']) ? (int) $row['account_id'] : 0;
                    if ($account_id > 0 && abs($delta) > 0.0001) {
                        $wpdb->query($wpdb->prepare(
                            "UPDATE {$accounts_table} SET current_balance = current_balance - %f, updated_at = %s WHERE id = %d",
                            $delta,
                            $now,
                            $account_id
                        ));
                    }
                    $wpdb->update(
                        $ledger_table,
                        array(
                            'status'        => 'void',
                            'ledger_status' => 'cancelled',
                            'void_reason'   => $reason,
                            'voided_by'     => $uid,
                            'voided_at'     => $now,
                        ),
                        array('id' => (int) $row['id']),
                        array('%s', '%s', '%s', '%d', '%s'),
                        array('%d')
                    );
                }
                $wpdb->query('COMMIT');
            }
        }

        $invoice->update_meta_data('_wsm_invoice_status', 'cancelled');
        $invoice->update_meta_data('_wsm_invoice_voided', '1');
        $invoice->update_meta_data('_wsm_invoice_voided_at', current_time('mysql'));
        $invoice->update_meta_data('_wsm_invoice_void_reason', $reason);
        self::sync_wc_status($invoice, 'cancelled');
        $invoice->save();
        return true;
    }

    /** حذف فیزیکی تنها برای فاکتور دستی پرداخت‌نشده/پیش‌نویس مجاز است؛ اسناد پرداخت‌شده یا باطل‌شده قفل هستند (409). */
    public static function delete($id) {
        $o = wc_get_order((int) $id);
        if (!$o || !$o->get_meta('_wsm_invoice')) {
            return new WP_Error('wsm_not_found', 'فاکتور پیدا نشد.', array('status' => 404));
        }
        $status = self::effective_status($o);
        if (in_array($status, array('paid', 'cancelled'), true) || absint($o->get_meta('_wsm_invoice_finance_id')) > 0 || (bool) $o->get_meta('_wsm_invoice_voided')) {
            return new WP_Error(
                'wsm_invoice_delete_blocked',
                'حذف فیزیکی فاکتور پرداخت‌شده یا ابطال‌شده مجاز نیست؛ برای حفظ تاریخچهٔ حسابداری از ابطال استفاده کنید.',
                array('status' => 409)
            );
        }
        $source_id = absint($o->get_meta('_wsm_source_order_id'));
        if ($source_id > 0) {
            $source = wc_get_order($source_id);
            if ($source && absint($source->get_meta('_wsm_linked_invoice_id')) === (int) $id) {
                $source->delete_meta_data('_wsm_linked_invoice_id');
                $source->save_meta_data();
            }
        }
        $o->delete(true);
        WSM_Activity_Log::log('delete', 'invoice', (int) $id, 'فاکتور INV-' . (int) $id, 'exists', 'deleted', 'success');
        return array('deleted' => true, 'id' => (int) $id);
    }

    /** کپی از یک فاکتور موجود به عنوان پیش‌نویس جدید. */
    public static function copy($id) {
        $o = wc_get_order((int) $id);
        if (!$o || !$o->get_meta('_wsm_invoice')) {
            return new WP_Error('wsm_not_found', 'فاکتور پیدا نشد.', array('status' => 404));
        }
        $input = self::to_input($o);
        $input['status'] = 'draft';
        $new = self::create($input);
        if (!is_wp_error($new)) {
            WSM_Activity_Log::log('copy', 'invoice', $new['id'], 'فاکتور INV-' . $new['id'], 'INV-' . (int) $id, 'draft', 'success');
        }
        return $new;
    }

    public static function duplicate($id) {
        return self::copy($id);
    }

    private static function to_input(WC_Order $o) {
        $items = array();
        foreach ($o->get_items('line_item') as $item) {
            $qty        = max(1, (int) $item->get_quantity());
            $saved_unit = $item->get_meta('_wsm_unit_price', true);
            $unit_price = ($saved_unit !== '' && $saved_unit !== null) ? (float) $saved_unit : ((float) $item->get_subtotal() / $qty);
            $items[] = array(
                'product_id'     => (int) $item->get_product_id(),
                'name'           => $item->get_name(),
                'qty'            => $qty,
                'price'          => $unit_price,
                'discount_type'  => $item->get_meta('_wsm_disc_type', true) ?: 'none',
                'discount_value' => (float) $item->get_meta('_wsm_disc_value', true),
            );
        }
        $tax_fee = 0.0;
        foreach ($o->get_fees() as $fee) {
            if ($fee->get_meta('_wsm_fee_kind') === 'tax') {
                $tax_fee += (float) $fee->get_total();
            }
        }
        $tax_pct = (float) $o->get_meta('_wsm_tax_percent');
        $in = array(
            'recipient'       => self::postal_recipient($o),
            'custom_fields'   => WSM_Util::custom_field_values($o, 'invoices'),
            'buyer'           => array(
                'name'        => trim($o->get_billing_first_name() . ' ' . $o->get_billing_last_name()),
                'mobile'      => $o->get_billing_phone(),
                'email'       => $o->get_billing_email(),
                'address'     => $o->get_billing_address_1(),
                'national_id' => $o->get_meta('_wsm_buyer_national_id'),
            ),
            'items'           => $items,
            'discount'        => array('type' => $o->get_meta('_wsm_discount_type') ?: 'none', 'value' => (float) $o->get_meta('_wsm_discount_value')),
            'tax_percent'     => $tax_pct,
            'shipping_amount' => (float) $o->get_shipping_total(),
            'note'            => $o->get_customer_note(),
        );
        if ($tax_pct <= 0 && $tax_fee > 0) {
            $in['tax'] = $tax_fee;
        }
        return $in;
    }

    public static function format(WC_Order $o) {
        $items     = array();
        $subtotal  = 0.0;
        $line_disc = 0.0;
        $item_tax  = 0.0;
        foreach ($o->get_items('line_item') as $item_id => $item) {
            $pid        = (int) $item->get_product_id();
            $prod       = $item->get_product();
            $img_id     = $pid ? (int) get_post_thumbnail_id($pid) : 0;
            $qty        = max(1, (int) $item->get_quantity());
            $gross      = (float) $item->get_subtotal();
            $net        = (float) $item->get_total();
            $disc_amt   = max(0.0, $gross - $net);
            $saved_unit = $item->get_meta('_wsm_unit_price', true);
            $unit_price = ($saved_unit !== '' && $saved_unit !== null) ? (float) $saved_unit : ($gross / $qty);
            $subtotal  += $gross;
            $line_disc += $disc_amt;
            $item_taxes = $item->get_taxes();
            if (isset($item_taxes['total']) && is_array($item_taxes['total'])) {
                $item_tax += array_sum(array_map('floatval', $item_taxes['total']));
            }
            $img_url = $img_id ? (string) wp_get_attachment_image_url($img_id, 'thumbnail') : '';
            $sku     = $prod ? (string) $prod->get_sku() : (string) $item->get_meta('_wsm_manual_sku');
            $items[] = array(
                'id'             => (int) $item_id,
                'product_id'     => $pid,
                'name'           => $item->get_name(),
                'sku'            => $sku,
                'qty'            => $qty,
                'unit_price'     => $unit_price,
                'price'          => $unit_price,
                'discount_type'  => $item->get_meta('_wsm_disc_type', true) ?: 'none',
                'discount_value' => (float) $item->get_meta('_wsm_disc_value', true),
                'gross'          => $gross,
                'line_subtotal'  => $gross,
                'line_discount'  => $disc_amt,
                'total'          => $net,
                'line_total'     => $net,
                'image_url'      => $img_url,
            );
        }

        $order_disc  = 0.0;
        $tax_fee     = 0.0;
        $has_tax_fee = false;
        foreach ($o->get_fees() as $fee) {
            $kind = $fee->get_meta('_wsm_fee_kind');
            $ftot = (float) $fee->get_total();
            if ($kind === 'discount' || $ftot < 0) {
                $order_disc += abs($ftot);
            } elseif ($kind === 'tax') {
                $has_tax_fee = true;
                $tax_fee    += $ftot;
            }
        }
        $wc_extra_disc = max(0.0, (float) $o->get_discount_total() - $line_disc);
        if ($wc_extra_disc > 0.009 && $order_disc <= 0.009) {
            $order_disc += $wc_extra_disc;
        }

        $tax        = $has_tax_fee ? $tax_fee : ($item_tax + (float) $o->get_shipping_tax());
        $shipping   = (float) $o->get_shipping_total();
        $disc_total = $line_disc + $order_disc;
        $status     = self::effective_status($o);
        $created    = $o->get_date_created();
        $buyer_name = trim($o->get_billing_first_name() . ' ' . $o->get_billing_last_name());
        $phone      = $o->get_billing_phone();

        $src_order_id  = absint($o->get_meta('_wsm_source_order_id'));
        $src_order_num = (string) $o->get_meta('_wsm_source_order_number');
        if ($src_order_id > 0 && $src_order_num === '') {
            $src_order = wc_get_order($src_order_id);
            if ($src_order) {
                $src_order_num = (string) $src_order->get_order_number();
            }
        }

        return array(
            'id'                  => (int) $o->get_id(),
            'number'              => 'INV-' . $o->get_id(),
            'source_order_id'     => $src_order_id,
            'source_order_number' => $src_order_num,
            'club_member_id'      => absint($o->get_meta('_wsm_club_member_id')),
            'club_member_code'    => (string) $o->get_meta('_wsm_club_member_code'),
            'club_card_number'    => (string) $o->get_meta('_wsm_club_card_number'),
            'status'              => $status,
            'status_label'        => self::label($status),
            'is_void'             => ($status === 'cancelled'),
            'is_immutable'        => self::is_immutable($o),
            'voided_at'           => (string) $o->get_meta('_wsm_invoice_voided_at'),
            'void_reason'         => (string) $o->get_meta('_wsm_invoice_void_reason'),
            'finance_id'          => absint($o->get_meta('_wsm_invoice_finance_id')),
            'date'                => wsm_fa_date($created ? $created->getTimestamp() : ''),
            'date_iso'            => $created ? wp_date('Y-m-d', $created->getTimestamp(), wp_timezone()) : '',
            'buyer_name'          => $buyer_name !== '' ? $buyer_name : 'بدون نام',
            'buyer'               => array(
                'name'        => $buyer_name,
                'first_name'  => $o->get_billing_first_name(),
                'last_name'   => $o->get_billing_last_name(),
                'mobile'      => $phone,
                'phone'       => $phone,
                'email'       => $o->get_billing_email(),
                'address'     => $o->get_billing_address_1(),
                'city'        => $o->get_billing_city(),
                'state'       => $o->get_billing_state(),
                'postcode'    => $o->get_billing_postcode(),
                'company'     => $o->get_billing_company(),
                'national_id' => (string) $o->get_meta('_wsm_buyer_national_id'),
            ),
            'recipient'           => self::postal_recipient($o),
            'custom_fields'       => WSM_Util::custom_field_values($o, 'invoices'),
            'items'               => $items,
            'discount'            => array(
                'type'  => $o->get_meta('_wsm_discount_type') ?: 'none',
                'value' => (float) $o->get_meta('_wsm_discount_value'),
            ),
            'discount_type'       => $o->get_meta('_wsm_discount_type') ?: 'none',
            'discount_value'      => (float) $o->get_meta('_wsm_discount_value'),
            'tax_percent'         => (float) $o->get_meta('_wsm_tax_percent'),
            'shipping_amount'     => $shipping,
            'note'                => $o->get_customer_note(),
            'totals'              => array(
                'subtotal'       => $subtotal,
                'line_discount'  => $line_disc,
                'order_discount' => $order_disc,
                'discount_total' => $disc_total,
                'tax'            => $tax,
                'shipping'       => $shipping,
                'total'          => (float) $o->get_total(),
                'total_display'  => wsm_fa_money($o->get_total()),
            ),
            'total_display'       => wsm_fa_money($o->get_total()),
        );
    }

    /** تبدیل تاریخ فیلتر به میلادی YYYY-MM-DD (پشتیبانی از شمسی فارسی/لاتین و میلادی). */
    public static function normalize_filter_date($value) {
        if (!is_scalar($value)) {
            return new WP_Error('wsm_bad_invoice_date', 'تاریخ فاکتور نامعتبر است؛ تاریخ را به‌شکل شمسی مانند ۱۴۰۵/۰۸/۱۴ وارد کنید.', array('status' => 400));
        }
        $raw = trim(sanitize_text_field((string) $value));
        if ($raw === '') {
            return '';
        }
        $digits = strtr($raw, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ));
        if (preg_match('/^(\d{4})(\d{2})(\d{2})$/', $digits, $compact)) {
            $digits = $compact[1] . '/' . $compact[2] . '/' . $compact[3];
        }
        if (preg_match('/^(\d{4})\s*[\/.\-]\s*(\d{1,2})\s*[\/.\-]\s*(\d{1,2})$/', $digits, $parts)) {
            $year  = (int) $parts[1];
            $month = (int) $parts[2];
            $day   = (int) $parts[3];
            if ($year > 1600) {
                if (checkdate($month, $day, $year)) {
                    return sprintf('%04d-%02d-%02d', $year, $month, $day);
                }
            } elseif ($year >= 1300 && $year <= 1500 && class_exists('WSM_Expiry')) {
                $jalali = WSM_Expiry::normalize_input($digits);
                if ($jalali !== false && $jalali !== '') {
                    return $jalali;
                }
            }
        }
        return new WP_Error('wsm_bad_invoice_date', 'تاریخ فاکتور نامعتبر است؛ تاریخ را به‌شکل شمسی مانند ۱۴۰۵/۰۸/۱۴ وارد کنید.', array('status' => 400));
    }

    private static function status_matches_filter(WC_Order $o, $filter_status) {
        $eff = self::effective_status($o);
        if ($filter_status === 'unpaid') {
            return in_array($eff, array('unpaid', 'draft', 'sent'), true);
        }
        return $eff === $filter_status;
    }

    /** جستجوی دقیق شماره فاکتور، شماره سفارش، و نام کامل/موبایل/ایمیل مشتری بدون تداخل فازی اعداد. */
    private static function search_matches_invoice(WC_Order $order, $search) {
        $raw = trim((string) $search);
        if ($raw === '') {
            return true;
        }
        $latin_raw   = trim(self::latinize_digits($raw));
        $invoice_id  = (int) $order->get_id();
        $inv_num     = 'INV-' . $invoice_id;
        $src_id      = absint($order->get_meta('_wsm_source_order_id'));
        $src_num_raw = trim((string) $order->get_meta('_wsm_source_order_number'));
        if ($src_num_raw === '' && $src_id > 0) {
            $src_num_raw = (string) $src_id;
        }
        $src_num_lat = self::latinize_digits($src_num_raw);

        // ۱) جستجوی صریح با پیشوند INV- یا فاکتور
        if (preg_match('/^(?:inv[-\s#]*|فاکتور[-\s#]*)(\d+)$/iu', $latin_raw, $m)) {
            return $invoice_id === (int) $m[1];
        }
        // ۲) جستجوی صریح با پیشوند سفارش یا order
        if (preg_match('/^(?:سفارش[-\s#]*|order[-\s#]*)(\d+)$/iu', $latin_raw, $m)) {
            $wanted       = ltrim($m[1], '0') ?: '0';
            $cand_src_num = ltrim($src_num_lat, '0') ?: $src_num_lat;
            return ($src_id > 0 && $src_id === (int) $m[1]) || ($src_num_lat !== '' && $cand_src_num === $wanted);
        }
        // ۳) جستجو با #123
        if (preg_match('/^#\s*(\d+)$/u', $latin_raw, $m)) {
            $n = (int) $m[1];
            return $invoice_id === $n
                || ($src_id > 0 && $src_id === $n)
                || ($src_num_lat !== '' && $src_num_lat === $m[1]);
        }
        // ۴) جستجوی کاملاً عددی (بدون Levenshtein فازی تا شناسه‌های مجاور تداخل نکنند)
        $only_digits = preg_replace('/[\s\-()+]+/u', '', $latin_raw);
        if ($only_digits !== '' && ctype_digit($only_digits)) {
            $n = (int) $only_digits;
            if ($invoice_id === $n) { return true; }
            if ($src_id > 0 && $src_id === $n) { return true; }
            if ($src_num_lat !== '' && $src_num_lat === $only_digits) { return true; }
            if (strlen($only_digits) >= 4) {
                $phone_digits = preg_replace('/\D+/', '', self::latinize_digits($order->get_billing_phone()));
                if ($phone_digits !== '' && strpos($phone_digits, $only_digits) !== false) {
                    return true;
                }
            }
            return false;
        }

        // ۵) جستجوی متنی / ترکیبی (نام کوچک + نام خانوادگی، شرکت، ایمیل، یادداشت، کد ورزشکار)
        $buyer_full = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        $recip      = self::postal_recipient($order);
        $combined   = implode(' ', array_filter(array(
            $inv_num,
            $src_num_raw,
            $buyer_full,
            $order->get_billing_company(),
            $order->get_billing_phone(),
            $order->get_billing_email(),
            isset($recip['name']) ? $recip['name'] : '',
            (string) $order->get_meta('_wsm_club_member_code'),
            $order->get_customer_note(),
        ), static function ($v) { return (string) $v !== ''; }));

        if (class_exists('WSM_Persian_Normalizer')) {
            $norm_query = WSM_Persian_Normalizer::normalize($raw);
            $norm_hay   = WSM_Persian_Normalizer::normalize($combined);
            $tokens     = preg_split('/\s+/u', trim($norm_query), -1, PREG_SPLIT_NO_EMPTY);
            if (!empty($tokens)) {
                $ok = true;
                foreach ($tokens as $tok) {
                    if ($tok !== '' && mb_strpos($norm_hay, $tok) === false) {
                        $ok = false;
                        break;
                    }
                }
                if ($ok) { return true; }
            }
        }

        $q_lower = mb_strtolower($latin_raw);
        $h_lower = mb_strtolower(self::latinize_digits($combined));
        $tokens  = preg_split('/\s+/u', $q_lower, -1, PREG_SPLIT_NO_EMPTY);
        if (empty($tokens)) { return false; }
        foreach ($tokens as $tok) {
            if (mb_strpos($h_lower, $tok) === false) {
                return false;
            }
        }
        return true;
    }

    /** فهرست فاکتورها با صفحه‌بندی، فیلتر وضعیت، بازهٔ تاریخ شمسی و جستجوی دقیق. */
    public static function list($args = array()) {
        $page       = max(1, (int) (isset($args['page']) ? $args['page'] : 1));
        $per_page   = max(1, min(50, (int) (isset($args['per_page']) ? $args['per_page'] : 20)));
        $raw_status = isset($args['status']) && is_scalar($args['status']) ? trim((string) $args['status']) : '';
        $status     = $raw_status !== '' ? self::normalize_status_key($raw_status) : '';
        if ($status !== '' && !in_array($status, self::STATUSES, true)) {
            return new WP_Error('wsm_bad_status', 'وضعیت فاکتور نامعتبر است.', array('status' => 400));
        }

        $date_from = self::normalize_filter_date(isset($args['date_from']) ? $args['date_from'] : '');
        if (is_wp_error($date_from)) { return $date_from; }
        $date_to = self::normalize_filter_date(isset($args['date_to']) ? $args['date_to'] : '');
        if (is_wp_error($date_to)) { return $date_to; }
        if ($date_from !== '' && $date_to !== '' && $date_from > $date_to) {
            return new WP_Error('wsm_bad_invoice_date_range', 'تاریخ شروع نباید بعد از تاریخ پایان باشد.', array('status' => 400));
        }

        $search = isset($args['search']) && is_scalar($args['search'])
            ? WSM_Util::clean_text((string) $args['search'], 100)
            : '';

        $tz      = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
        $from_ts = null;
        $to_ts   = null;
        if ($date_from !== '') {
            $dt_from = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $date_from . ' 00:00:00', $tz);
            if ($dt_from instanceof DateTimeImmutable) { $from_ts = $dt_from->getTimestamp(); }
        }
        if ($date_to !== '') {
            $dt_to = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $date_to . ' 23:59:59', $tz);
            if ($dt_to instanceof DateTimeImmutable) { $to_ts = $dt_to->getTimestamp(); }
        }

        $invoice_ids = WSM_Util::order_ids_with_meta('_wsm_invoice', '1');
        $query = array(
            'type'     => 'shop_order',
            'limit'    => $per_page,
            'page'     => $page,
            'paginate' => true,
            'orderby'  => 'date',
            'order'    => 'DESC',
            'return'   => 'objects',
            'post__in' => $invoice_ids ? $invoice_ids : array(0),
        );
        if ($from_ts !== null && $to_ts !== null) {
            $query['date_created'] = $from_ts . '...' . $to_ts;
        } elseif ($from_ts !== null) {
            $query['date_created'] = '>=' . $from_ts;
        } elseif ($to_ts !== null) {
            $query['date_created'] = '<=' . $to_ts;
        }

        if ($status === '' && $search === '' && $from_ts === null && $to_ts === null) {
            $result = wc_get_orders($query);
            if (is_wp_error($result)) { return $result; }
            $orders = is_object($result) && isset($result->orders) ? (array) $result->orders : (array) $result;
            $items  = array();
            foreach ($orders as $order) {
                if ($order instanceof WC_Order && $order->get_meta('_wsm_invoice')) {
                    $items[] = self::format($order);
                }
            }
            $total       = is_object($result) && isset($result->total) ? (int) $result->total : count($items);
            $total_pages = is_object($result) && isset($result->max_num_pages)
                ? max(1, (int) $result->max_num_pages)
                : max(1, (int) ceil($total / $per_page));
            return array('items' => $items, 'total' => $total, 'total_pages' => $total_pages, 'page' => $page);
        }

        $scan_limit     = 50;
        $query['limit'] = $scan_limit;
        $query['page']  = 1;
        $offset         = ($page - 1) * $per_page;
        $items          = array();
        $total          = 0;
        $scan_page      = 1;
        $max_scan_pages = 100;

        while (true) {
            if ($scan_page > $max_scan_pages) {
                return new WP_Error('wsm_invoice_filter_too_large', 'فیلتر فعلی بیش از ۵۰۰۰ فاکتور را بررسی می‌کند؛ لطفاً فیلتر دقیق‌تری انتخاب کنید.', array('status' => 400));
            }
            $query['page'] = $scan_page;
            $result = wc_get_orders($query);
            if (is_wp_error($result)) { return $result; }
            $has_pagination = is_object($result) && isset($result->orders);
            $orders         = $has_pagination ? (array) $result->orders : (array) $result;
            $max_pages      = $has_pagination && isset($result->max_num_pages)
                ? max(1, (int) $result->max_num_pages)
                : ($scan_page + (count($orders) >= $scan_limit ? 1 : 0));
            if ($max_pages > $max_scan_pages) {
                return new WP_Error('wsm_invoice_filter_too_large', 'فیلتر فعلی بیش از ۵۰۰۰ فاکتور را بررسی می‌کند؛ لطفاً فیلتر دقیق‌تری انتخاب کنید.', array('status' => 400));
            }

            foreach ($orders as $order) {
                if (!$order instanceof WC_Order || !$order->get_meta('_wsm_invoice')) {
                    continue;
                }
                $created = $order->get_date_created();
                $ts      = $created ? $created->getTimestamp() : 0;
                if ($from_ts !== null && $ts < $from_ts) { continue; }
                if ($to_ts !== null && $ts > $to_ts) { continue; }
                if ($status !== '' && !self::status_matches_filter($order, $status)) { continue; }
                if ($search !== '' && !self::search_matches_invoice($order, $search)) { continue; }

                if ($total >= $offset && count($items) < $per_page) {
                    $items[] = self::format($order);
                }
                $total++;
            }
            if ($scan_page >= $max_pages) {
                break;
            }
            $scan_page++;
        }

        return array(
            'items'       => $items,
            'total'       => $total,
            'total_pages' => $total > 0 ? max(1, (int) ceil($total / $per_page)) : 0,
            'page'        => $page,
        );
    }

    public static function get($id) {
        $order = wc_get_order((int) $id);
        if (!$order || !$order->get_meta('_wsm_invoice')) {
            return new WP_Error('wsm_not_found', 'فاکتور پیدا نشد.', array('status' => 404));
        }
        return self::format($order);
    }

    /** تولید HTML قابل چاپ برای فاکتور تکی. */
    public static function render_html($id, $template_type = 'invoice') {
        if ($template_type === 'label') {
            return self::render_label($id);
        }
        $order = wc_get_order((int) $id);
        if (!$order || !$order->get_meta('_wsm_invoice')) {
            return new WP_Error('wsm_not_found', 'فاکتور پیدا نشد.', array('status' => 404));
        }
        $template = WSM_PATH . 'templates/invoice-print.php';
        if (!is_readable($template)) {
            return new WP_Error('wsm_template_missing', 'قالب چاپ فاکتور پیدا نشد.', array('status' => 500));
        }
        $invoice = self::format($order);
        $store   = WSM_Util::settings();
        if (empty($store['store_name'])) {
            $store['store_name'] = get_bloginfo('name');
        }
        $barcode_svg = self::svg_code128($invoice['number']);
        $qr_payload  = $invoice['number'] . '|' . ($invoice['source_order_number'] !== '' ? ('ORD-' . $invoice['source_order_number']) : 'MANUAL') . '|' . $invoice['totals']['total'] . '|' . $invoice['status'];
        $qr_svg      = self::svg_qr($qr_payload);
        ob_start();
        include $template;
        return (string) ob_get_clean();
    }

    /** تولید HTML یکپارچه برای چاپ گروهی چند فاکتور انتخاب‌شده. */
    public static function render_batch_html($ids) {
        if (!is_array($ids)) {
            return new WP_Error('wsm_bad_ids', 'فهرست شناسهٔ فاکتورها معتبر نیست.', array('status' => 400));
        }
        $clean_ids = array_values(array_unique(array_filter(array_map('absint', $ids))));
        if (empty($clean_ids)) {
            return new WP_Error('wsm_empty_ids', 'حداقل یک فاکتور برای چاپ گروهی انتخاب کنید.', array('status' => 400));
        }
        if (count($clean_ids) > 50) {
            return new WP_Error('wsm_too_many_ids', 'حداکثر ۵۰ فاکتور در هر نوبت چاپ گروهی قابل انتخاب است.', array('status' => 400));
        }
        $template = WSM_PATH . 'templates/invoice-print.php';
        if (!is_readable($template)) {
            return new WP_Error('wsm_template_missing', 'قالب چاپ فاکتور پیدا نشد.', array('status' => 500));
        }
        $batch_invoices = array();
        foreach ($clean_ids as $id) {
            $inv = self::get($id);
            if (is_wp_error($inv)) { return $inv; }
            $batch_invoices[] = $inv;
        }
        $store = WSM_Util::settings();
        if (empty($store['store_name'])) {
            $store['store_name'] = get_bloginfo('name');
        }
        $batch_mode = true;
        $invoice    = $batch_invoices[0];
        ob_start();
        include $template;
        return (string) ob_get_clean();
    }

    /** تولید سند چاپ مستقل برای برچسب پستی ۱۰۰×۱۵۰ میلی‌متر به همراه بارکد SVG. */
    public static function render_label($id) {
        $order = wc_get_order((int) $id);
        if (!$order || !$order->get_meta('_wsm_invoice')) {
            return new WP_Error('wsm_not_found', 'فاکتور پیدا نشد.', array('status' => 404));
        }
        $template = WSM_PATH . 'templates/postal-label.php';
        if (!is_readable($template)) {
            return new WP_Error('wsm_label_template_missing', 'قالب برچسب پستی پیدا نشد.', array('status' => 500));
        }
        $invoice  = self::format($order);
        $settings = WSM_Util::settings();
        $sender   = array(
            'name'      => (string) $settings['postal_sender_name'],
            'company'   => (string) $settings['postal_sender_company'],
            'phone'     => (string) $settings['postal_sender_phone'],
            'email'     => (string) $settings['postal_sender_email'],
            'address_1' => (string) $settings['postal_sender_address_1'],
            'address_2' => (string) $settings['postal_sender_address_2'],
            'city'      => (string) $settings['postal_sender_city'],
            'state'     => (string) $settings['postal_sender_state'],
            'postcode'  => (string) $settings['postal_sender_postcode'],
            'country'   => (string) $settings['postal_sender_country'],
        );
        if ($sender['name'] === '') {
            $sender['name'] = (string) $settings['store_name'];
        }
        if ($sender['company'] === '') {
            $sender['company'] = (string) $settings['store_name'];
        }
        $barcode_svg = self::svg_code128($invoice['number'], 32);
        ob_start();
        include $template;
        return (string) ob_get_clean();
    }

    /** تولید بارکد استاندارد ISO/IEC 15417 Code-128B به‌صورت SVG بدون وابستگی خارجی. */
    public static function svg_code128($text, $height = 40) {
        static $patterns = array(
            '212222','222122','222221','121223','121322','131222','122213','122312','132212','221213',
            '221312','231212','112232','122132','122231','113222','123122','123221','223211','221132',
            '221231','213212','223112','312131','311222','321122','321221','312212','322112','322211',
            '212123','212321','232121','111323','131123','131321','112313','132113','132311','211313',
            '231113','231311','112133','112331','132131','113123','113321','133121','313121','211331',
            '231131','213113','213311','213131','311123','311321','331121','312113','312311','332111',
            '314111','221411','431111','111224','111422','121124','121421','141122','141221','112214',
            '112412','122114','122411','142112','142211','241211','221114','413111','241112','134111',
            '111242','121142','121241','114212','124112','124211','411212','421112','421211','212141',
            '214121','412121','111143','111341','131141','114113','114311','411113','411311','113141',
            '114131','311141','411131','211412','211214','211232','2331112',
        );
        $clean = preg_replace('/[^\x20-\x7E]/', '', self::latinize_digits((string) $text));
        if ($clean === '') { $clean = 'INV-0'; }
        $codes = array(104);
        $sum   = 104;
        $len   = strlen($clean);
        for ($i = 0; $i < $len; $i++) {
            $val     = ord($clean[$i]) - 32;
            $codes[] = $val;
            $sum    += $val * ($i + 1);
        }
        $codes[] = $sum % 103;
        $codes[] = 106;

        $x     = 10;
        $rects = array();
        foreach ($codes as $code) {
            $pat  = $patterns[$code];
            $plen = strlen($pat);
            for ($j = 0; $j < $plen; $j++) {
                $w = (int) $pat[$j] * 2;
                if ($j % 2 === 0) {
                    $rects[] = sprintf('<rect x="%d" y="2" width="%d" height="%d" fill="#0f172a"/>', $x, $w, (int) $height);
                }
                $x += $w;
            }
        }
        $total_w = $x + 10;
        $total_h = (int) $height + 18;
        $label   = htmlspecialchars($clean, ENT_QUOTES, 'UTF-8');
        return sprintf(
            '<svg class="invoice-barcode" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-label="بارکد %s"><rect width="100%%" height="100%%" fill="#ffffff"/>%s<text x="%d" y="%d" text-anchor="middle" font-family="monospace" font-size="11" fill="#0f172a">%s</text></svg>',
            $total_w,
            $total_h,
            min(210, $total_w),
            $total_h,
            $label,
            implode('', $rects),
            (int) round($total_w / 2),
            (int) $height + 14,
            $label
        );
    }

    /** تولید کیوآرکد استاندارد ISO/IEC 18004 (نسخه ۱ تا ۴، سطح L، ماسک ۰) به‌صورت SVG خالص. */
    public static function svg_qr($payload, $pixel_size = 74) {
        $bytes = array_values(unpack('C*', substr((string) $payload, 0, 76)));
        $blen  = count($bytes);
        $versions = array(
            1 => array('size' => 21, 'data' => 19, 'ec' => 7,  'align' => array()),
            2 => array('size' => 25, 'data' => 34, 'ec' => 10, 'align' => array(6, 18)),
            3 => array('size' => 29, 'data' => 55, 'ec' => 15, 'align' => array(6, 22)),
            4 => array('size' => 33, 'data' => 80, 'ec' => 20, 'align' => array(6, 26)),
        );
        $ver = 4;
        foreach ($versions as $v => $spec) {
            if ($blen + 2 <= $spec['data']) {
                $ver = $v;
                break;
            }
        }
        $spec = $versions[$ver];
        $size = $spec['size'];

        $bits = '0100' . str_pad(decbin($blen), 8, '0', STR_PAD_LEFT);
        foreach ($bytes as $b) {
            $bits .= str_pad(decbin($b), 8, '0', STR_PAD_LEFT);
        }
        $max_bits = $spec['data'] * 8;
        $bits .= str_repeat('0', min(4, max(0, $max_bits - strlen($bits))));
        while (strlen($bits) % 8 !== 0) { $bits .= '0'; }
        $data_cw = array();
        for ($i = 0; $i < strlen($bits); $i += 8) {
            $data_cw[] = bindec(substr($bits, $i, 8));
        }
        $pads = array(0xEC, 0x11);
        $pi   = 0;
        while (count($data_cw) < $spec['data']) {
            $data_cw[] = $pads[$pi % 2];
            $pi++;
        }

        $exp = array_fill(0, 512, 0);
        $log = array_fill(0, 256, 0);
        $x = 1;
        for ($i = 0; $i < 255; $i++) {
            $exp[$i] = $x;
            $log[$x] = $i;
            $x <<= 1;
            if ($x & 0x100) { $x ^= 0x11D; }
        }
        for ($i = 255; $i < 512; $i++) { $exp[$i] = $exp[$i - 255]; }
        $gf_mul = static function ($a, $b) use ($exp, $log) {
            return ($a === 0 || $b === 0) ? 0 : $exp[$log[$a] + $log[$b]];
        };
        $gen = array(1);
        for ($i = 0; $i < $spec['ec']; $i++) {
            $next = array_fill(0, count($gen) + 1, 0);
            for ($j = 0; $j < count($gen); $j++) {
                $next[$j]     ^= $gen[$j];
                $next[$j + 1] ^= $gf_mul($gen[$j], $exp[$i]);
            }
            $gen = $next;
        }
        $ec_cw = array_fill(0, $spec['ec'], 0);
        foreach ($data_cw as $b) {
            $factor  = $b ^ array_shift($ec_cw);
            $ec_cw[] = 0;
            if ($factor !== 0) {
                for ($j = 0; $j < $spec['ec']; $j++) {
                    $ec_cw[$j] ^= $gf_mul($gen[$j + 1], $factor);
                }
            }
        }
        $all_cw = array_merge($data_cw, $ec_cw);

        $grid = array_fill(0, $size, array_fill(0, $size, null));
        $used = array_fill(0, $size, array_fill(0, $size, false));
        $place_finder = static function ($r0, $c0) use (&$grid, &$used, $size) {
            for ($dr = -1; $dr <= 7; $dr++) {
                for ($dc = -1; $dc <= 7; $dc++) {
                    $r = $r0 + $dr;
                    $c = $c0 + $dc;
                    if ($r < 0 || $r >= $size || $c < 0 || $c >= $size) { continue; }
                    $in_outer = ($dr >= 0 && $dr <= 6 && $dc >= 0 && $dc <= 6);
                    $on_ring  = ($dr === 0 || $dr === 6 || $dc === 0 || $dc === 6);
                    $in_core  = ($dr >= 2 && $dr <= 4 && $dc >= 2 && $dc <= 4);
                    $grid[$r][$c] = ($in_outer && ($on_ring || $in_core)) ? 1 : 0;
                    $used[$r][$c] = true;
                }
            }
        };
        $place_finder(0, 0);
        $place_finder(0, $size - 7);
        $place_finder($size - 7, 0);

        if (!empty($spec['align'])) {
            $ac = $spec['align'];
            foreach ($ac as $ar) {
                foreach ($ac as $ac_col) {
                    if ($used[$ar][$ac_col]) { continue; }
                    for ($dr = -2; $dr <= 2; $dr++) {
                        for ($dc = -2; $dc <= 2; $dc++) {
                            $dark = (abs($dr) === 2 || abs($dc) === 2 || ($dr === 0 && $dc === 0));
                            $grid[$ar + $dr][$ac_col + $dc] = $dark ? 1 : 0;
                            $used[$ar + $dr][$ac_col + $dc] = true;
                        }
                    }
                }
            }
        }
        for ($i = 8; $i < $size - 8; $i++) {
            if (!$used[6][$i]) { $grid[6][$i] = ($i % 2 === 0) ? 1 : 0; $used[6][$i] = true; }
            if (!$used[$i][6]) { $grid[$i][6] = ($i % 2 === 0) ? 1 : 0; $used[$i][6] = true; }
        }
        for ($i = 0; $i < 9; $i++) {
            if ($i < $size) { $used[8][$i] = true; $used[$i][8] = true; }
        }
        for ($i = 0; $i < 8; $i++) {
            $used[8][$size - 1 - $i] = true;
            $used[$size - 1 - $i][8] = true;
        }
        $grid[$size - 8][8] = 1;
        $used[$size - 8][8] = true;

        $stream = '';
        foreach ($all_cw as $cw) {
            $stream .= str_pad(decbin($cw), 8, '0', STR_PAD_LEFT);
        }
        $bit_idx = 0;
        $up      = true;
        for ($col = $size - 1; $col > 0; $col -= 2) {
            if ($col === 6) { $col--; }
            for ($step = 0; $step < $size; $step++) {
                $row = $up ? ($size - 1 - $step) : $step;
                for ($dx = 0; $dx < 2; $dx++) {
                    $c = $col - $dx;
                    if ($used[$row][$c]) { continue; }
                    $bit = ($bit_idx < strlen($stream)) ? ((int) $stream[$bit_idx]) : 0;
                    $bit_idx++;
                    if (($row + $c) % 2 === 0) { $bit ^= 1; }
                    $grid[$row][$c] = $bit;
                }
            }
            $up = !$up;
        }

        $fmt = 0x77C4;
        $f1_coords = array(
            array(8,0), array(8,1), array(8,2), array(8,3), array(8,4), array(8,5),
            array(8,7), array(8,8), array(7,8), array(5,8), array(4,8), array(3,8),
            array(2,8), array(1,8), array(0,8),
        );
        for ($i = 0; $i < 15; $i++) {
            $bit = ($fmt >> (14 - $i)) & 1;
            $grid[$f1_coords[$i][0]][$f1_coords[$i][1]] = $bit;
            if ($i < 7) {
                $grid[$size - 1 - $i][8] = $bit;
            } else {
                $grid[8][$size - 15 + $i] = $bit;
            }
        }

        $quiet = 2;
        $vb    = $size + $quiet * 2;
        $paths = array();
        for ($r = 0; $r < $size; $r++) {
            for ($c = 0; $c < $size; $c++) {
                if (!empty($grid[$r][$c])) {
                    $paths[] = sprintf('M%d %dh1v1h-1z', $c + $quiet, $r + $quiet);
                }
            }
        }
        $label = htmlspecialchars((string) $payload, ENT_QUOTES, 'UTF-8');
        return sprintf(
            '<svg class="invoice-qr" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" shape-rendering="crispEdges" role="img" aria-label="کیوآرکد %s"><rect width="100%%" height="100%%" fill="#ffffff"/><path d="%s" fill="#0f172a"/></svg>',
            $vb,
            $vb,
            (int) $pixel_size,
            (int) $pixel_size,
            $label,
            implode('', $paths)
        );
    }
}
