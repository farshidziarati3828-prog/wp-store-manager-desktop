//! Phase 18 PROTOTYPE ONLY. Not compiled, linked, or enabled.
//!
//! OS inventory is metadata, NOT a usable device connection, fingerprint
//! match, attendance event, proof of absence, or a universal discovery guarantee.
//! This draft deliberately returns accessible=false for every inventory record.
//!
//! Integration requires review of the existing Tauri sidecar, permissions, local
//! key handling, Windows process lifecycle, serialization, UI and packaging.

use serde::Serialize;
use serde_json::Value;
use std::fs::{self, OpenOptions};
use std::io::{Read, Write};
use std::net::{SocketAddr, TcpStream};
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::{Arc, Mutex};
use std::sync::atomic::{AtomicBool, Ordering};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

const COMMAND_TIMEOUT: Duration = Duration::from_secs(5);
const MAX_OUTPUT: usize = 1024 * 1024;

#[derive(Clone, Debug, Serialize)]
pub struct Device {
    pub name: String,
    #[serde(rename = "type")]
    pub kind: String,
    pub source: String,
    pub accessible: bool,
    pub reason: String,
    pub unique_id: String,
    pub is_default: bool,
    pub port: String,
    pub vendor_id: String,
    pub product_id: String,
    pub port_path: String,
    pub ambiguous: bool,
}
pub type Printer = Device;
pub type ComPort = Device;
pub type UsbDevice = Device;
pub type Fingerprint = Device;

#[derive(Clone, Debug, Serialize)]
pub struct ProbeReport {
    pub items: Vec<Device>,
    pub warnings: Vec<String>,
}

fn device(name: String, kind: &str, unique_id: String) -> Device {
    Device {
        name: name.chars().take(160).collect(),
        kind: kind.into(),
        source: "os_probe_rust".into(),
        accessible: false,
        reason: "unknown".into(),
        unique_id: unique_id.chars().take(512).collect(),
        is_default: false,
        port: String::new(),
        vendor_id: String::new(),
        product_id: String::new(),
        port_path: String::new(),
        ambiguous: false,
    }
}

fn log_supervisor(event: &str) {
    // Do not put device names, paths, command output, credentials or stderr here.
    let home = std::env::var_os(if cfg!(windows) { "USERPROFILE" } else { "HOME" });
    if let Some(home) = home {
        let directory = PathBuf::from(home).join(".wsm").join("logs");
        if fs::create_dir_all(&directory).is_ok() {
            if let Ok(mut file) = OpenOptions::new().create(true).append(true)
                .open(directory.join("bridge-supervisor.log")) {
                let _ = writeln!(file, "{}", event);
            }
        }
    }
}

fn read_bounded(mut reader: impl Read) -> (Vec<u8>, bool) {
    let mut output = Vec::new();
    let mut buffer = [0_u8; 8192];
    let mut truncated = false;
    loop {
        match reader.read(&mut buffer) {
            Ok(0) | Err(_) => break,
            Ok(n) => {
                let room = MAX_OUTPUT.saturating_sub(output.len());
                output.extend_from_slice(&buffer[..n.min(room)]);
                if n > room { truncated = true; }
            }
        }
    }
    (output, truncated)
}

// Only compile-time command names/arguments are passed by callers below. The
// code never invokes a shell or interpolates a device name into a command.
fn run_fixed(program: &str, args: &[&str]) -> Result<String, &'static str> {
    let mut child = Command::new(program).args(args)
        .stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped())
        .spawn().map_err(|_| "spawn_failed")?;
    let out = child.stdout.take().ok_or("stdout_missing")?;
    let err = child.stderr.take().ok_or("stderr_missing")?;
    let out_thread = thread::spawn(move || read_bounded(out));
    let err_thread = thread::spawn(move || read_bounded(err));
    let deadline = Instant::now() + COMMAND_TIMEOUT;
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break Some(status),
            Ok(None) if Instant::now() < deadline => thread::sleep(Duration::from_millis(40)),
            _ => { let _ = child.kill(); let _ = child.wait(); break None; }
        }
    };
    let (stdout, truncated) = out_thread.join().unwrap_or_default();
    let _ = err_thread.join(); // stderr is deliberately not logged verbatim.
    match status {
        Some(s) if s.success() && !truncated => Ok(String::from_utf8_lossy(&stdout).into_owned()),
        Some(_) => Err("command_failed_or_output_truncated"),
        None => Err("command_timeout_or_wait_error"),
    }
}

#[cfg(target_os = "windows")]
fn powershell(script: &'static str) -> Result<String, &'static str> {
    run_fixed("powershell.exe", &["-NoProfile", "-NonInteractive", "-Command", script])
}

#[cfg(target_os = "windows")]
fn json_rows(text: &str) -> Vec<Value> {
    match serde_json::from_str::<Value>(text) {
        Ok(Value::Array(rows)) => rows,
        Ok(Value::Object(row)) => vec![Value::Object(row)],
        _ => Vec::new(),
    }
}

#[cfg(target_os = "windows")]
fn text_field(row: &Value, key: &str) -> String {
    row.get(key).and_then(Value::as_str).unwrap_or("").chars().take(512).collect()
}

#[cfg(target_os = "windows")]
fn vid_pid(instance: &str) -> (String, String) {
    let upper = instance.to_ascii_uppercase();
    let part = |prefix: &str| -> String {
        upper.find(prefix).and_then(|i| upper.get(i + prefix.len()..i + prefix.len() + 4))
            .filter(|v| v.chars().all(|c| c.is_ascii_hexdigit()))
            .unwrap_or("").to_ascii_lowercase()
    };
    (part("VID_"), part("PID_"))
}

fn printer_probe() -> Result<Vec<Printer>, &'static str> {
    #[cfg(target_os = "windows")]
    {
        const SCRIPT: &str = "$d=Get-CimInstance Win32_Printer | Where-Object Default | Select-Object -ExpandProperty Name; Get-Printer | ForEach-Object { [pscustomobject]@{Name=$_.Name;PortName=$_.PortName;Default=($_.Name -eq $d)} } | ConvertTo-Json -Compress";
        let output = powershell(SCRIPT)?;
        return Ok(json_rows(&output).into_iter().filter_map(|row| {
            let name = text_field(&row, "Name");
            if name.is_empty() { return None; }
            let mut d = device(name.clone(), "printer", format!("printer:{}", name));
            d.port = text_field(&row, "PortName");
            d.is_default = row.get("Default").and_then(Value::as_bool).unwrap_or(false);
            Some(d)
        }).collect());
    }
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    {
        let status = run_fixed("lpstat", &["-p", "-d"])?;
        let ports = run_fixed("lpstat", &["-v"])?;
        let default = status.lines().find_map(|line| line.strip_prefix("system default destination: "))
            .unwrap_or("").trim();
        let mut items = Vec::new();
        for line in status.lines() {
            if let Some(rest) = line.strip_prefix("printer ") {
                if let Some(name) = rest.split_whitespace().next() {
                    let mut d = device(name.into(), "printer", format!("printer:{}", name));
                    d.is_default = name == default;
                    let prefix = format!("device for {}: ", name);
                    d.port = ports.lines().find_map(|l| l.strip_prefix(&prefix)).unwrap_or("")
                        .chars().take(255).collect();
                    items.push(d);
                }
            }
        }
        return Ok(items);
    }
    #[allow(unreachable_code)]
    Err("unsupported_os")
}

fn com_probe() -> Result<Vec<ComPort>, &'static str> {
    #[cfg(target_os = "windows")]
    {
        let output = powershell("[System.IO.Ports.SerialPort]::GetPortNames() | ConvertTo-Json -Compress")?;
        let parsed: Value = serde_json::from_str(&output).unwrap_or(Value::Null);
        let names: Vec<String> = match parsed {
            Value::String(s) => vec![s],
            Value::Array(v) => v.into_iter().filter_map(|x| x.as_str().map(str::to_owned)).collect(),
            _ => Vec::new(),
        };
        return Ok(names.into_iter().map(|name| {
            let mut d = device(name.clone(), "com", format!("com:{}", name)); d.port = name; d
        }).collect());
    }
    #[cfg(target_os = "linux")]
    {
        let mut devices = Vec::new();
        for entry in fs::read_dir("/dev").map_err(|_| "read_dev_failed")?.flatten() {
            let name = entry.file_name().to_string_lossy().into_owned();
            if name.starts_with("ttyUSB") || name.starts_with("ttyACM") {
                let port = format!("/dev/{}", name);
                let mut d = device(port.clone(), "com", format!("com:{}", port)); d.port = port; devices.push(d);
            }
        }
        devices.sort_by(|a,b| a.port.cmp(&b.port));
        return Ok(devices);
    }
    #[allow(unreachable_code)]
    Err("unsupported_os")
}

#[cfg(target_os = "linux")]
fn sysfs_path(bus: u32, address: u32) -> String {
    if let Ok(entries) = fs::read_dir("/sys/bus/usb/devices") {
        for entry in entries.flatten() {
            let path = entry.path();
            let read_num = |field: &str| fs::read_to_string(path.join(field)).ok()
                .and_then(|s| s.trim().parse::<u32>().ok());
            if read_num("busnum") == Some(bus) && read_num("devnum") == Some(address) {
                if let Ok(port) = fs::read_to_string(path.join("devpath")) {
                    let port = port.trim();
                    if port != "0" && !port.is_empty() && port.chars().all(|c| c.is_ascii_digit() || c == '.') {
                        return format!("{}-{}", bus, port);
                    }
                }
            }
        }
    }
    String::new()
}

fn usb_probe() -> Result<Vec<UsbDevice>, &'static str> {
    #[cfg(target_os = "windows")]
    {
        const SCRIPT: &str = "$d=Get-PnpDevice -PresentOnly | Where-Object { $_.Class -in @('USB','HIDClass') }; $d | ForEach-Object { $p=Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName 'DEVPKEY_Device_LocationPaths' -ErrorAction SilentlyContinue; [pscustomobject]@{Name=$_.FriendlyName;InstanceId=$_.InstanceId;Location=($p.Data -join '|')} } | ConvertTo-Json -Compress";
        let output = powershell(SCRIPT)?;
        return Ok(json_rows(&output).into_iter().enumerate().filter_map(|(i,row)| {
            let instance = text_field(&row, "InstanceId");
            let (vid,pid) = vid_pid(&instance);
            if vid.is_empty() || pid.is_empty() { return None; }
            let path = text_field(&row, "Location");
            let ambiguous = path.is_empty();
            let unique = if ambiguous { format!("[ambiguous]:{}:{}:{}", vid,pid,i) }
                         else { format!("usb:{}:{}:{}",vid,pid,path) };
            let mut d = device(text_field(&row,"Name"),"usb_hid",unique);
            d.vendor_id=vid; d.product_id=pid; d.port_path=path; d.ambiguous=ambiguous; Some(d)
        }).collect());
    }
    #[cfg(target_os = "linux")]
    {
        let output = run_fixed("lsusb", &["-v"])?;
        let mut items = Vec::new();
        for line in output.lines() {
            // Example: Bus 001 Device 003: ID 1234:5678 [TEST] scanner
            let words: Vec<&str> = line.split_whitespace().collect();
            if words.len() < 6 || words[0] != "Bus" || words[2] != "Device" || words[4] != "ID" { continue; }
            let bus = words[1].parse::<u32>().unwrap_or(0);
            let address = words[3].trim_end_matches(':').parse::<u32>().unwrap_or(0);
            let Some((vid,pid)) = words[5].split_once(':') else { continue; };
            if vid.len()!=4 || pid.len()!=4 || !vid.chars().chain(pid.chars()).all(|c| c.is_ascii_hexdigit()) { continue; }
            let path = sysfs_path(bus,address);
            let ambiguous = path.is_empty();
            let unique = if ambiguous { format!("[ambiguous]:{}:{}:{}",vid,pid,items.len()) }
                         else { format!("usb:{}:{}:{}",vid,pid,path) };
            let name = if words.len()>6 { words[6..].join(" ") } else { "USB device".into() };
            let mut d=device(name,"usb_hid",unique);d.vendor_id=vid.to_ascii_lowercase();
            d.product_id=pid.to_ascii_lowercase();d.port_path=path;d.ambiguous=ambiguous;items.push(d);
        }
        return Ok(items);
    }
    #[allow(unreachable_code)]
    Err("unsupported_os")
}

fn fingerprint_probe() -> Result<Vec<Fingerprint>, &'static str> {
    #[cfg(target_os = "windows")]
    {
        let output=powershell("Get-PnpDevice -PresentOnly -Class Biometric | Select-Object FriendlyName,InstanceId | ConvertTo-Json -Compress")?;
        return Ok(json_rows(&output).into_iter().enumerate().map(|(i,row)| {
            let instance=text_field(&row,"InstanceId");let (vid,pid)=vid_pid(&instance);
            let mut d=device(text_field(&row,"FriendlyName"),"fingerprint",format!("biometric:{}:{}:{}",vid,pid,i));
            d.vendor_id=vid;d.product_id=pid;d.ambiguous=true;d
        }).collect());
    }
    #[cfg(target_os = "linux")]
    {
        // Candidate names only; this does not claim libfprint support or matching.
        return Ok(usb_probe()?.into_iter().filter_map(|mut d| {
            let name=d.name.to_ascii_lowercase();
            if name.contains("fingerprint") || name.contains("biometric") || name.contains("fprint") {
                d.kind="fingerprint".into(); Some(d)
            } else { None }
        }).collect());
    }
    #[allow(unreachable_code)]
    Err("unsupported_os")
}

pub fn enumerate_printers() -> Vec<Printer> { printer_probe().unwrap_or_default() }
pub fn enumerate_com_ports() -> Vec<ComPort> { com_probe().unwrap_or_default() }
pub fn enumerate_usb_hid() -> Vec<UsbDevice> { usb_probe().unwrap_or_default() }
pub fn enumerate_fingerprint() -> Vec<Fingerprint> { fingerprint_probe().unwrap_or_default() }

pub fn enumerate_with_warnings() -> ProbeReport {
    let mut result=ProbeReport{items:Vec::new(),warnings:Vec::new()};
    for (name,probe) in [("printers",printer_probe as fn()->Result<Vec<Device>,&'static str>),
                         ("com",com_probe),("usb_hid",usb_probe),("fingerprint",fingerprint_probe)] {
        match probe() {
            Ok(mut rows)=>result.items.append(&mut rows),
            Err(_) => { log_supervisor("os_probe_failed"); result.warnings.push(format!("{}: probe unavailable",name)); }
        }
    }
    result
}

#[derive(Clone, Default, Debug, Serialize)]
pub struct SupervisorState {
    pub pid: Option<u32>,
    pub responsive: bool,
    pub fallback: bool,
    pub consecutive_failures: u32,
}

// A valid status body is necessary but does not authenticate a loopback peer.
// The key must be obtained from trusted local configuration by integration code;
// it must never be logged. The draft remains disconnected from Tauri startup.
fn bridge_responsive(port: u16, local_api_key: &str) -> bool {
    if local_api_key.is_empty() || local_api_key.len() > 256 ||
        !local_api_key.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_') {
        return false;
    }
    let address=SocketAddr::from(([127,0,0,1],port));
    let Ok(mut stream)=TcpStream::connect_timeout(&address,Duration::from_secs(2)) else { return false; };
    let _=stream.set_read_timeout(Some(Duration::from_secs(2)));
    let _=stream.set_write_timeout(Some(Duration::from_secs(2)));
    let request=format!("GET /api/v1/health HTTP/1.1\r\nHost: 127.0.0.1:{}\r\nX-WSM-Local-Key: {}\r\nConnection: close\r\n\r\n",port,local_api_key);
    if stream.write_all(request.as_bytes()).is_err() {return false;}
    const MAX_HEALTH_RESPONSE: u64 = 1024 * 1024;
    let mut response=Vec::new();
    if stream.take(MAX_HEALTH_RESPONSE+1).read_to_end(&mut response).is_err() || response.len() as u64 > MAX_HEALTH_RESPONSE {return false;}
    let Ok(text)=std::str::from_utf8(&response) else {return false;};
    let Some((headers, body))=text.split_once("\r\n\r\n") else {return false;};
    let status=headers.lines().next().unwrap_or("");
    if !status.starts_with("HTTP/1.1 200 ") && !status.starts_with("HTTP/1.0 200 ") {return false;}
    if !headers.lines().any(|line| line.to_ascii_lowercase().starts_with("server:") && line.contains("WSM-Local-Bridge")) {return false;}
    let Ok(value)=serde_json::from_str::<Value>(body) else {return false;};
    value.get("status").and_then(Value::as_str)==Some("ok") && value.get("ok").and_then(Value::as_bool)==Some(true)
}

#[cfg(unix)]
fn terminate_child(child: &mut Child) {
    unsafe extern "C" { fn kill(pid: i32, signal: i32) -> i32; }
    const SIGTERM: i32 = 15;
    // Only signal the child spawned and owned by this supervisor.
    unsafe { let _ = kill(child.id() as i32, SIGTERM); }
    let deadline=Instant::now()+Duration::from_secs(5);
    while Instant::now()<deadline {
        if matches!(child.try_wait(),Ok(Some(_))) {return;}
        thread::sleep(Duration::from_millis(50));
    }
    let _=child.kill();let _=child.wait();
}
#[cfg(not(unix))]
fn terminate_child(child: &mut Child) {
    // Windows graceful termination is NOT implemented; this immediately kills.
    let _=child.kill();let _=child.wait();
}

pub struct Supervisor {
    stop: Arc<AtomicBool>,
    worker: Option<JoinHandle<()>>,
    pub state: Arc<Mutex<SupervisorState>>,
}
impl Supervisor {
    // `bridge_executable` must be resolved from the signed installed package by
    // trusted Tauri startup code, never from an untrusted request or device name.
    pub fn start(bridge_executable: PathBuf, port: u16, local_api_key: String) -> Self {
        let stop=Arc::new(AtomicBool::new(false));
        let state=Arc::new(Mutex::new(SupervisorState::default()));
        let worker_stop=Arc::clone(&stop);let worker_state=Arc::clone(&state);
        let worker=thread::spawn(move || {
            let mut child: Option<Child>=None;
            if !Path::new(&bridge_executable).is_file() {
                if let Ok(mut s)=worker_state.lock(){s.fallback=true;}
                log_supervisor("sidecar_missing_fallback");return;
            }
            while !worker_stop.load(Ordering::Relaxed) {
                let exited=match child.as_mut() { Some(c)=>matches!(c.try_wait(),Ok(Some(_))|Err(_)),None=>true };
                let responsive=!exited && bridge_responsive(port, &local_api_key);
                if exited || !responsive {
                    if let Some(mut old)=child.take(){terminate_child(&mut old);}
                    let failures=worker_state.lock().map(|s|s.consecutive_failures).unwrap_or(3);
                    if failures>=3 {
                        if let Ok(mut s)=worker_state.lock(){s.fallback=true;s.pid=None;s.responsive=false;}
                        log_supervisor("restart_limit_fallback");break;
                    }
                    match Command::new(&bridge_executable).arg("run")
                        .stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).spawn() {
                        Ok(new_child)=>{
                            if let Ok(mut s)=worker_state.lock(){s.pid=Some(new_child.id());s.responsive=false;s.consecutive_failures+=1;}
                            child=Some(new_child);log_supervisor("restart_attempt");
                        },
                        Err(_)=>{
                            if let Ok(mut s)=worker_state.lock(){s.pid=None;s.consecutive_failures+=1;}
                            log_supervisor("spawn_failed");
                        }
                    }
                } else if let Ok(mut s)=worker_state.lock() {
                    s.responsive=true;s.consecutive_failures=0;s.fallback=false;
                }
                for _ in 0..30 {
                    if worker_stop.load(Ordering::Relaxed){break;}
                    thread::sleep(Duration::from_millis(100));
                }
            }
            if let Some(mut owned)=child {terminate_child(&mut owned);}
            if let Ok(mut s)=worker_state.lock(){s.pid=None;s.responsive=false;}
        });
        Self{stop,worker:Some(worker),state}
    }
    pub fn stop(&mut self) {
        self.stop.store(true,Ordering::Relaxed);
        if let Some(worker)=self.worker.take(){let _=worker.join();}
    }
}
impl Drop for Supervisor { fn drop(&mut self){self.stop();} }
